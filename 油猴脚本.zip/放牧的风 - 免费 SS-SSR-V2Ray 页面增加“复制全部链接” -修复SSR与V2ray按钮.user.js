// ==UserScript==
// @name        放牧的风 - 免费 SS/SSR/V2Ray 页面增加“复制全部链接” -修复SSR与V2ray按钮
// @description 提取放牧的风在页面上提供的免费账号并增加“复制全部链接”按钮。【提升网页改动的兼容性&修复SSR页面bug】
// @namespace   UnKnown
// @match       *://www.youneed.win/free-*
// @require     https://libs.baidu.com/jquery/1.7.2/jquery.min.js
// @version      1.12
// @grant       none
// ==/UserScript==

(() => {
    //监听div内容改变(验证通过)
    $("body").bind("DOMNodeInserted", function () {

        //标记节点位置
        const parentNode = document.querySelector('.context');
        const referenceNodeArray = parentNode.querySelectorAll(':scope > div');
        for (var i = 0; i < referenceNodeArray.length; i++){
            if (referenceNodeArray[i].id == "AllLinks") return false; //已插入AllLinks节点
            if (referenceNodeArray[i].style.width == "700px" & (referenceNodeArray[i].style.overflow == "auto" | referenceNodeArray[i].style.overflow == "scroll")){
                var tempNode = referenceNodeArray[i]; //选择特定style的div
            }
        }
        const referenceNode = tempNode;
        const table = referenceNode.querySelector(':scope > table:only-child');

        if (!table) return false; //找不到table节点

        const arraySelector = (
            selector = ':scope > *',
            parent = table,
        ) => Array.from(
            parent.querySelectorAll( selector )
        );

        const type = location.pathname.slice(6);
        const getLinks = type => ({

            //获取ss链接
            ss: () => arraySelector(':scope > tbody > tr').map(
                tr => {
                    const d = arraySelector(':scope > td', tr).map(
                        td => td.textContent
                    );
                    //base64编码
                    return 'ss://' + base64(`${d[4]}:${d[3]}@${d[1]}:${d[2]}`);
                }
            ).join("\n"),

            //获取ssr链接
            //ssr: () => Array.from(table.querySelectorAll('a[data^="ssr"]')).map( a => a.getAttribute("data") ).join("\n"),
            ssr: () => arraySelector('a[data^="ssr"]').map(a => a.getAttribute("data")).join("\n"),

            //获取v2ray链接
            v2ray: () => arraySelector(':scope > tbody > tr').map(
                tr => {
                    const data = arraySelector(':scope > td', tr).map(
                        td => td.textContent
                    );
                    //base64编码
                    //v1版vmess的客户端使用这一行
                    //return 'vmess://' + base64(`{"ps":"[youneed.win]${data[1]}","add":"${data[1]}","port":"${data[2]}","id":"${data[3]}","aid":"0","net":"${data[4]}","type":"none","path":"${data[5]}","tls":"${data[6]}"}`);
                    //v2版vmess的客户端使用这一行（测试最新版V2rayN、V2rayU、Qv2ray、Trojan-qt5都支持）
                    return 'vmess://' + base64(`{"v":"2","ps":"[youneed.win]${data[1]}","add":"${data[1]}","port":"${data[2]}","id":"${data[3]}","aid":"0","net":"${data[4]}","type":"none","host":"","path":"${data[5]}","tls":"${data[6]}"}`);
                }
            ).join("\n"),

        })[type];


        let base64;
        if (type == "ss" || type == "v2ray") {
            //选择编码算法
            if (!window.CryptoJS) {
                // From https://en.wikibooks.org/wiki/Algorithm_Implementation/Miscellaneous/Base64#Javascript
                base64 = s => {
                    var d = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/",
                        r = "", p = "", c = s.length % 3;
                    if (c > 0) {
                        for (; c < 3; c++) {
                            p += '=';
                            s += "\0";
                        }
                    }
                    for (c = 0; c < s.length; c += 3) {
                        var n = (s.charCodeAt(c) << 16) + (s.charCodeAt(c + 1) << 8) + s.charCodeAt(c + 2);
                        n = [(n >>> 18) & 63, (n >>> 12) & 63, (n >>> 6) & 63, n & 63];
                        r += d[n[0]] + d[n[1]] + d[n[2]] + d[n[3]];
                    }
                    return r.substring(0, r.length - p.length) + p;
                }
            } else {
                base64 = str => CryptoJS.enc.Base64.stringify(
                    CryptoJS.enc.Utf8.parse(str)
                );
            }
        }

        // 获取所有链接
        const resultStr = getLinks(type)();

        // 添加一个文本容器
        const pre = document.createElement("pre");
        pre.style = "max-height: 12em; overflow-y: auto; margin-bottom: 10px;";
        pre.textContent = resultStr;

        //添加提示窗口
        function showTips(content, height, time) {
            var windowWidth = $(window).width();
            var tipsDiv = '<div class="tipsClass">' + content + '</div>';
            $('body').append(tipsDiv);
            $('div.tipsClass').css({
                'top': '40%',
                'left': (windowWidth / 2) - 200 / 2 + 'px',
                'position': 'fixed',
                'padding': '3px 5px',
                'background': '#FF0000',
                'font-size': 18 + 'px',
                'margin': '0 auto',
                'text-align': 'center',
                'width': '200px',
                'height': 'auto',
                'color': '#fff',
                'opacity': '0.8'
            }).show();
            setTimeout(function () { $('div.tipsClass').fadeOut(); }, (time * 1000));
        }

        // 添加复制按钮
        const button = document.createElement("button");
        button.style = "width: 100%; font-size: large;";
        button.textContent = "复制全部链接";
        button.addEventListener("click", () => {
            try {
                if (navigator.clipboard) {
                    navigator.clipboard.writeText(resultStr);
                    showTips('复制成功!', 30, 2);
                } else {
                    const eventCopyer = event => {
                        event.preventDefault();
                        event.clipboardData.setData("text/plain", resultStr);
                    }
                    document.addEventListener("copy", eventCopyer);
                    document.execCommand("copy");
                    document.removeEventListener("copy", eventCopyer);
                }
            } catch (error) {
                button.parentNode.insertBefore((str => {
                    const info = document.createElement("pre");
                    info.textContent ="若复制失败，请手动选择复制，" +
                        "PC 端用户可按 F12 获取详细错误信息，以便反馈。"
                        + "\n捕捉到的错误信息：" + str;
                })(error), button.nextSibling);
            }
        });

        //创建新节点
        const newNode = document.createElement("div");
        newNode.id = "AllLinks";

        newNode.appendChild(pre);
        newNode.appendChild(button);

        //节点插入位置
        parentNode.insertBefore(newNode, referenceNode);

    })
})();
