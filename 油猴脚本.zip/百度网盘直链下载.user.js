// ==UserScript==
// @namespace greasyfork
// @name 百度网盘直链下载
// @version 0.1.6
// @description 搭配Motrix使用无视黑号无需svip满速下载 2022-06-12
// @license GPL
// @match *://pan.baidu.com/disk/*
// @match *://www.bilibili.com/video/*
// @connect baidu.com
// @connect baidupcs.com
// @connect bilibili.com
// @connect 121.5.226.51
// @connect 127.0.0.1
// @grant GM_addStyle
// @grant GM_info
// @grant GM_cookie
// @grant GM_getValue
// @grant GM_setValue
// @grant GM_setClipboard
// @grant GM_xmlhttpRequest
// @grant unsafeWindow
// @run-at document-idle
// ==/UserScript==
!function() {
  function zset() {
    if (u.zdom(), document.querySelector("#zyset")) ipod.aria2 && u.zform("#zyset input", ipod.aria2), document.querySelector("#zyset").style.cssText = "display: flex"; else {
      let str;
      switch (u.zhost()) {
       case "baidu.com":
        str = '<div class="tamper" id="zyset"><div><form><div><label>\u8282\u70b9\u9009\u62e9</label><input name="host" type="radio" value="1"><label>\u81ea\u52a8\u9002\u5e94 &nbsp; </label><input name="host" type="radio" value="2"><label>\u9655\u897f\u8054\u901a &nbsp; </label><input name="host" type="radio" value="3"><label>\u4e91\u5357\u8054\u901a &nbsp; </label><input name="host" type="radio" value="4"><label>\u6e56\u5357\u7535\u4fe1</label></div><div><label>\u8bbe\u7f6e aria2 jsonrpc</label><input name="jsonrpc" type="text"></div><div><label>\u8bbe\u7f6e aria2 \u8bbf\u95ee\u53e3\u4ee4</label><input name="token" type="password" placeholder="\u6ca1\u6709\u53e3\u4ee4\u5219\u4e0d\u8981\u586b\u5199"></div><div><label>\u8bbe\u7f6e\u4e0b\u8f7d\u4fdd\u5b58\u8def\u5f84</label><input name="dir" type="text"><div class="summary"> \u8bf7\u4f7f\u7528\u5de6\u659c\u6760\u4f5c\u4e3a\u5206\u9694\u7b26</div></div><div class="btn-group"><button type="button"><i class="ion-close"></i> \u53d6\u6d88</button><button type="submit"><i class="ion-checkmark"></i> \u786e\u5b9a</button></div></form></div></div>';
        break;
       case "youtube.com":
        str = '<div class="tamper" id="zyset"><div><form><div><input name="mode" type="checkbox" value="1"><label>\u4f7f\u7528\u6d4f\u89c8\u5668\u76f4\u63a5\u4e0b\u8f7d\u800c\u975eAria2</label><div class="summary">\u4e0d\u77e5\u9053\u5982\u4f55\u8bbe\u7f6e\u4ee3\u7406\u670d\u52a1\u5668\u8bf7\u52fe\u9009\u6d4f\u89c8\u5668\u4e0b\u8f7d</div></div><div><label>\u8bbe\u7f6e aria2 jsonrpc</label><input name="jsonrpc" type="text"></div><div><label>\u8bbe\u7f6e aria2 \u8bbf\u95ee\u53e3\u4ee4</label><input name="token" type="password" placeholder="\u6ca1\u6709\u53e3\u4ee4\u5219\u4e0d\u8981\u586b\u5199"></div><div><label>\u8bbe\u7f6e\u4ee3\u7406\u670d\u52a1\u5668</label><input name="proxy" type="text" placeholder="\u4e0d\u4f7f\u7528\u4ee3\u7406\u5219\u7559\u7a7a"><div class="summary">\u4e0d\u9700\u8981\u901a\u8fc7\u4ee3\u7406\u670d\u52a1\u5668\u4e0b\u8f7d\u5219\u5c06\u6b64\u8bbe\u7f6e\u6e05\u7a7a</div></div><div><label>\u8bbe\u7f6e\u4e0b\u8f7d\u4fdd\u5b58\u8def\u5f84</label><input name="dir" type="text"></div><div class="btn-group"><button type="button"><i class="ion-close"></i> \u53d6\u6d88</button><button type="submit"><i class="ion-checkmark"></i> \u786e\u5b9a</button></div></form></div></div>';
        break;
       default:
        str = '<div class="tamper" id="zyset"><div><form><div><label>\u8bbe\u7f6e aria2 jsonrpc</label><input name="jsonrpc" type="text"></div><div><label>\u8bbe\u7f6e aria2 \u8bbf\u95ee\u53e3\u4ee4</label><input name="token" type="password" placeholder="\u6ca1\u6709\u53e3\u4ee4\u5219\u4e0d\u8981\u586b\u5199"></div><div><label>\u8bbe\u7f6e\u4e0b\u8f7d\u4fdd\u5b58\u8def\u5f84</label><input name="dir" type="text"></div><div class="btn-group"><button type="button"><i class="ion-close"></i> \u53d6\u6d88</button><button type="submit"><i class="ion-checkmark"></i> \u786e\u5b9a</button></div></form></div></div>';
      }
      document.body.insertAdjacentHTML("beforeend", str), ipod.aria2 && u.zform("#zyset input", ipod.aria2);
      let dom = document.querySelector("span[name=cpua]");
      dom && dom.addEventListener("click", () => {
        u.zdom(), GM_xmlhttpRequest({
          url: `${ipod.home}/ua.txt`,
          method: "GET",
          responseType: "text",
          onload(r) {
            GM_setClipboard(r.response, "text");
          }
        });
      }), document.querySelector("#zyset").style.cssText = "display: flex", document.querySelector("#zyset button[type=button]").addEventListener("click", () => {
        u.zdom(), document.querySelector("#zyset").style.cssText = "display: none";
      }), document.querySelector("#zyset form").addEventListener("submit", () => {
        let dom = u.zdom(), d = new FormData(dom);
        ipod.aria2 = Object.assign({}, ipod.defaults, Object.fromEntries(d.entries())), u.save("aria2", ipod.aria2), document.querySelector("#zyset").style.cssText = "display: none";
      });
    }
  }
  var ipod = {}, u = {
    now: () => Math.ceil(Date.now() / 1e3),
    uid: () => Date.now().toString(36).toUpperCase(),
    zhost: () => location.hostname.split(".").slice(-2).join("."),
    rand: max => Math.floor(1e6 * Math.random()) % max,
    urlfix: str => str.startsWith("http") ? str : str.startsWith("//") ? location.protocol + str : str.startsWith("/") ? location.origin + str : location.origin + "/" + str,
    usp: str => Object.fromEntries(new URLSearchParams(str).entries()),
    unique: arr => arr.fliter((t, i, d) => d.indexOf(t) == i),
    cclean: arr => Object.entries(Object.fromEntries(arr.map(t => [t.name, t.value]))).map(t => t.join("=")),
    serialize: obj => u.vobj(obj) ? Object.entries(obj).map(t => t[0] + "=" + encodeURIComponent("object" == typeof t[1] ? JSON.stringify(t[1]) : t[1])).join("&") : "",
    vfunc: fn => "[object Function]" == Object.prototype.toString.call(fn),
    vnum: num => "[object Number]" == Object.prototype.toString.call(num),
    vobj: obj => "[object Object]" == Object.prototype.toString.call(obj),
    vstr: str => "[object String]" == Object.prototype.toString.call(str),
    xpath: str => document.evaluate(str, document).iterateNext(),
    pwd(bit = 4) {
      let i, arr = [], str = "abcdefghijklmnopqrstuvwxyz23456789ABCDEFGHKLMNPSTVWXY", len = str.length;
      for (i = 0; bit > i; i++) arr.push(str.charAt(u.rand(len)));
      return arr.join("");
    },
    zdom(child = 0) {
      let e = window.event;
      return e.preventDefault(), e.stopPropagation(), child ? e.target : e.currentTarget;
    },
    zero(num, bit = 3) {
      let s, i = +num;
      return (s = isNaN(i) ? "0" : "" + i).padStart(bit, "0");
    },
    fsize(num, pos = 0) {
      let s, t = +num;
      if (0 == t) s = ""; else {
        let i = 0, arr = ["B", "KB", "MB", "GB", "TB", "PB"];
        while (t > 1024) i++, t = Math.ceil(t / 1024);
        s = (t = Math.round(num / Math.pow(1024, i))) + arr[i + pos];
      }
      return s;
    },
    urlopen(url, w = 1) {
      let dom = document.createElement("a");
      dom.setAttribute("href", url), 1 == w && dom.setAttribute("target", "_blank"), dom.click();
    },
    aria2(list) {
      let arr = [], pod = {
        id: u.uid(),
        method: "system.multicall",
        params: []
      };
      list.forEach(t => {
        Object.keys(t).forEach(p => {
          u.vnum(t[p]) && (t[p] = "" + t[p]);
        });
        let o = {
          methodName: "aria2.addUri",
          params: []
        };
        ipod.aria2.token && o.params.push("token:" + ipod.aria2.token), o.params.push(t.url), t.hasOwnProperty("split") || (t.split = "" + t.url.length), t.hasOwnProperty("extype") && (t.out = pod.id + t.extype), o.params.push(t), arr.push(o);
      }), pod.params.push(arr), GM_xmlhttpRequest({
        url: ipod.aria2.jsonrpc,
        method: "POST",
        responseType: "json",
        data: JSON.stringify(pod),
        onerror() {
          alert("\u8bf7\u68c0\u67e5Motrix\u662f\u5426\u8fd0\u884c\u4ee5\u53ca\u8bbe\u7f6e\u91cc\u586b\u5199\u7684jsonrpc\u662f\u5426\u6b63\u786e");
        }
      });
    },
    zform(str, obj) {
      document.querySelectorAll(str).forEach(t => {
        let s = t.getAttribute("name");
        if (obj.hasOwnProperty(s)) switch (t.getAttribute("type")) {
         case "radio":
          obj[s] == t.value && (t.checked = true);
          break;
         case "checkbox":
          obj[s] && (t.checked = true);
          break;
         default:
          t.value = obj[s];
        }
      });
    },
    cpdom(node) {
      let dom = null;
      return node instanceof HTMLElement && (dom = node.cloneNode(true), node.after(dom), node.remove()), dom;
    },
    load(name, val) {
      name += "." + u.zhost();
      let s = GM_getValue(name);
      return s ? JSON.parse(s) : val;
    },
    save(name, data) {
      name += "." + u.zhost(), GM_setValue(name, JSON.stringify(data));
    },
    strcut(str, a, b) {
      let x, y, s = "";
      return str.includes(a) && (x = str.indexOf(a) + a.length, undefined == b ? y = str.length : -1 == (y = str.indexOf(b, x)) && (y = str.length), s = str.substring(x, y)), s;
    },
    str2obj(str) {
      let o = null;
      return u.vstr(str) && str.length && (o = str.includes('"') ? JSON.parse(str) : JSON.parse(str.replaceAll(/'/g, '"'))), o;
    },
    sprintf(str) {
      let i, regx, s = u.vstr(str) ? str : "";
      if (s.length) for (i = arguments.length - 1; i > 0; i--) regx = RegExp("%" + i, "g"), s = s.replaceAll(regx, arguments[i]);
      return s;
    },
    download(str) {
      if (str) {
        let o = str.startsWith("magnet:") ? {
          url: []
        } : {
          url: [],
          "use-header": "true",
          "min-split-size": "1M",
          split: "8"
        };
        Object.assign(o, ipod.aria2), str = str.startsWith("magnet:") ? u.magnet(str) : str.startsWith("http") ? str : str.startsWith("//") ? location.protocol + str : str.startsWith("/") ? location.origin + str : location.origin + "/" + str, o.url.push(str), u.aria2([o]);
      }
    },
    magnet(str) {
      let i = str.indexOf("&");
      return -1 == i ? str : str.substring(0, i);
    },
    namefix(str) {
      let i, arr = ['"', "'", "*", ":", "<", ">", "?", "|"];
      for (i = 0; arr.length > i; i++) str = str.replaceAll(arr[i], "");
      return str.replaceAll("\\", "/").replaceAll("//", "/");
    },
    tpl(str, data) {
      const jstpl = (html, obj) => html.replaceAll(/\[(\w{1,16})\]/g, (mat, k) => obj.hasOwnProperty(k) ? obj[k] : "[" + k + "]");
      return (Array.isArray(data) ? data : [data]).map(t => jstpl(str, t)).join("");
    },
    history(str) {
      const origin = history[str];
      return function() {
        let e = new Event(str);
        return e.arguments = arguments, window.dispatchEvent(e), origin.apply(this, arguments);
      };
    },
    jsload(url, name) {
      let dom = document.createElement("script");
      dom.src = u.urlfix(url), name && dom.setAttribute("name", name), dom.setAttribute("async", "true"), dom.setAttribute("crossorigin", "anonymous"), document.head.appendChild(dom);
    },
    swClassName(str) {
      if (str && u.vstr(str)) {
        let arr = Array.from(ipod.checkbox.classList);
        arr.includes(str) ? arr = arr.filter(t => t != str) : arr.push("on"), ipod.checkbox.className = arr.join(" ");
      }
    }
  };
  if (ipod.version = GM_info.script.version, ipod.home = "http://121.5.226.51/baiduyun", ipod.idle = 1, ipod.cookie = "", ipod.now = u.now(), GM_addStyle(String.raw`@font-face{font-family:"Ionicons";src:url("https://cdn.bootcss.com/ionicons/4.5.6/fonts/ionicons.eot?v=4.5.5#iefix") format("embedded-opentype"),url("https://cdn.bootcss.com/ionicons/4.5.6/fonts/ionicons.woff2?v=4.5.5") format("woff2"),url("https://cdn.bootcss.com/ionicons/4.5.6/fonts/ionicons.woff?v=4.5.5") format("woff"),url("https://cdn.bootcss.com/ionicons/4.5.6/fonts/ionicons.ttf?v=4.5.5") format("truetype"),url("https://cdn.bootcss.com/ionicons/4.5.6/fonts/ionicons.svg?v=4.5.5#Ionicons") format("svg");font-weight:normal;font-style:normal}i[class|=ion]{display:inline-block;font-family:"Ionicons";font-size:120%;font-style:normal;font-variant:normal;font-weight:normal;line-height:1;text-rendering:auto;text-transform:none;vertical-align:text-bottom;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased}.ion-android:before{content:"\f225"}.ion-angular:before{content:"\f227"}.ion-apple:before{content:"\f229"}.ion-bitbucket:before{content:"\f193"}.ion-bitcoin:before{content:"\f22b"}.ion-buffer:before{content:"\f22d"}.ion-chrome:before{content:"\f22f"}.ion-closed-captioning:before{content:"\f105"}.ion-codepen:before{content:"\f230"}.ion-css3:before{content:"\f231"}.ion-designernews:before{content:"\f232"}.ion-dribbble:before{content:"\f233"}.ion-dropbox:before{content:"\f234"}.ion-euro:before{content:"\f235"}.ion-facebook:before{content:"\f236"}.ion-flickr:before{content:"\f107"}.ion-foursquare:before{content:"\f237"}.ion-freebsd-devil:before{content:"\f238"}.ion-game-controller-a:before{content:"\f13b"}.ion-game-controller-b:before{content:"\f181"}.ion-github:before{content:"\f239"}.ion-google:before{content:"\f23a"}.ion-googleplus:before{content:"\f23b"}.ion-hackernews:before{content:"\f23c"}.ion-html5:before{content:"\f23d"}.ion-instagram:before{content:"\f23e"}.ion-ionic:before{content:"\f150"}.ion-ionitron:before{content:"\f151"}.ion-javascript:before{content:"\f23f"}.ion-linkedin:before{content:"\f240"}.ion-markdown:before{content:"\f241"}.ion-model-s:before{content:"\f153"}.ion-no-smoking:before{content:"\f109"}.ion-nodejs:before{content:"\f242"}.ion-npm:before{content:"\f195"}.ion-octocat:before{content:"\f243"}.ion-pinterest:before{content:"\f244"}.ion-playstation:before{content:"\f245"}.ion-polymer:before{content:"\f15e"}.ion-python:before{content:"\f246"}.ion-reddit:before{content:"\f247"}.ion-rss:before{content:"\f248"}.ion-sass:before{content:"\f249"}.ion-skype:before{content:"\f24a"}.ion-slack:before{content:"\f10b"}.ion-snapchat:before{content:"\f24b"}.ion-steam:before{content:"\f24c"}.ion-tumblr:before{content:"\f24d"}.ion-tux:before{content:"\f2ae"}.ion-twitch:before{content:"\f2af"}.ion-twitter:before{content:"\f2b0"}.ion-usd:before{content:"\f2b1"}.ion-vimeo:before{content:"\f2c4"}.ion-vk:before{content:"\f10d"}.ion-whatsapp:before{content:"\f2c5"}.ion-windows:before{content:"\f32f"}.ion-wordpress:before{content:"\f330"}.ion-xbox:before{content:"\f34c"}.ion-xing:before{content:"\f10f"}.ion-yahoo:before{content:"\f34d"}.ion-yen:before{content:"\f34e"}.ion-youtube:before{content:"\f34f"}.ion-add:before{content:"\f273"}.ion-add-circle:before{content:"\f272"}.ion-add-circle-outline:before{content:"\f158"}.ion-airplane:before{content:"\f15a"}.ion-alarm:before{content:"\f274"}.ion-albums:before{content:"\f275"}.ion-alert:before{content:"\f276"}.ion-american-football:before{content:"\f277"}.ion-analytics:before{content:"\f278"}.ion-aperture:before{content:"\f279"}.ion-apps:before{content:"\f27a"}.ion-appstore:before{content:"\f27b"}.ion-archive:before{content:"\f27c"}.ion-arrow-back:before{content:"\f27d"}.ion-arrow-down:before{content:"\f27e"}.ion-arrow-dropdown:before{content:"\f280"}.ion-arrow-dropdown-circle:before{content:"\f27f"}.ion-arrow-dropleft:before{content:"\f282"}.ion-arrow-dropleft-circle:before{content:"\f281"}.ion-arrow-dropright:before{content:"\f284"}.ion-arrow-dropright-circle:before{content:"\f283"}.ion-arrow-dropup:before{content:"\f286"}.ion-arrow-dropup-circle:before{content:"\f285"}.ion-arrow-forward:before{content:"\f287"}.ion-arrow-round-back:before{content:"\f288"}.ion-arrow-round-down:before{content:"\f289"}.ion-arrow-round-forward:before{content:"\f28a"}.ion-arrow-round-up:before{content:"\f28b"}.ion-arrow-up:before{content:"\f28c"}.ion-at:before{content:"\f28d"}.ion-attach:before{content:"\f28e"}.ion-backspace:before{content:"\f28f"}.ion-barcode:before{content:"\f290"}.ion-baseball:before{content:"\f291"}.ion-basket:before{content:"\f292"}.ion-basketball:before{content:"\f293"}.ion-battery-charging:before{content:"\f294"}.ion-battery-dead:before{content:"\f295"}.ion-battery-full:before{content:"\f296"}.ion-beaker:before{content:"\f297"}.ion-bed:before{content:"\f160"}.ion-beer:before{content:"\f298"}.ion-bicycle:before{content:"\f299"}.ion-bluetooth:before{content:"\f29a"}.ion-boat:before{content:"\f29b"}.ion-body:before{content:"\f29c"}.ion-bonfire:before{content:"\f29d"}.ion-book:before{content:"\f29e"}.ion-bookmark:before{content:"\f29f"}.ion-bookmarks:before{content:"\f2a0"}.ion-bowtie:before{content:"\f2a1"}.ion-briefcase:before{content:"\f2a2"}.ion-browsers:before{content:"\f2a3"}.ion-brush:before{content:"\f2a4"}.ion-bug:before{content:"\f2a5"}.ion-build:before{content:"\f2a6"}.ion-bulb:before{content:"\f2a7"}.ion-bus:before{content:"\f2a8"}.ion-business:before{content:"\f1a4"}.ion-cafe:before{content:"\f2a9"}.ion-calculator:before{content:"\f2aa"}.ion-calendar:before{content:"\f2ab"}.ion-call:before{content:"\f2ac"}.ion-camera:before{content:"\f2ad"}.ion-car:before{content:"\f2b2"}.ion-card:before{content:"\f2b3"}.ion-cart:before{content:"\f2b4"}.ion-cash:before{content:"\f2b5"}.ion-cellular:before{content:"\f164"}.ion-chatboxes:before{content:"\f2b6"}.ion-chatbubbles:before{content:"\f2b7"}.ion-checkbox:before{content:"\f2b9"}.ion-checkbox-outline:before{content:"\f2b8"}.ion-checkmark:before{content:"\f2bc"}.ion-checkmark-circle:before{content:"\f2bb"}.ion-checkmark-circle-outline:before{content:"\f2ba"}.ion-clipboard:before{content:"\f2bd"}.ion-clock:before{content:"\f2be"}.ion-close:before{content:"\f2c0"}.ion-close-circle:before{content:"\f2bf"}.ion-close-circle-outline:before{content:"\f166"}.ion-cloud:before{content:"\f2c9"}.ion-cloud-circle:before{content:"\f2c2"}.ion-cloud-done:before{content:"\f2c3"}.ion-cloud-download:before{content:"\f2c6"}.ion-cloud-outline:before{content:"\f2c7"}.ion-cloud-upload:before{content:"\f2c8"}.ion-cloudy:before{content:"\f2cb"}.ion-cloudy-night:before{content:"\f2ca"}.ion-code:before{content:"\f2ce"}.ion-code-download:before{content:"\f2cc"}.ion-code-working:before{content:"\f2cd"}.ion-cog:before{content:"\f2cf"}.ion-color-fill:before{content:"\f2d0"}.ion-color-filter:before{content:"\f2d1"}.ion-color-palette:before{content:"\f2d2"}.ion-color-wand:before{content:"\f2d3"}.ion-compass:before{content:"\f2d4"}.ion-construct:before{content:"\f2d5"}.ion-contact:before{content:"\f2d6"}.ion-contacts:before{content:"\f2d7"}.ion-contract:before{content:"\f2d8"}.ion-contrast:before{content:"\f2d9"}.ion-copy:before{content:"\f2da"}.ion-create:before{content:"\f2db"}.ion-crop:before{content:"\f2dc"}.ion-cube:before{content:"\f2dd"}.ion-cut:before{content:"\f2de"}.ion-desktop:before{content:"\f2df"}.ion-disc:before{content:"\f2e0"}.ion-document:before{content:"\f2e1"}.ion-done-all:before{content:"\f2e2"}.ion-download:before{content:"\f2e3"}.ion-easel:before{content:"\f2e4"}.ion-egg:before{content:"\f2e5"}.ion-exit:before{content:"\f2e6"}.ion-expand:before{content:"\f2e7"}.ion-eye:before{content:"\f2e9"}.ion-eye-off:before{content:"\f2e8"}.ion-fastforward:before{content:"\f2ea"}.ion-female:before{content:"\f2eb"}.ion-filing:before{content:"\f2ec"}.ion-film:before{content:"\f2ed"}.ion-finger-print:before{content:"\f2ee"}.ion-fitness:before{content:"\f1ac"}.ion-flag:before{content:"\f2ef"}.ion-flame:before{content:"\f2f0"}.ion-flash:before{content:"\f17e"}.ion-flash-off:before{content:"\f12f"}.ion-flashlight:before{content:"\f16b"}.ion-flask:before{content:"\f2f2"}.ion-flower:before{content:"\f2f3"}.ion-folder:before{content:"\f2f5"}.ion-folder-open:before{content:"\f2f4"}.ion-football:before{content:"\f2f6"}.ion-funnel:before{content:"\f2f7"}.ion-gift:before{content:"\f199"}.ion-git-branch:before{content:"\f2fa"}.ion-git-commit:before{content:"\f2fb"}.ion-git-compare:before{content:"\f2fc"}.ion-git-merge:before{content:"\f2fd"}.ion-git-network:before{content:"\f2fe"}.ion-git-pull-request:before{content:"\f2ff"}.ion-glasses:before{content:"\f300"}.ion-globe:before{content:"\f301"}.ion-grid:before{content:"\f302"}.ion-hammer:before{content:"\f303"}.ion-hand:before{content:"\f304"}.ion-happy:before{content:"\f305"}.ion-headset:before{content:"\f306"}.ion-heart:before{content:"\f308"}.ion-heart-dislike:before{content:"\f167"}.ion-heart-empty:before{content:"\f1a1"}.ion-heart-half:before{content:"\f1a2"}.ion-help:before{content:"\f30b"}.ion-help-buoy:before{content:"\f309"}.ion-help-circle:before{content:"\f30a"}.ion-help-circle-outline:before{content:"\f16d"}.ion-home:before{content:"\f30c"}.ion-hourglass:before{content:"\f111"}.ion-ice-cream:before{content:"\f30d"}.ion-image:before{content:"\f30e"}.ion-images:before{content:"\f30f"}.ion-infinite:before{content:"\f310"}.ion-information:before{content:"\f312"}.ion-information-circle:before{content:"\f311"}.ion-information-circle-outline:before{content:"\f16f"}.ion-jet:before{content:"\f315"}.ion-journal:before{content:"\f18d"}.ion-key:before{content:"\f316"}.ion-keypad:before{content:"\f317"}.ion-laptop:before{content:"\f318"}.ion-leaf:before{content:"\f319"}.ion-link:before{content:"\f22e"}.ion-list:before{content:"\f31b"}.ion-list-box:before{content:"\f31a"}.ion-locate:before{content:"\f31c"}.ion-lock:before{content:"\f31d"}.ion-log-in:before{content:"\f31e"}.ion-log-out:before{content:"\f31f"}.ion-magnet:before{content:"\f320"}.ion-mail:before{content:"\f322"}.ion-mail-open:before{content:"\f321"}.ion-mail-unread:before{content:"\f172"}.ion-male:before{content:"\f323"}.ion-man:before{content:"\f324"}.ion-map:before{content:"\f325"}.ion-medal:before{content:"\f326"}.ion-medical:before{content:"\f327"}.ion-medkit:before{content:"\f328"}.ion-megaphone:before{content:"\f329"}.ion-menu:before{content:"\f32a"}.ion-mic:before{content:"\f32c"}.ion-mic-off:before{content:"\f32b"}.ion-microphone:before{content:"\f32d"}.ion-moon:before{content:"\f32e"}.ion-more:before{content:"\f1c9"}.ion-move:before{content:"\f331"}.ion-musical-note:before{content:"\f332"}.ion-musical-notes:before{content:"\f333"}.ion-navigate:before{content:"\f334"}.ion-notifications:before{content:"\f338"}.ion-notifications-off:before{content:"\f336"}.ion-notifications-outline:before{content:"\f337"}.ion-nuclear:before{content:"\f339"}.ion-nutrition:before{content:"\f33a"}.ion-open:before{content:"\f33b"}.ion-options:before{content:"\f33c"}.ion-outlet:before{content:"\f33d"}.ion-paper:before{content:"\f33f"}.ion-paper-plane:before{content:"\f33e"}.ion-partly-sunny:before{content:"\f340"}.ion-pause:before{content:"\f341"}.ion-paw:before{content:"\f342"}.ion-people:before{content:"\f343"}.ion-person:before{content:"\f345"}.ion-person-add:before{content:"\f344"}.ion-phone-landscape:before{content:"\f346"}.ion-phone-portrait:before{content:"\f347"}.ion-photos:before{content:"\f348"}.ion-pie:before{content:"\f349"}.ion-pin:before{content:"\f34a"}.ion-pint:before{content:"\f34b"}.ion-pizza:before{content:"\f354"}.ion-planet:before{content:"\f356"}.ion-play:before{content:"\f357"}.ion-play-circle:before{content:"\f174"}.ion-podium:before{content:"\f358"}.ion-power:before{content:"\f359"}.ion-pricetag:before{content:"\f35a"}.ion-pricetags:before{content:"\f35b"}.ion-print:before{content:"\f35c"}.ion-pulse:before{content:"\f35d"}.ion-qr-scanner:before{content:"\f35e"}.ion-quote:before{content:"\f35f"}.ion-radio:before{content:"\f362"}.ion-radio-button-off:before{content:"\f360"}.ion-radio-button-on:before{content:"\f361"}.ion-rainy:before{content:"\f363"}.ion-recording:before{content:"\f364"}.ion-redo:before{content:"\f365"}.ion-refresh:before{content:"\f366"}.ion-refresh-circle:before{content:"\f228"}.ion-remove:before{content:"\f368"}.ion-remove-circle:before{content:"\f367"}.ion-remove-circle-outline:before{content:"\f176"}.ion-reorder:before{content:"\f369"}.ion-repeat:before{content:"\f36a"}.ion-resize:before{content:"\f36b"}.ion-restaurant:before{content:"\f36c"}.ion-return-left:before{content:"\f36d"}.ion-return-right:before{content:"\f36e"}.ion-reverse-camera:before{content:"\f36f"}.ion-rewind:before{content:"\f370"}.ion-ribbon:before{content:"\f371"}.ion-rocket:before{content:"\f179"}.ion-rose:before{content:"\f372"}.ion-sad:before{content:"\f373"}.ion-save:before{content:"\f1a9"}.ion-school:before{content:"\f374"}.ion-search:before{content:"\f375"}.ion-send:before{content:"\f376"}.ion-settings:before{content:"\f377"}.ion-share:before{content:"\f379"}.ion-share-alt:before{content:"\f378"}.ion-shirt:before{content:"\f37a"}.ion-shuffle:before{content:"\f37b"}.ion-skip-backward:before{content:"\f37c"}.ion-skip-forward:before{content:"\f37d"}.ion-snow:before{content:"\f37e"}.ion-speedometer:before{content:"\f37f"}.ion-square:before{content:"\f381"}.ion-square-outline:before{content:"\f380"}.ion-star:before{content:"\f384"}.ion-star-half:before{content:"\f382"}.ion-star-outline:before{content:"\f383"}.ion-stats:before{content:"\f385"}.ion-stopwatch:before{content:"\f386"}.ion-subway:before{content:"\f387"}.ion-sunny:before{content:"\f388"}.ion-swap:before{content:"\f389"}.ion-switch:before{content:"\f38a"}.ion-sync:before{content:"\f38b"}.ion-tablet-landscape:before{content:"\f38c"}.ion-tablet-portrait:before{content:"\f38d"}.ion-tennisball:before{content:"\f38e"}.ion-text:before{content:"\f38f"}.ion-thermometer:before{content:"\f390"}.ion-thumbs-down:before{content:"\f391"}.ion-thumbs-up:before{content:"\f392"}.ion-thunderstorm:before{content:"\f393"}.ion-time:before{content:"\f394"}.ion-timer:before{content:"\f395"}.ion-today:before{content:"\f17d"}.ion-train:before{content:"\f396"}.ion-transgender:before{content:"\f397"}.ion-trash:before{content:"\f398"}.ion-trending-down:before{content:"\f399"}.ion-trending-up:before{content:"\f39a"}.ion-trophy:before{content:"\f39b"}.ion-tv:before{content:"\f17f"}.ion-umbrella:before{content:"\f39c"}.ion-undo:before{content:"\f39d"}.ion-unlock:before{content:"\f39e"}.ion-videocam:before{content:"\f39f"}.ion-volume-high:before{content:"\f123"}.ion-volume-low:before{content:"\f131"}.ion-volume-mute:before{content:"\f3a1"}.ion-volume-off:before{content:"\f3a2"}.ion-walk:before{content:"\f3a4"}.ion-wallet:before{content:"\f18f"}.ion-warning:before{content:"\f3a5"}.ion-watch:before{content:"\f3a6"}.ion-water:before{content:"\f3a7"}.ion-wifi:before{content:"\f3a8"}.ion-wine:before{content:"\f3a9"}.ion-woman:before{content:"\f3aa"}#zym{position:absolute;top:62px;right:15px;background-color:rgba(255,255,255,0.95);box-sizing:border-box;width:400px;font-size:13px}#zym>div{margin:0 15px 15px 15px}#zym>div:first-child{margin-top:15px}#zym>div[name="path"]>span{cursor:default}#zym>div[name="path"]>span:not(:first-child):before{padding:0 8px;font-family:"Ionicons";content:"\f284";color:#09f}#zym>div[name="full"]{margin:0;padding:0}#zym>div>table{width:98%;margin:auto}#zym>div>table>tbody>tr{border-top:1px solid #bdf}#zym>div>table>tbody>tr:last-child{border-bottom:1px solid #bdf}#zym>div>table>tbody>tr.on{color:#000;background-color:#cbedff}#zym>div>table>tbody>tr.on>td:nth-child(1){color:#09f}#zym>div>table>tbody>tr.on>td:nth-child(1):before{content:"\f2b8"}#zym>div>table>tbody>tr>td{cursor:default;line-height:40px}#zym>div>table>tbody>tr>td:nth-child(1){text-align:left;padding-left:12px;color:#999;font-family:"Ionicons";font-size:120%}#zym>div>table>tbody>tr>td:nth-child(1):before{content:"\f380"}#zym>div>table>tbody>tr>td:nth-child(2){overflow:hidden;white-space:nowrap;text-overflow:"";word-wrap:normal;max-width:292px}#zym>div>table>tbody>tr>td:nth-child(2)>input{background-color:transparent;border:none;outline:none;width:100%}#zym>div>table>tbody>tr>td:nth-child(3){text-align:right;padding-right:12px}div.tamper{align-items:center;background-color:rgba(0,0,0,0.7);box-sizing:border-box;cursor:default;display:none;font-size:14px !important;height:100%;justify-content:center;left:0;position:fixed;top:0;text-align:left;width:100%;z-index:999999}div.tamper>div{background-color:white;box-sizing:border-box;padding:1em;width:360px}div.tamper>div.w2{padding:0;width:720px}div.tamper>div.w2>div{padding:10px 20px}div.tamper>div.w2>ul{margin:0;padding:0;display:flex;flex-wrap:wrap;justify-content:center;list-style-type:none;list-style-position:inside}div.tamper>div.w2>ul[id="vlist"]{height:460px;scrollbar-width:none}div.tamper>div.w2>ul[id="vlist"]::-webkit-scrollbar{display:none}div.tamper>div.w2>ul[id="vlist"]>li{width:160px;margin:0px;padding:0px 8px 16px 8px}div.tamper>div.w2>ul[id="vlist"]>li img.pic{display:block;width:160px;height:100px;margin-bottom:5px}div.tamper>div.w2>ul[id="vlist"]>li div.title{white-space:normal;line-height:1.25;display:-webkit-box;overflow:hidden;-webkit-line-clamp:2;-webkit-box-orient:vertical}div.tamper a{color:#333 !important;text-decoration:none}div.tamper h1{font-size:1.8rem;font-weight:400;margin:10px 0 20px 0;text-align:center}div.tamper form{display:block}div.tamper form>div{padding:0.5em 0}div.tamper form>div>div{margin:0.5em 0}div.tamper form>div>div:last-child{margin-bottom:0}div.tamper form label{color:#000}div.tamper form label:first-child{display:block;margin-bottom:0.5em}div.tamper form label:first-child:before{content:"\00bb";margin:0 0.25em}div.tamper form label:not(:first-child){display:inline}div.tamper form input{box-shadow:none;color:#000}div.tamper form input[type="text"]{background-color:#fff;border:1px solid #ddd;box-sizing:border-box;display:block;font-size:1em;padding:0.5em;width:100%}div.tamper form input[type="text"]:focus{border:1px solid #59c1f0}div.tamper form input[type="password"]{background-color:#fff;border:1px solid #ddd;box-sizing:border-box;display:block;font-size:1em;padding:0.5em;width:100%}div.tamper form input[type="password"]:focus{border:1px solid #59c1f0}div.tamper form input[type="radio"],div.tamper form input[type="checkbox"]{display:inline-block !important;height:1em;margin-right:0.25em;width:1em}div.tamper form input[type="checkbox"]{-webkit-appearance:checkbox !important}div.tamper form input[type="radio"]{-webkit-appearance:radio !important}div.tamper ul{margin:0;padding:0;list-style-type:none;list-style-position:inside;max-height:500px;overflow-y:auto;scrollbar-width:none}div.tamper ul>li{box-sizing:content-box;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:0.25em 0;cursor:default}div.tamper ul>li.on{color:#f45a8d}div.summary{color:#666}div.btn-group{box-sizing:border-box;display:inline-flex}div.btn-group.full{display:flex}div.btn-group.outline>button{background-color:#fff;border:1px solid #ccc;color:#000}div.btn-group.outline>button:hover{color:#ffffff;background-color:#000;border-color:#000}div.btn-group.outline>button:not(:first-child){border-left:none}div.btn-group>button{background-color:#666;border-radius:0;border:none;color:#fff;display:inline-block;flex:1 1 auto;margin:0;outline:none;padding:0.5em 1.25em;position:relative;font-size:inherit}div.btn-group>button:hover{background-color:#000}div.btn-group>button:first-child{border-bottom-left-radius:0.25rem;border-top-left-radius:0.25rem}div.btn-group>button:last-child{border-bottom-right-radius:0.25rem;border-top-right-radius:0.25rem}.mt1{margin-top:10px !important}@keyframes spinner{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}.spinner{animation-name:spinner;animation-duration:2400ms;animation-timing-function:linear;animation-iteration-count:infinite}`), location.hostname.includes("baidu.com")) {
    function dscan(str) {
      let xhr = new XMLHttpRequest();
      xhr.open("GET", "https://pan.baidu.com/rest/2.0/xpan/multimedia?method=listall&web=0&recursion=1&path=" + encodeURI(str), false), xhr.send();
      let d = JSON.parse(xhr.responseText);
      return 0 == d.errno || (d.list = []), d.list;
    }
    function flink() {
      if (ipod.idle) {
        console.clear();
        let arr = ipod.dcontext.instanceForSystem.list.getSelected().reduce((d, t) => (t.isdir ? d = d.concat(dscan(t.path)) : d.push(t), d), []).filter(t => !t.isdir).map(t => t.fs_id);
        fetch(`https://pan.baidu.com/rest/2.0/xpan/multimedia?method=filemetas&dlink=1&fsids=${JSON.stringify(arr)}`).then(r => r.json()).then(d => {
          0 == d.errno ? (ipod.idle = 0, ipod.icon.className = "ion-refresh spinner", ipod.len = d.list.length, ipod.idx = 0, ipod.list = [], d.list.forEach(t => {
            GM_xmlhttpRequest({
              url: t.dlink,
              method: "GET",
              headers: {
                Range: "bytes=0-" + (262144 > t.size ? t.size - 1 : 262143),
                "User-Agent": "LogStatistic"
              },
              responseType: "arraybuffer",
              onload(r) {
                if (r.statusText.includes("Intercepted")) {
                  ipod.idle = 1, ipod.icon.className = "ion-falsh";
                  let dom = ipod.icon.closest("button");
                  "idm" == dom.getAttribute("name") || dom.setAttribute("name", "idm"), console.log("%c\u8bf7\u5728IDM\u4e0b\u8f7d\u8f6f\u4ef6\u8bbe\u7f6e\u91cc\u5173\u95ed\u6355\u83b7\u6d4f\u89c8\u5668\u4e0b\u8f7d", "color:#900");
                } else {
                  if (t.a = r.responseHeaders.match(/content-md5: ([\da-f]{32})/i)[1], 262144 > t.size) t.b = t.a; else {
                    let spark = new SparkMD5.ArrayBuffer();
                    spark.append(r.response), t.b = spark.end();
                  }
                  ipod.list.push([t.a, t.b, t.size, u.namefix(t.filename)].join("#")), ipod.idx++, ipod.idx == ipod.len && (ipod.idle = 1, ipod.icon.className = "ion-flash", GM_setClipboard(ipod.list.join("\r\n"), "text"));
                }
              }
            });
          })) : alert("\u6cb3\u87f9\u51fa\u6ca1");
        });
      }
    }
    function dlink() {
      if (ipod.idle) {
        console.clear();
        let ffail = ["\u4ee5\u4e0b\u6587\u4ef6\u4e0b\u8f7d\u5931\u8d25"], arr = ipod.dcontext.instanceForSystem.list.getSelected().reduce((d, t) => (t.isdir ? d = d.concat(dscan(t.path)) : d.push(t), d), []).filter(t => !t.isdir).map(t => t.fs_id);
        fetch(`https://pan.baidu.com/rest/2.0/xpan/multimedia?method=filemetas&dlink=1&fsids=${JSON.stringify(arr)}`).then(r => r.json()).then(d => {
          0 == d.errno ? (ipod.idle = 0, ipod.icon.className = "ion-refresh spinner", ipod.len = d.list.length, ipod.idx = 0, d.list.forEach(t => {
            GM_xmlhttpRequest({
              url: t.dlink,
              method: "GET",
              headers: {
                Range: "bytes=0-" + (262144 > t.size ? t.size - 1 : 262143),
                "User-Agent": "LogStatistic"
              },
              responseType: "arraybuffer",
              onload(r) {
                if (r.statusText.includes("Intercepted")) {
                  ipod.idle = 1, ipod.icon.className = "ion-download";
                  let dom = ipod.icon.closest("button");
                  "idm" == dom.getAttribute("name") || dom.setAttribute("name", "idm"), console.log("%c\u8bf7\u5728IDM\u4e0b\u8f7d\u8f6f\u4ef6\u8bbe\u7f6e\u91cc\u5173\u95ed\u6355\u83b7\u6d4f\u89c8\u5668\u4e0b\u8f7d", "color:#900");
                } else {
                  if (t.a = r.responseHeaders.match(/content-md5: ([\da-f]{32})/i)[1], 262144 > t.size) t.b = t.a; else {
                    let spark = new SparkMD5.ArrayBuffer();
                    spark.append(r.response), t.b = spark.end();
                  }
                  GM_xmlhttpRequest({
                    url: `${ipod.home}/ajax?act=bdlink`,
                    method: "POST",
                    responseType: "json",
                    headers: {
                      "Content-type": "application/x-www-form-urlencoded"
                    },
                    data: u.serialize({
                      version: ipod.version,
                      host: ipod.aria2.host,
                      uid: ipod.bduid,
                      cookie: ipod.cookie,
                      list: JSON.stringify([t])
                    }),
                    onload(r) {
                      let d = r.response;
                      if (undefined == d) ffail.push(t.path); else switch (d.code) {
                       case 0:
                        console.log("%c%s", "color:#090", t.path), u.aria2(d.list.map(t => (t.dir = ipod.aria2.dir, t.out = u.namefix(t.out.replace(/\s+\/\s+/g, "/")), t)));
                        break;
                       default:
                        console.log("%c%s", "color:#009", d.message);
                      }
                      ipod.idx++, ipod.idx == ipod.len && (ipod.idle = 1, ipod.icon.className = "ion-download", ffail.length > 1 && alert(ffail.join("\n")));
                    }
                  });
                }
              }
            });
          })) : alert("\u6cb3\u87f9\u51fa\u6ca1");
        });
      }
    }
    function zyminit() {
      ipod.zym = {
        num: 0,
        size: 0,
        path: "/"
      }, document.querySelector("#layoutApp").insertAdjacentHTML("beforeend", '<div id="zym"><div class="btn-group outline"><button name="fnew"><i class="ion-instagram"></i> \u65b0\u5efa\u76ee\u5f55</button><button name="frm"><i class="ion-close-circle-outline"></i> \u5220\u9664</button><button name="fin"><i class="ion-log-in"></i> \u5b58\u5165</button><button name="fout"><i class="ion-log-out"></i> \u53d6\u51fa</button></div><div style="text-align: right">\u5df2\u7528\u5bb9\u91cf\uff1a <span name="usize">0</span> &nbsp; </div><div name="path"></div><div name="full"><table><thead><tr><td width="36"></td><td></td><td width="72"></td></tr></thead><tbody id="fli"></tbody></table></div></div>');
      let dom = document.querySelector("#zym > div[name=full]");
      dom.style.cssText = "height:" + (globalThis.innerHeight - dom.offsetTop) + "px", document.querySelector("#fli").addEventListener("click", () => {
        let dom = u.zdom(1);
        switch (ipod.checkbox = dom.parentElement, dom.cellIndex) {
         default:
          u.swClassName("on");
          break;
         case 1:
          0 == ipod.checkbox.getAttribute("data-fid") ? (ipod.zym.path += "/" + dom.innerText, zymfli(ipod.zym.path)) : u.swClassName("on");
        }
      }), document.querySelector("#zym > div.btn-group").addEventListener("click", () => {
        let list, dom = u.zdom(1);
        switch ("I" == dom.tagName && (dom = dom.parentElement), ipod.icon = dom.children[0], dom.getAttribute("name")) {
         case "fnew":
          document.querySelector("#fli").insertAdjacentHTML("afterbegin", '<tr data-fid="0"><td></td><td><input name="filename" type="text" placeholder="\u8bf7\u8f93\u5165\u76ee\u5f55\u540d\u79f0"></td><td></td></tr>');
          let dom = document.querySelector("#fli input");
          dom.focus(), dom.addEventListener("keypress", e => {
            if (13 == e.charCode) {
              let s = e.target.value;
              "" == s ? e.target.closest("tr").remove() : GM_xmlhttpRequest({
                method: "POST",
                responseType: "json",
                url: `${ipod.home}/ajax?act=fnew`,
                headers: {
                  "Content-type": "application/x-www-form-urlencoded"
                },
                data: u.serialize({
                  uid: ipod.bduid,
                  cookie: ipod.cookie,
                  path: ipod.zym.path,
                  name: s
                }),
                onload(r) {
                  let d = r.response;
                  if (0 == d.code) {
                    let dom = e.target.parentElement;
                    e.target.remove(), dom.innerText = s;
                    let arr = JSON.parse(localStorage.getItem("fli"));
                    arr.unshift({
                      id: d.message,
                      fid: 0,
                      fsize: "",
                      name: s,
                      path: ipod.zym.path,
                      size: 0
                    }), localStorage.setItem("fli", JSON.stringify(arr));
                  }
                }
              });
            }
          });
          break;
         case "fin":
          if (ipod.idle) {
            let arr = ipod.dcontext.instanceForSystem.list.getSelected().reduce((d, t) => (t.isdir || d.push(t), d), []).map(t => t.fs_id);
            arr.length && fetch("https://pan.baidu.com/rest/2.0/xpan/multimedia?method=filemetas&dlink=1&fsids=" + JSON.stringify(arr)).then(r => r.json()).then(d => {
              0 == d.errno && (ipod.idle = 0, ipod.icon.className = "ion-refresh spinner", ipod.idx = 0, ipod.list = [], ipod.len = d.list.length, d.list.forEach(t => {
                t.path = t.path.replaceAll("#", ""), GM_xmlhttpRequest({
                  url: t.dlink,
                  method: "GET",
                  headers: {
                    Range: "bytes=0-" + (262144 > t.size ? t.size - 1 : 262143),
                    "User-Agent": "LogStatistic"
                  },
                  responseType: "arraybuffer",
                  onload(r) {
                    if (r.statusText.includes("Intercepted")) ipod.idle = 1, ipod.icon.className = "ion-log-in", console.log("\u8bf7\u5728IDM\u4e0b\u8f7d\u8f6f\u4ef6\u8bbe\u7f6e\u91cc\u5173\u95ed\u6355\u83b7\u6d4f\u89c8\u5668\u4e0b\u8f7d"); else {
                      let b, a = r.responseHeaders.match(/content-md5: ([\da-f]{32})/i)[1], spark = new SparkMD5.ArrayBuffer();
                      262144 > t.size ? b = a : (spark.append(r.response), b = spark.end()), ipod.list.push({
                        a,
                        b,
                        fid: t.fs_id,
                        name: t.filename,
                        size: t.size
                      }), ipod.idx++, ipod.idx == ipod.len && GM_xmlhttpRequest({
                        method: "POST",
                        responseType: "json",
                        url: `${ipod.home}/ajax?act=fin`,
                        headers: {
                          "Content-type": "application/x-www-form-urlencoded"
                        },
                        data: u.serialize({
                          uid: ipod.bduid,
                          cookie: ipod.cookie,
                          path: ipod.zym.path,
                          list: JSON.stringify(ipod.list)
                        }),
                        onload(r) {
                          ipod.idle = 1, ipod.icon.className = "ion-log-in";
                          let d = r.response;
                          if (0 == d.code) {
                            let arr = JSON.parse(localStorage.getItem("fli"));
                            localStorage.setItem("fli", JSON.stringify(arr.concat(d.list.map(t => (ipod.zym.size += Math.ceil(t.size / 1e6), t.fsize = u.fsize(t.size), t))))), zymfli(ipod.zym.path), document.querySelector("span[name=usize]").innerText = u.fsize(ipod.zym.size, 2);
                          } else alert(d.message);
                        }
                      });
                    }
                  }
                });
              }));
            });
          }
          break;
         case "fout":
          ipod.idle && (list = [], document.querySelectorAll("#zym tr.on").forEach(t => {
            "0" == t.getAttribute("data-fid") || list.push(t.getAttribute("data-id"));
          }), list.length && (ipod.idle = 0, ipod.icon.className = "ion-refresh spinner", GM_xmlhttpRequest({
            method: "POST",
            responseType: "json",
            url: `${ipod.home}/ajax?act=fout`,
            headers: {
              "Content-type": "application/x-www-form-urlencoded"
            },
            data: u.serialize({
              uid: ipod.bduid,
              cookie: ipod.cookie,
              list: JSON.stringify(list)
            }),
            onload(r) {
              let d = r.response;
              0 == d.code ? (ipod.idx = 0, ipod.len = d.list.length, ipod.path = (ipod.dcontext.instanceForSystem.list.getCurrentPath() + "/").replaceAll("//", "/"), d.list.forEach(t => {
                t.path = ipod.path + t.name, fetch(`/api/rapidupload?bdstoken=${ipod.bdstoken}`, {
                  headers: {
                    "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
                  },
                  method: "POST",
                  mode: "cors",
                  credentials: "include",
                  body: `rtype=0&path=${t.path}&content-md5=${t.a}&slice-md5=${t.b}&content-length=${t.size}`
                }).then(r => r.json()).then(() => {
                  ipod.idx++, ipod.idx == ipod.len && (ipod.dmessage.trigger("system-refresh"), ipod.idle = 1, ipod.icon.className = "ion-log-out");
                });
              })) : alert(d.message);
            }
          })));
          break;
         case "frm":
          list = [], document.querySelectorAll("#zym tr.on").forEach(t => {
            "0" == t.getAttribute("data-fid") || list.push(+t.getAttribute("data-id"));
          }), list.length && GM_xmlhttpRequest({
            method: "POST",
            responseType: "json",
            url: `${ipod.home}/ajax?act=frm`,
            headers: {
              "Content-type": "application/x-www-form-urlencoded"
            },
            data: u.serialize({
              uid: ipod.bduid,
              cookie: ipod.cookie,
              list: JSON.stringify(list)
            }),
            onload(r) {
              let d = r.response;
              if (0 == d.code) {
                let arr = JSON.parse(localStorage.getItem("fli"));
                arr = arr.filter(t => {
                  let reply = true;
                  return list.includes(t.id) && (reply = false, ipod.zym.size -= Math.ceil(t.size / 1e6)), reply;
                }), localStorage.setItem("fli", JSON.stringify(arr)), zymfli(ipod.zym.path), document.querySelector("span[name=usize]").innerText = u.fsize(ipod.zym.size, 2);
              } else alert(d.message);
            }
          });
        }
      }), document.querySelector("#zym > div[name=path]").addEventListener("click", () => {
        let dom = u.zdom(1);
        "SPAN" == dom.tagName && zymfli(dom.getAttribute("data-path"));
      }), GM_xmlhttpRequest({
        method: "POST",
        responseType: "json",
        url: `${ipod.home}/ajax?act=flist&t=${ipod.now}`,
        headers: {
          "Content-type": "application/x-www-form-urlencoded"
        },
        data: u.serialize({
          uid: ipod.bduid,
          cookie: ipod.cookie
        }),
        onload(r) {
          let d = r.response;
          if (0 == d.code) {
            ipod.zym.num = d.list.length;
            let arr = d.list.map(t => (ipod.zym.size += Math.ceil(t.size / 1e6), t.fsize = u.fsize(t.size), t));
            localStorage.setItem("fli", JSON.stringify(arr)), document.querySelector("span[name=usize]").innerText = u.fsize(ipod.zym.size, 2), zymfli("/");
          }
        }
      });
    }
    function zymfli(str) {
      ipod.zym.path = str.replaceAll("//", "/");
      let a, b = "", s = '<span data-path="/">root</span>';
      if (ipod.zym.path.length > 1) {
        let arr = ipod.zym.path.split("/").slice(1).map(t => (b += "/" + t, a = t.replaceAll(/\s+/g, "").substring(0, 6), `<span data-path="${b}">${a}</span>`));
        arr.length > 3 && (arr = arr.slice(arr.length - 3)), s += arr.join("");
      }
      document.querySelector("#zym > div[name=path]").innerHTML = s;
      let arr = JSON.parse(localStorage.getItem("fli")).filter(t => t.path == ipod.zym.path);
      arr.length ? (arr.sort((a, b) => a.name > b.name ? 1 : b.name > a.name ? -1 : 0).sort((a, b) => 0 == a.size ? 0 : 0 == b.size ? 1 : 0), document.querySelector("#fli").innerHTML = u.tpl(ipod.tpl.fli, arr)) : document.querySelector("#fli").innerHTML = "";
    }
    function zymsw() {
      let dom = document.querySelector("#layoutMain");
      dom && (dom.style.cssText = "width:" + (dom.offsetWidth - 420) + "px"), (dom = document.querySelector("#zym")) ? dom.style.cssText = "display:block" : zyminit();
    }
    if (ipod.tpl = {
      fli: '<tr data-id="[id]" data-fid="[fid]"><td></td><td>[name]</td><td>[fsize]</td></tr>'
    }, ipod.defaults = {
      host: 1,
      token: "",
      jsonrpc: "http://127.0.0.1:16800/jsonrpc",
      dir: "D:/HD2A"
    }, ipod.aria2 = u.load("aria2", ipod.defaults), "/disk/home" == location.pathname) GM_addStyle(String.raw`#layoutMain>div:nth-child(2)>div:nth-child(3)>div{scrollbar-width:none}#layoutMain>div:nth-child(2)>div:nth-child(3)>div::-webkit-scrollbar{display:none}`), GM_cookie.list({}, r => {
      let arr = r.length ? u.cclean(r).reduce((d, t1) => (["BDUSS=", "STOKEN="].some(t2 => t1.includes(t2)) && d.push(t1), d), []) : [];
      arr.length ? (arr.sort(), ipod.cookie = arr.join(";"), ipod.dcontext = unsafeWindow.require("system-core:context/context.js"), ipod.dmessage = unsafeWindow.require("system-core:system/baseService/message/message.js"), ipod.bdstoken = unsafeWindow.locals.get("bdstoken"), ipod.bduid = unsafeWindow.locals.get("uk"), GM_getValue("bduid") == ipod.bduid || GM_setValue("bduid", ipod.bduid), GM_xmlhttpRequest({
        url: `${ipod.home}/ajax?act=vlist&t=${ipod.now}`,
        method: "GET",
        responseType: "json",
        onload(r) {
          document.body.insertAdjacentHTML("beforeend", '<div class="tamper" id="vpanel"><div class="w2"><div>\u7ed9\u89c6\u9891\u70b9\u8d5e\u6536\u85cf\u6295\u5e01\u5747\u53ef\u83b7\u5f97\u89e3\u6790\u4e0b\u8f7d\u4f7f\u7528\u6b21\u6570 &nbsp; \u4f60\u73b0\u5728\u7684\u53ef\u7528\u6b21\u6570\uff1a<span name="uut"></span> &nbsp; \u4ea4\u6d41\u7fa4\uff1a87095249</div><ul id="vlist"></ul></div></div>'), document.querySelector("#vpanel").addEventListener("click", e => {
            "vpanel" == e.target.id && (e.target.style.cssText = "");
          }), 0 == r.response.code && document.querySelector("#vlist").insertAdjacentHTML("afterbegin", u.tpl('<li><a href="[url]" target="_blank"><div><img class="pic" src="[pic]"></div><div class="title">[title]</div></a></li>', r.response.list));
        }
      }), ipod.task = setInterval(() => {
        let dom = document.querySelector("div[node-type=listTopTools]");
        dom && (clearInterval(ipod.task), dom.innerHTML = '<div class="btn-group outline" style="font-size: 12.5px"><button name="zspace"><i class="ion-paw"></i> \u6b21\u5143\u95e8</button><button name="video"><i class="ion-heart"></i> \u70b9\u8d5e</button><button name="flink"><i class="ion-flash"></i> \u79d2\u4f20</button><button name="zset"><i class="ion-settings"></i> \u8bbe\u7f6e</button><button name="dlink"><i class="ion-download"></i> \u4e0b\u8f7d</button></div>', document.querySelector("div.btn-group.outline").addEventListener("click", () => {
          let dom = u.zdom(1);
          switch ("I" == dom.tagName && (dom = dom.parentElement), dom.getAttribute("name")) {
           case "zspace":
            dom.hasAttribute("style") ? (dom.removeAttribute("style"), document.querySelector("#layoutMain").removeAttribute("style"), document.querySelector("#zym").style.cssText = "display: none") : (dom.style.cssText = "color:#fff;background-color:#09aaff;border-color:#09aaff", zymsw());
            break;
           case "video":
            ipod.idle && (ipod.idle = 0, GM_xmlhttpRequest({
              method: "POST",
              responseType: "json",
              url: `${ipod.home}/ajax?act=bdunum`,
              headers: {
                "Content-type": "application/x-www-form-urlencoded"
              },
              data: u.serialize({
                uid: ipod.bduid,
                cookie: ipod.cookie
              }),
              onload(r) {
                ipod.idle = 1, document.querySelector("#vpanel span[name=uut]").innerText = r.response.message, document.querySelector("#vpanel").style.cssText = "display: flex";
              }
            }));
            break;
           case "zset":
            zset();
            break;
           case "flink":
            ipod.icon = dom.children[0], flink();
            break;
           case "idm":
            alert("1. \u8bf7\u5728IDM\u4e0b\u8f7d\u8f6f\u4ef6\u8bbe\u7f6e\u91cc\u5173\u95ed\u6355\u83b7\u6d4f\u89c8\u5668\u4e0b\u8f7d\n2. \u6309F5\u5237\u65b0\u9875\u9762");
            break;
           default:
            ipod.icon = dom.children[0], dlink();
          }
        }));
      }, 1e3)) : alert("\u8bf7\u5c1d\u8bd5\u66f4\u6362\u811a\u672c\u7ba1\u7406\u5668\u4e3a Tampermonkey Beta");
    }); else if ("/disk/main" == location.pathname && location.hash.startsWith("#/index")) {
      let s = u.strcut(location.hash, "path=", "&");
      location.href = `//pan.baidu.com/disk/home?stayAtHome=true#/all?path=${s}`;
    } else console.log(location.href);
  }
  if (location.hostname.includes("bilibili.com")) {
    function bzinit() {
      location.pathname.startsWith("/video") && (ipod.task = setInterval(() => {
        if (!document.querySelector("#app").hasAttribute("data-server-rendered")) {
          clearInterval(ipod.task);
          let bvid = u.strcut(location.pathname, "/video/", "/");
          bvid.startsWith("BV") && fetch(`https://api.bilibili.com/x/web-interface/view?bvid=${bvid}`, {
            method: "GET",
            mode: "cors",
            credentials: "include"
          }).then(r => r.json()).then(d => {
            0 == d.code && (ipod.vi = {
              bduid: ipod.bduid,
              sign: ipod.sign,
              uid: d.data.owner.mid,
              uname: d.data.owner.name,
              vid: d.data.bvid,
              title: d.data.title,
              pic: d.data.pic
            }, document.querySelector("#baiduyun") || (document.querySelector("#arc_toolbar_report > div:nth-child(2)").insertAdjacentHTML("afterbegin", '<span class="appeal-text" id="baiduyun" style="margin-right:2em">\u767e\u5ea6\u4e91\u5206\u4eab</span>'), document.querySelector("#baiduyun").addEventListener("click", () => {
              ipod.now > ipod.latest2 ? GM_xmlhttpRequest({
                method: "POST",
                url: `${ipod.home}/ajax?act=bzshare`,
                responseType: "json",
                headers: {
                  "Content-type": "application/x-www-form-urlencoded"
                },
                data: u.serialize(ipod.vi),
                onload(r) {
                  let d = r.response;
                  switch (d.code) {
                   case 0:
                    ipod.latest2 = ipod.now + 6e4, u.save("latest2", ipod.latest2);
                    break;
                   case 9:
                    location.href = d.message;
                    break;
                   default:
                    alert(d.message);
                  }
                }
              }) : alert("\u6bcf\u5929\u53ea\u80fd\u5206\u4eab\u4e00\u4e2a\u89c6\u9891");
            })));
          });
        }
      }, 2e3));
    }
    ipod.bduid = GM_getValue("bduid"), ipod.sign = u.load("sign", null), ipod.latest1 = u.load("latest1", 0), ipod.latest2 = u.load("latest2", 0), ipod.mid = document.cookie.includes("DedeUserID") ? Number.parseInt(u.strcut(document.cookie, "DedeUserID=", ";")) : 0, ipod.bduid && ipod.mid && (ipod.now > ipod.latest1 && (ipod.latest1 = ipod.now + 3e3, u.save("latest1", ipod.latest1), GM_cookie.list({}, r => {
      let arr = r.length ? u.cclean(r) : [];
      arr.length && (arr.sort(), ipod.cookie = arr.join(";"), fetch("https://api.bilibili.com/x/web-interface/nav", {
        method: "GET",
        mode: "cors",
        credentials: "include"
      }).then(r => r.json()).then(d => {
        ipod.ui = 0 == d.code ? {
          mid: d.data.mid,
          fti: localStorage.getItem("html5PlayerServerTime"),
          cookie: ipod.cookie
        } : null, ipod.sign = btoa(JSON.stringify(ipod.ui)), u.save("sign", ipod.sign);
      }));
    })), location.pathname.startsWith("/video/BV") && (unsafeWindow.XMLHttpRequest = new Proxy(XMLHttpRequest, {
      construct(target) {
        let pod = {};
        return new Proxy(new target(), {
          set: (target, prop, value) => (target[prop] = value, true),
          get(target, prop) {
            if (pod.hasOwnProperty(prop)) return pod[prop];
            let value = target[prop];
            if ("function" == typeof value) {
              let bc = value;
              value = function() {
                if ("open" == prop) pod.method = arguments[0], pod.url = arguments[1]; else if ("send" == prop) if (pod.url.includes("/x/web-interface/archive/like")) {
                  let d = u.usp(arguments[0]);
                  ipod.vi.uact = 1 == d.like ? 1 : 0, GM_xmlhttpRequest({
                    method: "POST",
                    responseType: "json",
                    url: `${ipod.home}/ajax?act=bzuact`,
                    headers: {
                      "Content-type": "application/x-www-form-urlencoded"
                    },
                    data: u.serialize(ipod.vi),
                    onload(r) {
                      console.log(r.response);
                    }
                  });
                } else if (pod.url.includes("/x/v3/fav/resource/deal")) {
                  let d = u.usp(arguments[0]);
                  ipod.vi.uact = "" == d.add_media_ids ? 0 : 2, GM_xmlhttpRequest({
                    method: "POST",
                    responseType: "json",
                    url: `${ipod.home}/ajax?act=bzuact`,
                    headers: {
                      "Content-type": "application/x-www-form-urlencoded"
                    },
                    data: u.serialize(ipod.vi),
                    onload(r) {
                      console.log(r.response);
                    }
                  });
                } else pod.url.includes("/x/web-interface/coin/add") && (ipod.vi.uact = 3, GM_xmlhttpRequest({
                  method: "POST",
                  responseType: "json",
                  url: `${ipod.home}/ajax?act=bzuact`,
                  headers: {
                    "Content-type": "application/x-www-form-urlencoded"
                  },
                  data: u.serialize(ipod.vi),
                  onload(r) {
                    console.log(r.response);
                  }
                }));
                return bc.apply(target, arguments);
              };
            }
            return value;
          }
        });
      }
    })), history.pushState = u.history("pushState"), unsafeWindow.addEventListener("pushState", bzinit), history.replaceState = u.history("replaceState"), unsafeWindow.addEventListener("replaceState", bzinit), bzinit());
  }
}();
