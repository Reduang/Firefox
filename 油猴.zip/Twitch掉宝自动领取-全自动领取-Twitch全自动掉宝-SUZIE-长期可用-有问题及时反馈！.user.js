// ==UserScript==
// @name         Twitch掉宝自动领取/全自动领取/Twitch全自动掉宝/SUZIE/长期可用/有问题及时反馈！
// @version      1.2
// @description  自动领取掉宝库存页面奖励（此脚本由其他作者开源）
// @author       小黑盒：SUZIE 抖音：SUZIE
// @match        https://www.twitch.tv/drops/inventory*
// @icon         https://imgheybox.max-c.com/avatar/2021/11/09/f93babd9c2e98dadd71849435f90cb51.jpeg
// @run-at       document-end
// @namespace    https://xiaoheihe.cn/community/7216/list/83188884
// ==/UserScript==

const claimButton = '[data-test-selector="DropsCampaignInProgressRewardPresentation-claim-button"]';
var onMutate = function(mutationsList) {
	mutationsList.forEach(mutation => {
		if(document.querySelector(claimButton)) document.querySelector(claimButton).click();
	})
}
var observer = new MutationObserver(onMutate);
observer.observe(document.body, {childList: true, subtree: true});

setInterval(function() {
                  window.location.reload();
                }, 1*60000); 
