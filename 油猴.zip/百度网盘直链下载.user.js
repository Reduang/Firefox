// ==UserScript==
// @namespace greasyfork
// @name 百度网盘直链下载
// @version 0.1.20
// @description 搭配Motrix使用无需svip满速下载
// @license GPL
// @match https://pan.baidu.com/disk/*
// @match https://www.bilibili.com/video/*
// @connect baidu.com
// @connect baidupcs.com
// @connect bilibili.com
// @connect 121.5.226.51
// @connect 127.0.0.1
// @grant GM_addStyle
// @grant GM_info
// @grant GM_cookie
// @grant GM_getValue
// @grant GM_setValue
// @grant GM_setClipboard
// @grant GM_xmlhttpRequest
// @grant unsafeWindow
// @run-at document-end
// ==/UserScript==
void function() {
  function zset() {
    if (u.zdom(), document.querySelector("#zyset")) ipod.aria2 && u.zform("#zyset input", ipod.aria2), document.querySelector("#zyset").style.cssText = "display: flex"; else {
      let str;
      switch (u.zhost()) {
       case "baidu.com":
        str = '<div class="tamper" id="zyset"><div><form><div><label>\u8282\u70b9\u9009\u62e9</label><input name="host" type="radio" value="1"><label>\u81ea\u52a8\u9002\u5e94 &nbsp; </label><input name="host" type="radio" value="2"><label>\u9655\u897f\u8054\u901a &nbsp; </label><input name="host" type="radio" value="3"><label>\u4e91\u5357\u8054\u901a &nbsp; </label><input name="host" type="radio" value="4"><label>\u6e56\u5357\u7535\u4fe1</label></div><div><label>\u8bbe\u7f6e aria2 jsonrpc</label><input name="jsonrpc" type="text"></div><div><label>\u8bbe\u7f6e aria2 \u8bbf\u95ee\u53e3\u4ee4</label><input name="token" type="password" placeholder="\u6ca1\u6709\u53e3\u4ee4\u5219\u4e0d\u8981\u586b\u5199"></div><div><label>\u8bbe\u7f6e\u4e0b\u8f7d\u4fdd\u5b58\u8def\u5f84</label><input name="dir" type="text"><div class="summary"> \u8bf7\u4f7f\u7528\u5de6\u659c\u6760\u4f5c\u4e3a\u5206\u9694\u7b26</div></div><div class="btn-group"><button type="button"><i class="ion-close"></i> \u53d6\u6d88</button><button type="submit"><i class="ion-checkmark"></i> \u786e\u5b9a</button></div></form></div></div>';
        break;
       case "youtube.com":
        str = '<div class="tamper" id="zyset"><div><form><div><input name="mode" type="checkbox" value="1"><label>\u4f7f\u7528\u6d4f\u89c8\u5668\u76f4\u63a5\u4e0b\u8f7d\u800c\u975eAria2</label><div class="summary">\u4e0d\u77e5\u9053\u5982\u4f55\u8bbe\u7f6e\u4ee3\u7406\u670d\u52a1\u5668\u8bf7\u52fe\u9009\u6d4f\u89c8\u5668\u4e0b\u8f7d</div></div><div><label>\u8bbe\u7f6e aria2 jsonrpc</label><input name="jsonrpc" type="text"></div><div><label>\u8bbe\u7f6e aria2 \u8bbf\u95ee\u53e3\u4ee4</label><input name="token" type="password" placeholder="\u6ca1\u6709\u53e3\u4ee4\u5219\u4e0d\u8981\u586b\u5199"></div><div><label>\u8bbe\u7f6e\u4ee3\u7406\u670d\u52a1\u5668</label><input name="proxy" type="text" placeholder="\u4e0d\u4f7f\u7528\u4ee3\u7406\u5219\u7559\u7a7a"><div class="summary">\u4e0d\u9700\u8981\u901a\u8fc7\u4ee3\u7406\u670d\u52a1\u5668\u4e0b\u8f7d\u5219\u5c06\u6b64\u8bbe\u7f6e\u6e05\u7a7a</div></div><div><label>\u8bbe\u7f6e\u4e0b\u8f7d\u4fdd\u5b58\u8def\u5f84</label><input name="dir" type="text"></div><div class="btn-group"><button type="button"><i class="ion-close"></i> \u53d6\u6d88</button><button type="submit"><i class="ion-checkmark"></i> \u786e\u5b9a</button></div></form></div></div>';
        break;
       default:
        str = '<div class="tamper" id="zyset"><div><form><div><label>\u8bbe\u7f6e aria2 jsonrpc</label><input name="jsonrpc" type="text"></div><div><label>\u8bbe\u7f6e aria2 \u8bbf\u95ee\u53e3\u4ee4</label><input name="token" type="password" placeholder="\u6ca1\u6709\u53e3\u4ee4\u5219\u4e0d\u8981\u586b\u5199"></div><div><label>\u8bbe\u7f6e\u4e0b\u8f7d\u4fdd\u5b58\u8def\u5f84</label><input name="dir" type="text"></div><div class="btn-group"><button type="button"><i class="ion-close"></i> \u53d6\u6d88</button><button type="submit"><i class="ion-checkmark"></i> \u786e\u5b9a</button></div></form></div></div>';
      }
      document.body.insertAdjacentHTML("beforeend", str), ipod.aria2 && u.zform("#zyset input", ipod.aria2), document.querySelector("#zyset").style.cssText = "display: flex", document.querySelector("#zyset button[type=button]").addEventListener("click", () => {
        u.zdom(), document.querySelector("#zyset").style.cssText = "display: none";
      }), document.querySelector("#zyset form").addEventListener("submit", () => {
        let dom = u.zdom(), d = new FormData(dom);
        ipod.aria2 = Object.assign({}, ipod.defaults, Object.fromEntries(d.entries())), u.save("aria2", ipod.aria2), document.querySelector("#zyset").style.cssText = "display: none";
      });
    }
  }
  const u = {
    now: () => Math.floor(Date.now() / 1e3),
    uid: () => Date.now().toString(36).toUpperCase(),
    zhost: () => location.hostname.split(".").slice(-2).join("."),
    rand: max => Math.floor(1e3 * Math.random()) % max,
    urlfix: str => str.startsWith("http") ? str : str.startsWith("//") ? location.protocol + str : str.startsWith("/") ? location.origin + str : location.origin + "/" + str,
    usp: str => Object.fromEntries(new URLSearchParams(str).entries()),
    unique: arr => arr.fliter((t, i, d) => d.indexOf(t) == i),
    cclean: arr => Object.entries(Object.fromEntries(arr.map(t => [t.name, t.value]))).map(t => t.join("=")),
    serialize: obj => "object" == typeof obj ? "" + new URLSearchParams(Object.entries(obj)) : "string" == typeof obj ? obj : "" + obj,
    vfunc: fn => "[object Function]" == Object.prototype.toString.call(fn),
    vnum: num => "[object Number]" == Object.prototype.toString.call(num),
    vobj: obj => "[object Object]" == Object.prototype.toString.call(obj),
    vstr: str => "[object String]" == Object.prototype.toString.call(str),
    xpath: str => document.evaluate(str, document).iterateNext(),
    pwd(bit = 4) {
      let i, arr = [];
      for (i = 0; bit > i; i++) arr.push("abcdefghijklmnopqrstuvwxyz23456789ABCDEFGHKLMNPSTVWXY".charAt(u.rand(53)));
      return arr.join("");
    },
    zdom(top = 0) {
      let e = window.event;
      return e.preventDefault(), e.stopPropagation(), top ? e.target : e.currentTarget;
    },
    zinput(dom, str) {
      dom.value = str, dom.hasOwnProperty("_valueTracker") && dom._valueTracker.setValue(""), dom.dispatchEvent(new Event("input", {
        bubbles: !0
      }));
    },
    zero(num, bit = 2) {
      let s, i = +num;
      return (s = isNaN(i) ? "0" : "" + i).padStart(bit, "0");
    },
    fsize(num, idx = 0) {
      let s, t = +num;
      if (0 == t) s = ""; else {
        let i = 0, arr = ["B", "KB", "MB", "GB", "TB", "PB"];
        while (t > 1024) i++, t = Math.ceil(t / 1024);
        s = (t = Math.round(num / Math.pow(1024, i))) + arr[i + idx];
      }
      return s;
    },
    urlopen(url, self) {
      let dom = document.createElement("a");
      dom.setAttribute("href", url), undefined == self && dom.setAttribute("target", "_blank"), dom.click();
    },
    aria2(list) {
      let arr = [], pod = {
        id: u.uid(),
        method: "system.multicall",
        params: []
      };
      list.forEach(t => {
        Object.keys(t).forEach(p => {
          u.vnum(t[p]) && (t[p] = "" + t[p]);
        });
        let o = {
          methodName: "aria2.addUri",
          params: []
        };
        ipod.aria2.token && o.params.push(`token:${ipod.aria2.token}`), o.params.push(t.url), t.hasOwnProperty("split") || (t.split = "" + t.url.length), t.hasOwnProperty("extype") && (t.out = pod.id + t.extype), o.params.push(t), arr.push(o);
      }), pod.params.push(arr), GM_xmlhttpRequest({
        url: ipod.aria2.jsonrpc,
        method: "POST",
        responseType: "json",
        data: JSON.stringify(pod),
        onerror() {
          alert("\u8bf7\u68c0\u67e5Motrix\u662f\u5426\u8fd0\u884c\u4ee5\u53ca\u811a\u672c\u8bbe\u7f6e\u91cc\u586b\u5199\u7684jsonrpc\u662f\u5426\u6b63\u786e");
        }
      });
    },
    aria2config(jsonrpc) {
      let pod = {
        id: u.uid(),
        method: "aria2.changeGlobalOption",
        params: [{
          "allow-overwrite": "false",
          "auto-file-renaming": "false",
          "max-concurrent-downloads": "1"
        }]
      };
      GM_xmlhttpRequest({
        url: jsonrpc,
        method: "POST",
        responseType: "json",
        data: JSON.stringify(pod)
      });
    },
    zform(str, obj) {
      document.querySelectorAll(str).forEach(t => {
        let s = t.getAttribute("name");
        if (obj.hasOwnProperty(s)) {
          let v = obj[s];
          switch (t.getAttribute("type")) {
           case "radio":
            t.checked = v == t.value;
            break;
           case "checkbox":
            t.checked = !!v;
            break;
           default:
            t.value = v;
          }
        }
      });
    },
    domcopy(element) {
      let dom = null;
      return element instanceof HTMLElement && ((dom = element.cloneNode(!0)).setAttribute("data-clone", "true"), element.after(dom), element.remove()), dom;
    },
    domremove(list) {
      list.forEach(t => {
        let dom = t.startsWith("/html/") ? u.xpath(t) : document.querySelector(t);
        null == dom || dom.remove();
      });
    },
    domhide(list) {
      list.forEach(t => {
        let dom = t.startsWith("/html/") ? u.xpath(t) : document.querySelector(t);
        null == dom || (dom.style.cssText = "display: none");
      });
    },
    loread(name, val = "") {
      let s = localStorage.getItem(name);
      return null == s ? val : s;
    },
    losave(name, val) {
      localStorage.setItem(name, val);
    },
    load(name, val = null) {
      name += "." + u.zhost();
      let d = GM_getValue(name, null);
      return null == d ? val : JSON.parse(d);
    },
    save(name, data) {
      name += "." + u.zhost(), GM_setValue(name, JSON.stringify(data));
    },
    strcut(str, a, b) {
      let x, y, s = str;
      return str.includes(a) && (x = str.indexOf(a) + a.length, undefined == b ? y = str.length : -1 == (y = str.indexOf(b, x)) && (y = str.length), s = str.substring(x, y)), s;
    },
    str2obj(str) {
      let o = null;
      return u.vstr(str) && str.length && (o = str.includes('"') ? JSON.parse(str) : JSON.parse(str.replaceAll(/'/g, '"'))), o;
    },
    download(str) {
      if (str) {
        let o = str.startsWith("magnet:") ? {
          url: []
        } : {
          url: [],
          "use-header": "true",
          "min-split-size": "1M",
          split: "8"
        };
        Object.assign(o, ipod.aria2), str = str.startsWith("magnet:") ? u.magnet(str) : str.startsWith("http") ? str : str.startsWith("//") ? location.protocol + str : str.startsWith("/") ? location.origin + str : location.origin + "/" + str, o.url.push(str), u.aria2([o]);
      }
    },
    magnet(str) {
      let i = str.indexOf("&");
      return -1 == i ? str : str.substring(0, i);
    },
    namefix(str) {
      let i, arr = ['"', "'", "*", ":", "<", ">", "?", "|"];
      for (i = 0; arr.length > i; i++) str = str.replaceAll(arr[i], "");
      return str.replaceAll("\\", "/").replaceAll("//", "/");
    },
    tpl: (str, data) => (Array.isArray(data) ? data : [data]).map(t => ((html, obj) => html.replaceAll(/\[(\w{1,16})\]/g, (matched, major) => obj.hasOwnProperty(major) ? obj[major] : major))(str, t)).join(""),
    history(str) {
      const origin = history[str];
      return function() {
        let e = new Event(str);
        return e.arguments = arguments, window.dispatchEvent(e), origin.apply(this, arguments);
      };
    },
    jsload(url, name) {
      let dom = document.createElement("script");
      dom.src = u.urlfix(url), undefined == name || dom.setAttribute("name", name), dom.setAttribute("charset", "utf-8"), dom.setAttribute("crossorigin", "anonymous"), document.head.appendChild(dom);
    },
    swClassName(str) {
      if (str && u.vstr(str)) {
        let arr = Array.from(ipod.checkbox.classList);
        arr.includes(str) ? arr = arr.filter(t => t != str) : arr.push("on"), ipod.checkbox.className = arr.join(" ");
      }
    }
  };
  let ipod = {
    version: GM_info.script.version,
    home: "https://121.5.226.51",
    cookie: "",
    lazy: 0,
    now: u.now()
  };
  if (GM_addStyle(String.raw`@font-face{font-family:"Ionicons";src:url("https://cdn.bootcss.com/ionicons/4.5.6/fonts/ionicons.eot?v=4.5.5#iefix") format("embedded-opentype"),url("https://cdn.bootcss.com/ionicons/4.5.6/fonts/ionicons.woff2?v=4.5.5") format("woff2"),url("https://cdn.bootcss.com/ionicons/4.5.6/fonts/ionicons.woff?v=4.5.5") format("woff"),url("https://cdn.bootcss.com/ionicons/4.5.6/fonts/ionicons.ttf?v=4.5.5") format("truetype"),url("https://cdn.bootcss.com/ionicons/4.5.6/fonts/ionicons.svg?v=4.5.5#Ionicons") format("svg");font-weight:normal;font-style:normal}i[class|=ion]{display:inline-block;font-family:"Ionicons";font-size:120%;font-style:normal;font-variant:normal;font-weight:normal;line-height:1;text-rendering:auto;text-transform:none;vertical-align:text-bottom;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased}.ion-android:before{content:"\f225"}.ion-angular:before{content:"\f227"}.ion-apple:before{content:"\f229"}.ion-bitbucket:before{content:"\f193"}.ion-bitcoin:before{content:"\f22b"}.ion-buffer:before{content:"\f22d"}.ion-chrome:before{content:"\f22f"}.ion-closed-captioning:before{content:"\f105"}.ion-codepen:before{content:"\f230"}.ion-css3:before{content:"\f231"}.ion-designernews:before{content:"\f232"}.ion-dribbble:before{content:"\f233"}.ion-dropbox:before{content:"\f234"}.ion-euro:before{content:"\f235"}.ion-facebook:before{content:"\f236"}.ion-flickr:before{content:"\f107"}.ion-foursquare:before{content:"\f237"}.ion-freebsd-devil:before{content:"\f238"}.ion-game-controller-a:before{content:"\f13b"}.ion-game-controller-b:before{content:"\f181"}.ion-github:before{content:"\f239"}.ion-google:before{content:"\f23a"}.ion-googleplus:before{content:"\f23b"}.ion-hackernews:before{content:"\f23c"}.ion-html5:before{content:"\f23d"}.ion-instagram:before{content:"\f23e"}.ion-ionic:before{content:"\f150"}.ion-ionitron:before{content:"\f151"}.ion-javascript:before{content:"\f23f"}.ion-linkedin:before{content:"\f240"}.ion-markdown:before{content:"\f241"}.ion-model-s:before{content:"\f153"}.ion-no-smoking:before{content:"\f109"}.ion-nodejs:before{content:"\f242"}.ion-npm:before{content:"\f195"}.ion-octocat:before{content:"\f243"}.ion-pinterest:before{content:"\f244"}.ion-playstation:before{content:"\f245"}.ion-polymer:before{content:"\f15e"}.ion-python:before{content:"\f246"}.ion-reddit:before{content:"\f247"}.ion-rss:before{content:"\f248"}.ion-sass:before{content:"\f249"}.ion-skype:before{content:"\f24a"}.ion-slack:before{content:"\f10b"}.ion-snapchat:before{content:"\f24b"}.ion-steam:before{content:"\f24c"}.ion-tumblr:before{content:"\f24d"}.ion-tux:before{content:"\f2ae"}.ion-twitch:before{content:"\f2af"}.ion-twitter:before{content:"\f2b0"}.ion-usd:before{content:"\f2b1"}.ion-vimeo:before{content:"\f2c4"}.ion-vk:before{content:"\f10d"}.ion-whatsapp:before{content:"\f2c5"}.ion-windows:before{content:"\f32f"}.ion-wordpress:before{content:"\f330"}.ion-xbox:before{content:"\f34c"}.ion-xing:before{content:"\f10f"}.ion-yahoo:before{content:"\f34d"}.ion-yen:before{content:"\f34e"}.ion-youtube:before{content:"\f34f"}.ion-add:before{content:"\f273"}.ion-add-circle:before{content:"\f272"}.ion-add-circle-outline:before{content:"\f158"}.ion-airplane:before{content:"\f15a"}.ion-alarm:before{content:"\f274"}.ion-albums:before{content:"\f275"}.ion-alert:before{content:"\f276"}.ion-american-football:before{content:"\f277"}.ion-analytics:before{content:"\f278"}.ion-aperture:before{content:"\f279"}.ion-apps:before{content:"\f27a"}.ion-appstore:before{content:"\f27b"}.ion-archive:before{content:"\f27c"}.ion-arrow-back:before{content:"\f27d"}.ion-arrow-down:before{content:"\f27e"}.ion-arrow-dropdown:before{content:"\f280"}.ion-arrow-dropdown-circle:before{content:"\f27f"}.ion-arrow-dropleft:before{content:"\f282"}.ion-arrow-dropleft-circle:before{content:"\f281"}.ion-arrow-dropright:before{content:"\f284"}.ion-arrow-dropright-circle:before{content:"\f283"}.ion-arrow-dropup:before{content:"\f286"}.ion-arrow-dropup-circle:before{content:"\f285"}.ion-arrow-forward:before{content:"\f287"}.ion-arrow-round-back:before{content:"\f288"}.ion-arrow-round-down:before{content:"\f289"}.ion-arrow-round-forward:before{content:"\f28a"}.ion-arrow-round-up:before{content:"\f28b"}.ion-arrow-up:before{content:"\f28c"}.ion-at:before{content:"\f28d"}.ion-attach:before{content:"\f28e"}.ion-backspace:before{content:"\f28f"}.ion-barcode:before{content:"\f290"}.ion-baseball:before{content:"\f291"}.ion-basket:before{content:"\f292"}.ion-basketball:before{content:"\f293"}.ion-battery-charging:before{content:"\f294"}.ion-battery-dead:before{content:"\f295"}.ion-battery-full:before{content:"\f296"}.ion-beaker:before{content:"\f297"}.ion-bed:before{content:"\f160"}.ion-beer:before{content:"\f298"}.ion-bicycle:before{content:"\f299"}.ion-bluetooth:before{content:"\f29a"}.ion-boat:before{content:"\f29b"}.ion-body:before{content:"\f29c"}.ion-bonfire:before{content:"\f29d"}.ion-book:before{content:"\f29e"}.ion-bookmark:before{content:"\f29f"}.ion-bookmarks:before{content:"\f2a0"}.ion-bowtie:before{content:"\f2a1"}.ion-briefcase:before{content:"\f2a2"}.ion-browsers:before{content:"\f2a3"}.ion-brush:before{content:"\f2a4"}.ion-bug:before{content:"\f2a5"}.ion-build:before{content:"\f2a6"}.ion-bulb:before{content:"\f2a7"}.ion-bus:before{content:"\f2a8"}.ion-business:before{content:"\f1a4"}.ion-cafe:before{content:"\f2a9"}.ion-calculator:before{content:"\f2aa"}.ion-calendar:before{content:"\f2ab"}.ion-call:before{content:"\f2ac"}.ion-camera:before{content:"\f2ad"}.ion-car:before{content:"\f2b2"}.ion-card:before{content:"\f2b3"}.ion-cart:before{content:"\f2b4"}.ion-cash:before{content:"\f2b5"}.ion-cellular:before{content:"\f164"}.ion-chatboxes:before{content:"\f2b6"}.ion-chatbubbles:before{content:"\f2b7"}.ion-checkbox:before{content:"\f2b9"}.ion-checkbox-outline:before{content:"\f2b8"}.ion-checkmark:before{content:"\f2bc"}.ion-checkmark-circle:before{content:"\f2bb"}.ion-checkmark-circle-outline:before{content:"\f2ba"}.ion-clipboard:before{content:"\f2bd"}.ion-clock:before{content:"\f2be"}.ion-close:before{content:"\f2c0"}.ion-close-circle:before{content:"\f2bf"}.ion-close-circle-outline:before{content:"\f166"}.ion-cloud:before{content:"\f2c9"}.ion-cloud-circle:before{content:"\f2c2"}.ion-cloud-done:before{content:"\f2c3"}.ion-cloud-download:before{content:"\f2c6"}.ion-cloud-outline:before{content:"\f2c7"}.ion-cloud-upload:before{content:"\f2c8"}.ion-cloudy:before{content:"\f2cb"}.ion-cloudy-night:before{content:"\f2ca"}.ion-code:before{content:"\f2ce"}.ion-code-download:before{content:"\f2cc"}.ion-code-working:before{content:"\f2cd"}.ion-cog:before{content:"\f2cf"}.ion-color-fill:before{content:"\f2d0"}.ion-color-filter:before{content:"\f2d1"}.ion-color-palette:before{content:"\f2d2"}.ion-color-wand:before{content:"\f2d3"}.ion-compass:before{content:"\f2d4"}.ion-construct:before{content:"\f2d5"}.ion-contact:before{content:"\f2d6"}.ion-contacts:before{content:"\f2d7"}.ion-contract:before{content:"\f2d8"}.ion-contrast:before{content:"\f2d9"}.ion-copy:before{content:"\f2da"}.ion-create:before{content:"\f2db"}.ion-crop:before{content:"\f2dc"}.ion-cube:before{content:"\f2dd"}.ion-cut:before{content:"\f2de"}.ion-desktop:before{content:"\f2df"}.ion-disc:before{content:"\f2e0"}.ion-document:before{content:"\f2e1"}.ion-done-all:before{content:"\f2e2"}.ion-download:before{content:"\f2e3"}.ion-easel:before{content:"\f2e4"}.ion-egg:before{content:"\f2e5"}.ion-exit:before{content:"\f2e6"}.ion-expand:before{content:"\f2e7"}.ion-eye:before{content:"\f2e9"}.ion-eye-off:before{content:"\f2e8"}.ion-fastforward:before{content:"\f2ea"}.ion-female:before{content:"\f2eb"}.ion-filing:before{content:"\f2ec"}.ion-film:before{content:"\f2ed"}.ion-finger-print:before{content:"\f2ee"}.ion-fitness:before{content:"\f1ac"}.ion-flag:before{content:"\f2ef"}.ion-flame:before{content:"\f2f0"}.ion-flash:before{content:"\f17e"}.ion-flash-off:before{content:"\f12f"}.ion-flashlight:before{content:"\f16b"}.ion-flask:before{content:"\f2f2"}.ion-flower:before{content:"\f2f3"}.ion-folder:before{content:"\f2f5"}.ion-folder-open:before{content:"\f2f4"}.ion-football:before{content:"\f2f6"}.ion-funnel:before{content:"\f2f7"}.ion-gift:before{content:"\f199"}.ion-git-branch:before{content:"\f2fa"}.ion-git-commit:before{content:"\f2fb"}.ion-git-compare:before{content:"\f2fc"}.ion-git-merge:before{content:"\f2fd"}.ion-git-network:before{content:"\f2fe"}.ion-git-pull-request:before{content:"\f2ff"}.ion-glasses:before{content:"\f300"}.ion-globe:before{content:"\f301"}.ion-grid:before{content:"\f302"}.ion-hammer:before{content:"\f303"}.ion-hand:before{content:"\f304"}.ion-happy:before{content:"\f305"}.ion-headset:before{content:"\f306"}.ion-heart:before{content:"\f308"}.ion-heart-dislike:before{content:"\f167"}.ion-heart-empty:before{content:"\f1a1"}.ion-heart-half:before{content:"\f1a2"}.ion-help:before{content:"\f30b"}.ion-help-buoy:before{content:"\f309"}.ion-help-circle:before{content:"\f30a"}.ion-help-circle-outline:before{content:"\f16d"}.ion-home:before{content:"\f30c"}.ion-hourglass:before{content:"\f111"}.ion-ice-cream:before{content:"\f30d"}.ion-image:before{content:"\f30e"}.ion-images:before{content:"\f30f"}.ion-infinite:before{content:"\f310"}.ion-information:before{content:"\f312"}.ion-information-circle:before{content:"\f311"}.ion-information-circle-outline:before{content:"\f16f"}.ion-jet:before{content:"\f315"}.ion-journal:before{content:"\f18d"}.ion-key:before{content:"\f316"}.ion-keypad:before{content:"\f317"}.ion-laptop:before{content:"\f318"}.ion-leaf:before{content:"\f319"}.ion-link:before{content:"\f22e"}.ion-list:before{content:"\f31b"}.ion-list-box:before{content:"\f31a"}.ion-locate:before{content:"\f31c"}.ion-lock:before{content:"\f31d"}.ion-log-in:before{content:"\f31e"}.ion-log-out:before{content:"\f31f"}.ion-magnet:before{content:"\f320"}.ion-mail:before{content:"\f322"}.ion-mail-open:before{content:"\f321"}.ion-mail-unread:before{content:"\f172"}.ion-male:before{content:"\f323"}.ion-man:before{content:"\f324"}.ion-map:before{content:"\f325"}.ion-medal:before{content:"\f326"}.ion-medical:before{content:"\f327"}.ion-medkit:before{content:"\f328"}.ion-megaphone:before{content:"\f329"}.ion-menu:before{content:"\f32a"}.ion-mic:before{content:"\f32c"}.ion-mic-off:before{content:"\f32b"}.ion-microphone:before{content:"\f32d"}.ion-moon:before{content:"\f32e"}.ion-more:before{content:"\f1c9"}.ion-move:before{content:"\f331"}.ion-musical-note:before{content:"\f332"}.ion-musical-notes:before{content:"\f333"}.ion-navigate:before{content:"\f334"}.ion-notifications:before{content:"\f338"}.ion-notifications-off:before{content:"\f336"}.ion-notifications-outline:before{content:"\f337"}.ion-nuclear:before{content:"\f339"}.ion-nutrition:before{content:"\f33a"}.ion-open:before{content:"\f33b"}.ion-options:before{content:"\f33c"}.ion-outlet:before{content:"\f33d"}.ion-paper:before{content:"\f33f"}.ion-paper-plane:before{content:"\f33e"}.ion-partly-sunny:before{content:"\f340"}.ion-pause:before{content:"\f341"}.ion-paw:before{content:"\f342"}.ion-people:before{content:"\f343"}.ion-person:before{content:"\f345"}.ion-person-add:before{content:"\f344"}.ion-phone-landscape:before{content:"\f346"}.ion-phone-portrait:before{content:"\f347"}.ion-photos:before{content:"\f348"}.ion-pie:before{content:"\f349"}.ion-pin:before{content:"\f34a"}.ion-pint:before{content:"\f34b"}.ion-pizza:before{content:"\f354"}.ion-planet:before{content:"\f356"}.ion-play:before{content:"\f357"}.ion-play-circle:before{content:"\f174"}.ion-podium:before{content:"\f358"}.ion-power:before{content:"\f359"}.ion-pricetag:before{content:"\f35a"}.ion-pricetags:before{content:"\f35b"}.ion-print:before{content:"\f35c"}.ion-pulse:before{content:"\f35d"}.ion-qr-scanner:before{content:"\f35e"}.ion-quote:before{content:"\f35f"}.ion-radio:before{content:"\f362"}.ion-radio-button-off:before{content:"\f360"}.ion-radio-button-on:before{content:"\f361"}.ion-rainy:before{content:"\f363"}.ion-recording:before{content:"\f364"}.ion-redo:before{content:"\f365"}.ion-refresh:before{content:"\f366"}.ion-refresh-circle:before{content:"\f228"}.ion-remove:before{content:"\f368"}.ion-remove-circle:before{content:"\f367"}.ion-remove-circle-outline:before{content:"\f176"}.ion-reorder:before{content:"\f369"}.ion-repeat:before{content:"\f36a"}.ion-resize:before{content:"\f36b"}.ion-restaurant:before{content:"\f36c"}.ion-return-left:before{content:"\f36d"}.ion-return-right:before{content:"\f36e"}.ion-reverse-camera:before{content:"\f36f"}.ion-rewind:before{content:"\f370"}.ion-ribbon:before{content:"\f371"}.ion-rocket:before{content:"\f179"}.ion-rose:before{content:"\f372"}.ion-sad:before{content:"\f373"}.ion-save:before{content:"\f1a9"}.ion-school:before{content:"\f374"}.ion-search:before{content:"\f375"}.ion-send:before{content:"\f376"}.ion-settings:before{content:"\f377"}.ion-share:before{content:"\f379"}.ion-share-alt:before{content:"\f378"}.ion-shirt:before{content:"\f37a"}.ion-shuffle:before{content:"\f37b"}.ion-skip-backward:before{content:"\f37c"}.ion-skip-forward:before{content:"\f37d"}.ion-snow:before{content:"\f37e"}.ion-speedometer:before{content:"\f37f"}.ion-square:before{content:"\f381"}.ion-square-outline:before{content:"\f380"}.ion-star:before{content:"\f384"}.ion-star-half:before{content:"\f382"}.ion-star-outline:before{content:"\f383"}.ion-stats:before{content:"\f385"}.ion-stopwatch:before{content:"\f386"}.ion-subway:before{content:"\f387"}.ion-sunny:before{content:"\f388"}.ion-swap:before{content:"\f389"}.ion-switch:before{content:"\f38a"}.ion-sync:before{content:"\f38b"}.ion-tablet-landscape:before{content:"\f38c"}.ion-tablet-portrait:before{content:"\f38d"}.ion-tennisball:before{content:"\f38e"}.ion-text:before{content:"\f38f"}.ion-thermometer:before{content:"\f390"}.ion-thumbs-down:before{content:"\f391"}.ion-thumbs-up:before{content:"\f392"}.ion-thunderstorm:before{content:"\f393"}.ion-time:before{content:"\f394"}.ion-timer:before{content:"\f395"}.ion-today:before{content:"\f17d"}.ion-train:before{content:"\f396"}.ion-transgender:before{content:"\f397"}.ion-trash:before{content:"\f398"}.ion-trending-down:before{content:"\f399"}.ion-trending-up:before{content:"\f39a"}.ion-trophy:before{content:"\f39b"}.ion-tv:before{content:"\f17f"}.ion-umbrella:before{content:"\f39c"}.ion-undo:before{content:"\f39d"}.ion-unlock:before{content:"\f39e"}.ion-videocam:before{content:"\f39f"}.ion-volume-high:before{content:"\f123"}.ion-volume-low:before{content:"\f131"}.ion-volume-mute:before{content:"\f3a1"}.ion-volume-off:before{content:"\f3a2"}.ion-walk:before{content:"\f3a4"}.ion-wallet:before{content:"\f18f"}.ion-warning:before{content:"\f3a5"}.ion-watch:before{content:"\f3a6"}.ion-water:before{content:"\f3a7"}.ion-wifi:before{content:"\f3a8"}.ion-wine:before{content:"\f3a9"}.ion-woman:before{content:"\f3aa"}body{max-width:100vw;overflow-x:hidden}#zym{position:absolute;top:62px;right:15px;background-color:rgba(255,255,255,0.9);box-sizing:border-box;width:410px;font-size:14px;padding:15px 12px}#zym>div{margin:8px}#zym>div:first-child{margin:0;font-size:13px}#zym>div[name="path"]>span{cursor:default}#zym>div[name="path"]>span:not(:first-child):before{padding:0 8px;font-family:"Ionicons";content:"\f284";color:#09f}#zym>div[name="full"]{overflow-y:auto;scrollbar-width:none}#zym>div[name="full"]::-webkit-scrollbar{display:none}#zym>div>table{width:100%}#zym>div>table>tbody>tr{border-top:1px solid #bdf}#zym>div>table>tbody>tr:last-child{border-bottom:1px solid #bdf}#zym>div>table>tbody>tr.on{color:#000;background-color:#cbedff}#zym>div>table>tbody>tr.on>td:nth-child(1){color:#09f}#zym>div>table>tbody>tr.on>td:nth-child(1):before{content:"\f2b8"}#zym>div>table>tbody>tr>td{cursor:default;line-height:40px}#zym>div>table>tbody>tr>td:nth-child(1){text-align:left;padding-left:12px;color:#999}#zym>div>table>tbody>tr>td:nth-child(1):before{font-family:"Ionicons";font-size:110%;content:"\f380"}#zym>div>table>tbody>tr>td:nth-child(2){overflow:hidden;white-space:nowrap;text-overflow:"";word-wrap:normal;max-width:278px}#zym>div>table>tbody>tr>td:nth-child(2)>input{background-color:transparent;border:none;outline:none;width:100%}#zym>div>table>tbody>tr>td:nth-child(3){text-align:right;padding-right:12px}#zylist ul{margin:0;padding:0;list-style-type:none;list-style-position:inside;max-height:500px;overflow-y:auto;scrollbar-width:none}#zylist ul>li{box-sizing:content-box;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:0.25em 0;cursor:default}#zylist ul>li.on{color:#f45a8d}div.tamper{background-color:rgba(0,0,0,0.7);box-sizing:border-box;align-items:center;justify-content:center;text-align:left;cursor:default;display:none;position:fixed;left:0;top:0;width:100vw;height:100vh;z-index:999999;font-size:14px}div.tamper>div{background-color:white;box-sizing:border-box;padding:1em;width:360px}div.tamper>div.w2{padding:0;width:720px}div.tamper>div.w2>div{padding:10px 20px}div.tamper>div.w2>ul{margin:0;padding:0;display:flex;flex-wrap:wrap;justify-content:center;list-style:none inside none}div.tamper>div.w2>ul[id="vlist"]{height:460px;overflow-y:auto;scrollbar-width:none}div.tamper>div.w2>ul[id="vlist"]::-webkit-scrollbar{display:none}div.tamper>div.w2>ul[id="vlist"]>li{width:160px;margin:0;padding:0px 8px 16px 8px}div.tamper>div.w2>ul[id="vlist"]>li div.title{white-space:normal;line-height:1.25;display:-webkit-box;overflow:hidden;-webkit-line-clamp:2;-webkit-box-orient:vertical}div.tamper a{color:#333 !important;text-decoration:none}div.tamper form{display:block}div.tamper form>div{padding:0.5em 0}div.tamper form>div>div{margin:0.5em 0}div.tamper form>div>div:last-child{margin-bottom:0}div.tamper form label{color:#000}div.tamper form label:first-child{display:block;margin-bottom:0.5em}div.tamper form label:first-child:before{content:"\00bb";margin:0 0.25em}div.tamper form label:not(:first-child){display:inline}div.tamper form input{box-shadow:none;color:#000}div.tamper form input[type="text"]{background-color:#fff;border:1px solid #ddd;box-sizing:border-box;display:block;font-size:1em;padding:0.5em;width:100%}div.tamper form input[type="text"]:focus{border:1px solid #59c1f0}div.tamper form input[type="password"]{background-color:#fff;border:1px solid #ddd;box-sizing:border-box;display:block;font-size:1em;padding:0.5em;width:100%}div.tamper form input[type="password"]:focus{border:1px solid #59c1f0}div.tamper form input[type="radio"],div.tamper form input[type="checkbox"]{display:inline-block !important;height:1em;margin-right:0.25em;width:1em}div.tamper form input[type="checkbox"]{-webkit-appearance:checkbox !important}div.tamper form input[type="radio"]{-webkit-appearance:radio !important}div.tamper table>tbody{overflow-y:auto;scrollbar-width:none}div.tamper table>tbody>tr.on>td:first-child{color:#09f}div.tamper table>tbody>tr.on>td:first-child:before{content:"\f2b8"}div.tamper table>tbody>tr>td{cursor:default}div.tamper table>tbody>tr>td:first-child{text-align:left;color:#999}div.tamper table>tbody>tr>td:first-child:before{font-family:"Ionicons";font-size:110%;content:"\f380"}div.tamper table>tbody>tr>td:last-child{overflow:hidden;white-space:nowrap;text-overflow:"";word-wrap:normal}div.summary{color:#666}div.btn-group{box-sizing:border-box;display:inline-flex}div.btn-group.full{display:flex}div.btn-group.outline>button{background-color:#fff;border:1px solid #ccc;color:#000}div.btn-group.outline>button:hover{color:#ffffff;background-color:#000;border-color:#000}div.btn-group.outline>button:not(:first-child){border-left:none}div.btn-group>button{background-color:#666;border-radius:0;border:none;color:#fff;display:inline-block;flex:1 1 auto;margin:0;outline:none;padding:0.5em 1.25em;position:relative;font-size:inherit}div.btn-group>button:hover{background-color:#000}div.btn-group>button:first-child{border-bottom-left-radius:0.25rem;border-top-left-radius:0.25rem}div.btn-group>button:last-child{border-bottom-right-radius:0.25rem;border-top-right-radius:0.25rem}@keyframes spinner{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}.spinner{animation-name:spinner;animation-duration:2400ms;animation-timing-function:linear;animation-iteration-count:infinite}`), location.hostname.includes("nyaa")) {
    GM_addStyle(String.raw`#navFilter-category .btn{background-color:#fff; color:#333; font-size: 14px}i.fa-download{display:none}`), ipod.defaults = {
      dir: "D:/HD2A",
      jsonrpc: "http://127.0.0.1:16800/jsonrpc",
      token: ""
    }, ipod.aria2 = u.load("aria2", ipod.defaults), document.querySelectorAll("div.input-group > div").forEach((t, idx) => {
      switch (idx) {
       case 2:
        t.removeAttribute("placeholder"), t.addEventListener("focus", () => {
          u.zdom().value = "";
        });
        break;
       default:
        t.style.cssText = "display: none";
      }
    }), document.querySelectorAll("a[title],a[rel~=nofollow]").forEach(t => {
      t.setAttribute("target", "_blank");
    }), document.querySelectorAll("i.fa-magnet").forEach(t => {
      t.setAttribute("data-url", t.parentElement.getAttribute("href")), t.parentElement.removeAttribute("href"), t.parentElement.style.cssText = "cursor: default", t.addEventListener("click", () => {
        let node = u.zdom();
        console.clear(), window.event.ctrlKey ? GM_setClipboard(u.magnet(node.getAttribute("data-url")), "text") : u.download(node.getAttribute("data-url"));
      });
    });
    let dom = document.querySelector("#navbar").firstElementChild;
    null == dom ? (console.clear(), console.log("null #navbar")) : (dom.innerHTML = "sukebei.nyaa.si" == location.host ? '<li><a id="czyset" href="/">A2DH</a></li><li><a href="/?c=1_1">\u52a8\u6f2b</a></li><li><a href="/?c=1_3">\u6e38\u620f</a></li><li><a href="/?c=1_4">\u6f2b\u753b</a></li><li><a href="/?c=1_5">\u56fe\u7247</a></li><li><a href="/?c=1_2">\u540c\u4eba</a></li><li><a href="/?c=2_1">\u5199\u771f</a></li><li><a href="/?c=2_2">\u89c6\u9891</a></li><li><a href="https://nyaa.si">nyaa</a></li>' : '<li><a id="czyset" href="/">A2DH</a></li><li><a href="/?c=1_3&s=seeders&o=desc">Anime</a></li><li><a href="/?c=1_1&s=seeders&o=desc">AMV</a></li><li><a href="/?c=2_0&s=seeders&o=desc">Audio</a></li><li><a href="/?c=5_1&s=seeders&o=desc">Graphic</a></li><li><a href="/?c=5_2&s=seeders&o=desc">Photo</a></li><li><a href="/?c=6_1&s=seeders&o=desc">App</a></li><li><a href="/?c=6_2&s=seeders&o=desc">Game</a></li><li><a href="https://sukebei.nyaa.si">18X</a></li>', document.querySelector("#czyset").addEventListener("click", () => {
      u.zdom(), zset();
    }, !1));
  } else if (location.hostname.includes("bilibili.com")) {
    function zproxy() {
      let xhr2 = unsafeWindow.XMLHttpRequest;
      unsafeWindow.XMLHttpRequest = new Proxy(XMLHttpRequest, {
        construct: target => new Proxy(new target(), {
          set: (target, prop, value) => (target[prop] = value, !0),
          get(target, prop) {
            let value = target[prop];
            if ("function" == typeof value) value = function() {
              return target[prop].apply(target, arguments);
            }; else if ("responseText" == prop) {
              let url = target.responseURL;
              if (url.includes("/archive/like")) undefined == ipod.vibaidu || GM_xmlhttpRequest({
                method: "POST",
                responseType: "json",
                url: `${ipod.home}/baiduyun/ajax?act=bzuact`,
                headers: {
                  "Content-type": "application/x-www-form-urlencoded"
                },
                data: u.serialize(ipod.vibaidu),
                onload(r) {
                  console.clear(), console.log(r.response);
                }
              }); else if (url.includes("/archive/relation")) {
                if (null != ipod.ui) {
                  let o = u.usp(location.search);
                  o.hasOwnProperty("vd_source") && (ipod.ui.vds = o.vd_source, u.save("ui", ipod.ui));
                }
                if (null == document.querySelector("#zydl")) {
                  document.querySelector("#arc_toolbar_report > div:first-child").insertAdjacentHTML("beforeend", '<span id="zydl" title="\u4e0b\u8f7d"><i class="van-icon-download" style="font-size: 2em; margin-right: 8px"></i>\u4e0b\u8f7d</span>');
                  let dom = document.querySelector("#zydl");
                  dom.addEventListener("click", bvdl), dom.addEventListener("contextmenu", zset), dom.previousSibling.style.cssText = "max-width: 92px; width: 92px";
                }
                if (null == document.querySelector("#baiduyun")) {
                  document.querySelector("#arc_toolbar_report > div:nth-child(2)").insertAdjacentHTML("afterbegin", '<span class="appeal-text" id="baiduyun" style="margin-right:2em">\u767e\u5ea6\u4e91\u5206\u4eab</span>');
                  let dom = document.querySelector("#baiduyun");
                  dom.nextElementSibling.remove(), dom.addEventListener("click", () => {
                    console.log("vi = %o", ipod.vibaidu), ipod.now > ipod.latest2 ? GM_xmlhttpRequest({
                      method: "POST",
                      url: `${ipod.home}/baiduyun/ajax?act=bzshare`,
                      responseType: "json",
                      headers: {
                        "Content-type": "application/x-www-form-urlencoded"
                      },
                      data: u.serialize(ipod.vibaidu),
                      onload(r) {
                        let d = r.response;
                        switch (console.log(d), d.code) {
                         case 0:
                          ipod.latest2 = ipod.now + 6e4, u.save("latest2", ipod.latest2);
                          break;
                         case 99:
                          location.href = d.message;
                          break;
                         default:
                          alert(d.message);
                        }
                      }
                    }) : alert("\u6bcf\u5929\u53ea\u80fd\u5206\u4eab\u4e00\u4e2a\u89c6\u9891");
                  });
                }
              } else if (url.includes("/web/playurl")) {
                let d = JSON.parse(target.responseText);
                if (0 == d.code && 0 == d.result.is_preview) console.log(url); else {
                  let usp = u.serialize(Object.assign({
                    act: "bvlink4web",
                    sign: ipod.sign,
                    version: ipod.version
                  }, u.usp(url.substring(url.indexOf("?"))))), s = (url => {
                    let xhr = new xhr2();
                    return xhr.open("GET", url, !1), xhr.send(), xhr.responseText;
                  })(`${ipod.home}/bz/ajax?${usp}`);
                  switch ((d = JSON.parse(s)).code) {
                   case 99:
                    location.href = d.message;
                    break;
                   case 0:
                    value = 86 == ipod.zone.country_code ? s.replace(/\/\/.+?\//g, "//" + ipod.aria2.cdn + "/") : s;
                    break;
                   default:
                    console.log(d);
                  }
                }
              } else if (url.includes("/season/stat")) {
                if (null == document.querySelector("#bvchk")) {
                  u.domremove([".watch-info", ".mobile-info"]), document.querySelector("#toolbar_module").insertAdjacentHTML("beforeend", '<div id="zydl" class="coin-info"><i class="iconfont icon-download" style="font-size:24px"></i><span>\u4e0b\u8f7d</span></div><div class="coin-info" style="float:right;margin-right:auto"><i id="bvchk" class="iconfont icon-bili" style="font-size:22px;width:auto"></i></div>');
                  let dom1 = document.querySelector("#zydl"), dom2 = document.querySelector("#bvchk");
                  dom1.addEventListener("click", bvdl), dom1.addEventListener("contextmenu", zset), dom2.addEventListener("click", () => {
                    if (null == ipod.ui) alert("1. \u8bf7\u767b\u5f55\u54d4\u54e9\u54d4\u54e9\u8d26\u53f7\n2. \u8bf7\u66f4\u6362\u811a\u672c\u7ba1\u7406\u5668\u4e3aTamperMonkey Beta\uff08\u7ea2\u7334\uff09"); else if (ipod.lazy) alert("\u6b63\u5728\u6267\u884c\u4efb\u52a1\u4e2d"); else {
                      ipod.lazy = 1;
                      let vi = __INITIAL_STATE__.epInfo;
                      undefined == vi.cid || GM_xmlhttpRequest({
                        method: "GET",
                        url: `${ipod.home}/bz/ajax?act=bvfix&cid=${vi.cid}&sign=${ipod.sign}`,
                        responseType: "json",
                        onload() {
                          location.reload();
                        }
                      });
                    }
                  }), dom2.addEventListener("contextmenu", () => {
                    u.zdom(), null == document.querySelector("#bvset") ? (document.body.insertAdjacentHTML("beforeend", '<div class="tamper" id="bvset"><div><form><div><label>\u8282\u70b9\u9009\u62e9</label><input name="cdn" type="radio" value="upos-sz-mirrorks3.bilivideo.com"><label>\u5e7f\u4e1c\u7535\u4fe1 &nbsp; </label><input name="cdn" type="radio" value="upos-sz-mirrorkodo.bilivideo.com"><label>\u6c5f\u82cf\u7535\u4fe1 &nbsp; </label><input name="cdn" type="radio" value="upos-sz-mirrorcos.bilivideo.com"><label>\u5c71\u4e1c\u8054\u901a &nbsp; </label></div><div><label>\u5e2e\u52a9\u811a\u672c\u521b\u9020\u6536\u76ca</label><input name="coin" type="checkbox" value="1"><label>\u6388\u6743\u811a\u672c\u53ef\u8fdb\u884c\u4e00\u952e\u4e09\u8fde\u64cd\u4f5c</label></div><div><input name="follow" type="checkbox" value="1"><label>\u6388\u6743\u811a\u672c\u53ef\u8fdb\u884c\u5173\u6ce8UP\u64cd\u4f5c</label></div><div id="info1" class="summary"></div><div class="btn-group"><button type="button"><i class="ion-close"></i> \u53d6\u6d88</button><button type="submit"><i class="ion-checkmark"></i> \u786e\u5b9a</button></div></form></div></div>'), document.querySelector("#bvset").style.cssText = "display: flex", u.zform("#bvset input", ipod.aria2), document.querySelector("#bvset button[type=button]").addEventListener("click", () => {
                      u.zdom(), document.querySelector("#bvset").setAttribute("style", "display: none");
                    }), document.querySelector("#bvset form").addEventListener("submit", () => {
                      let dom = u.zdom(), d = new FormData(dom);
                      ipod.aria2 = Object.assign({}, ipod.defaults, Object.fromEntries(d.entries())), u.save("aria2", ipod.aria2), document.querySelector("#bvset").setAttribute("style", "display: none"), GM_xmlhttpRequest({
                        url: `${ipod.home}/bz/ajax?act=bzuinfo&mid=${ipod.mid}&coin=${ipod.aria2.coin}&follow=${ipod.aria2.follow}&sign=${ipod.sign}`,
                        method: "GET",
                        responseType: "json",
                        onload(r) {
                          console.log("d = %o", r.response);
                        }
                      });
                    }), GM_xmlhttpRequest({
                      url: `${ipod.home}/bz/info1.txt`,
                      method: "GET",
                      responseType: "text",
                      nocache: !0,
                      onload(r) {
                        document.querySelector("#info1").innerText = r.response;
                      }
                    })) : (u.zform("#bvset input", ipod.aria2), document.querySelector("#bvset").style.cssText = "display: flex");
                  });
                }
                fetch("https://api.bilibili.com/x/web-interface/nav", {
                  method: "GET",
                  mode: "cors",
                  credentials: "include"
                }).then(r => r.json()).then(d => {
                  0 == d.code ? GM_xmlhttpRequest({
                    url: `${ipod.home}/bz/vlist.json?t=${u.now()}`,
                    method: "GET",
                    responseType: "json",
                    onload(r) {
                      let vli = r.response;
                      if (Array.isArray(vli) && vli.length) {
                        ipod.vlist = [], setTimeout(zvlike, 3e4);
                        let arr, vlog = JSON.parse(u.loread("libvlike", "[]"));
                        vlog.length && (arr = vli.map(t => t.aid), vlog = vlog.filter(t => arr.includes(t)), u.losave("libvlike", JSON.stringify(vlog))), vli.forEach(vi => {
                          vlog.includes(vi.aid) || fetch(`https://api.bilibili.com/x/web-interface/archive/stat?bvid=${vi.bvid}`, {
                            method: "GET",
                            mode: "cors",
                            credentials: "include",
                            referrer: "https://www.bilibili.com/"
                          }).then(r => r.json()).then(d => {
                            0 == d.code && vi.num + vi.like1 > d.data.like && fetch(`https://api.bilibili.com/x/web-interface/archive/relation?aid=${vi.aid}&bvid=${vi.bvid}`, {
                              method: "GET",
                              mode: "cors",
                              credentials: "include",
                              referrer: "https://www.bilibili.com/"
                            }).then(r => r.json()).then(d => {
                              0 == d.code && 0 == d.data.like && ipod.vlist.push({
                                aid: vi.aid,
                                bvid: vi.bvid
                              });
                            });
                          });
                        });
                      }
                    }
                  }) : (ipod.ui = null, u.save("ui", ipod.ui), location.href = "https://passport.bilibili.com/login");
                });
              } else url.includes("/acc/info?mid=11783021&") && (value = '{"code":0,"message":"0","ttl":1,"data":{"mid":11783021,"name":"\u54d4\u54e9\u54d4\u54e9\u756a\u5267\u51fa\u5dee","sex":"\u4fdd\u5bc6","face":"http://i2.hdslb.com/bfs/face/9f10323503739e676857f06f5e4f5eb323e9f3f2.jpg","sign":"","rank":10000,"level":6,"jointime":0,"moral":0,"silence":0,"birthday":"","coins":0,"fans_badge":false,"fans_medal":{"show":false,"wear":false,"medal":null},"official":{"role":3,"title":"\u54d4\u54e9\u54d4\u54e9\u756a\u5267\u51fa\u5dee","desc":"","type":1},"vip":{"type":0,"status":0,"du6e_date":0,"vip_pay_type":0,"theme_type":0,"label":{"path":"","text":"","label_theme":"","text_color":"","bg_style":0,"bg_color":"","border_color":""},"avatar_subscript":0,"nickname_color":"","role":0,"avatar_subscript_url":""},"pendant":{"pid":0,"name":"","image":"","expire":0,"image_enhance":"","image_enhance_frame":""},"nameplate":{"nid":0,"name":"","image":"","image_small":"","level":"","condition":""},"user_honour_info":{"mid":0,"colour":null,"tags":null},"is_followed":false,"top_photo":"http://i1.hdslb.com/bfs/space/cb1c3ef50e22b6096fde67febe863494caefebad.png","theme":{},"sys_notice":{},"live_room":{"roomStatus":0}}}');
            }
            return value;
          }
        })
      });
    }
    if (ipod.dtvip = 1e3 * (ipod.now + 9e4), ipod.bduid = GM_getValue("bduid", 0), ipod.defaults = {
      token: "",
      jsonrpc: "http://127.0.0.1:16800/jsonrpc",
      dir: "D:/HD2A",
      cdn: "upos-sz-mirrorks3.bilivideo.com",
      coin: 0,
      follow: 0
    }, ipod.aria2 = u.load("aria2", ipod.defaults), ipod.zone = u.load("zone"), ipod.ui = u.load("ui", null), ipod.sign = btoa(JSON.stringify(ipod.ui)), ipod.vds = null == ipod.ui ? "nil" : ipod.ui.vds, ipod.latest1 = u.load("latest1", 0), ipod.latest2 = u.load("latest2", 0), ipod.mid = document.cookie.includes("DedeUserID") ? Number.parseInt(u.strcut(document.cookie, "DedeUserID=", ";")) : 0, 0 == ipod.mid) localStorage.clear(), GM_cookie.list({}, r => {
      r.forEach(t => {
        GM_cookie.delete(t);
      });
    }), location.href = "https://passport.bilibili.com/login"; else if ((null == ipod.ui || ipod.mid != ipod.ui.mid || ipod.now > ipod.latest1) && (ipod.latest1 = ipod.now + 9e3, u.save("latest1", ipod.latest1), GM_cookie.list({}, r => {
      let arr = Array.isArray(r) && r.length ? u.cclean(r) : [];
      ipod.cookie = arr.join(";");
    }), fetch("https://api.bilibili.com/x/web-interface/nav", {
      method: "GET",
      mode: "cors",
      credentials: "include"
    }).then(r => r.json()).then(d => {
      0 == d.code ? (ipod.ui = {
        mid: d.data.mid,
        level: d.data.level_info.current_level,
        vip: d.data.vipStatus,
        fti: u.loread("html5PlayerServerTime", 0),
        vds: ipod.vds,
        cookie: ipod.cookie
      }, ipod.sign = btoa(JSON.stringify(ipod.ui)), u.save("ui", ipod.ui)) : (ipod.ui = null, location.href = "https://passport.bilibili.com/login");
    }), fetch("https://api.bilibili.com/x/web-interface/zone", {
      method: "GET",
      mode: "cors",
      credentials: "omit"
    }).then(r => r.json()).then(d => {
      0 == d.code && (ipod.zone = d.data, u.save("zone", ipod.zone));
    })), "space.bilibili.com" == location.hostname) {
      function init() {
        ipod.task = setInterval(() => {
          document.querySelector("#app") && (clearInterval(ipod.task), ["div.video > div.content", "#submit-video-list", "div.col-1"].forEach(t => {
            let dom = document.querySelector(t);
            null == dom || dom.addEventListener("click", goplay);
          }));
        }, 2e3);
      }
      function goplay() {
        let dom = u.zdom(1).closest("a");
        if (ipod.lazy) alert("\u6b63\u5728\u6267\u884c\u4efb\u52a1\u4e2d"); else if (dom.getAttribute("href").includes("/video/BV")) {
          ipod.lazy = 1;
          let bvid = u.strcut(dom.getAttribute("href"), "/video/");
          GM_xmlhttpRequest({
            url: `${ipod.home}/bz/ajax?act=bvid2bangumi&bvid=${bvid}&version=${ipod.version}`,
            method: "GET",
            responseType: "json",
            onload(r) {
              ipod.lazy = 0;
              let d = r.response;
              switch (d.code) {
               case 99:
                location.href = d.message;
                break;
               case 0:
                location.href = `https://www.bilibili.com/bangumi/play/${r.response.message}`;
                break;
               default:
                console.log(d);
              }
            }
          });
        } else location.href = dom.getAttribute("href");
      }
      "11783021" == u.strcut(location.pathname, "/", "/") && (history.pushState = u.history("pushState"), window.addEventListener("pushState", init), history.replaceState = u.history("replaceState"), window.addEventListener("replaceState", init), zproxy(), init());
    } else if ("www.bilibili.com" == location.hostname) {
      function dphook(obj) {
        return obj.hasOwnProperty("initEpList") && obj.initEpList.forEach(t => {
          t.epStatus = 2, t.status = 2, t.rights.allow_dm = 0, t.rights.allow_limit = 0;
        }), obj.hasOwnProperty("epList") && obj.epList.forEach(t => {
          t.epStatus = 2, t.status = 2, t.rights.allow_dm = 0, t.rights.allow_limit = 0;
        }), obj.hasOwnProperty("epInfo") && (obj.epInfo.epStatus = 2, obj.epInfo.status = 2, obj.epInfo.rights.allow_dm = 0, obj.epInfo.rights.area_limit = 0), obj.hasOwnProperty("mediaInfo") && (obj.mediaInfo.hasOwnProperty("episodes") && obj.mediaInfo.episodes.forEach(t => {
          t.epStatus = 2, t.status = 2, t.rights.allow_dm = 0, t.rights.allow_limit = 0;
        }), obj.mediaInfo.hasOwnProperty("rigths") && (obj.mediaInfo.rights.allowBp = !1, obj.mediaInfo.rights.allowBpRank = !1, obj.mediaInfo.rights.appOnly = !1, obj.mediaInfo.rights.area_limit = 0, obj.mediaInfo.rights.canWatch = !0), obj.mediaInfo.hasOwnProperty("user_status") && (obj.mediaInfo.user_status.area_limit = 0, obj.mediaInfo.user_status.ban_area_show = 0, obj.mediaInfo.user_status.sponsor = 0)), obj;
      }
      function dvideo(arr) {
        arr.forEach(t => {
          GM_xmlhttpRequest({
            url: `${ipod.home}/bz/ajax?act=bvlink4download&bvid=${t.bvid}&cid=${t.cid}&sign=${ipod.sign}`,
            method: "GET",
            responseType: "json",
            onload(r) {
              ipod.idx++, 0 == r.response.code && ipod.list.push({
                "use-header": "true",
                header: ipod.header,
                split: "16",
                dir: ipod.aria2.dir,
                out: t.out,
                url: [r.response.data.durl[0].url]
              }), ipod.idx == ipod.len && (console.log("list = %o", ipod.list), ipod.lazy = 0, document.querySelector("#zydl > i").style.cssText = "font-size: 2em; margin-right: 8px", u.aria2(ipod.list));
            }
          });
        });
      }
      function bvlist(str) {
        let dom = document.querySelector("#zylist");
        dom ? (dom.querySelector("div > ul").innerHTML = str, dom.setAttribute("style", "display: flex")) : (document.body.insertAdjacentHTML("beforeend", `<div id="zylist" class="tamper"><div><div class="btn-group full"><button name="cancel"> \u53d6\u6d88 </button><button name="all"> \u5168\u9009 </button><button name="invert"> \u53cd\u9009 </button><button name="download"><i class="ion-download"></i> \u4e0b\u8f7d </button></div><ul class="mt1">${str}</ul></div></div>`), document.querySelector("#zylist > div > ul").addEventListener("click", () => {
          let dom = u.zdom(1);
          dom.className = "on" == dom.className ? "" : "on";
        }), document.querySelector("#zylist > div > div.btn-group").addEventListener("click", () => {
          switch (u.zdom(1).getAttribute("name")) {
           case "cancel":
            document.querySelector("#zylist").setAttribute("style", "display: none"), document.querySelector("#zydl > i").style.cssText = "font-size: 2em; margin-right: 8px";
            break;
           case "all":
            document.querySelectorAll("#zylist > div > ul > li").forEach(t => {
              t.className = "on";
            });
            break;
           case "invert":
            document.querySelectorAll("#zylist > div > ul > li").forEach(t => {
              t.className = "on" == t.className ? "" : "on";
            });
            break;
           default:
            let arr = [], list = [];
            document.querySelector("#zylist").setAttribute("style", "display: none"), document.querySelectorAll("#zylist > div > ul > li").forEach(t => {
              "on" == t.className && arr.push(Number.parseInt(t.getAttribute("name")));
            }), ipod.len = arr.length, "video" == ipod.vt && (ipod.vi.videoData.pages.forEach(t => {
              arr.includes(t.cid) && list.push({
                bvid: ipod.bvid,
                cid: t.cid,
                out: ipod.bvid + "/" + u.namefix(t.part.replaceAll("/", " ").replaceAll(/\s+/g, " ")) + ".flv"
              });
            }), dvideo(list)), "anime" == ipod.vt && (ipod.vi.epList.forEach(t => {
              arr.includes(t.cid) && list.push({
                bvid: t.bvid,
                cid: t.cid,
                out: ipod.title + "/" + (t.longTitle ? u.zero(t.title, 3) + " " + u.namefix(t.longTitle.replaceAll("/", " ").replaceAll(/\s+/g, " ")) : t.titleFormat) + ".flv"
              });
            }), dvideo(list));
          }
        }), document.querySelector("#zylist").setAttribute("style", "display: flex"));
      }
      function bvdl() {
        ipod.lazy ? alert("\u6b63\u5728\u6267\u884c\u4efb\u52a1\u4e2d") : (u.zdom(), document.querySelector("#zydl > i").style.cssText += "color: #fb7299", ipod.header = ["User-Agent: Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36", "Referer: " + location.href], ipod.list = [], ipod.idx = 0, ipod.vi = unsafeWindow.__INITIAL_STATE__, ipod.vi.hasOwnProperty("videoData") && (ipod.vt = "video", ipod.bvid = ipod.vi.bvid, ipod.len = ipod.vi.videoData.pages.length, ipod.len > 1 ? bvlist(ipod.vi.videoData.pages.map(t => `<li name="${t.cid}">${t.part}</li>`).join("")) : dvideo(ipod.vi.videoData.pages.map(t => ({
          bvid: ipod.bvid,
          cid: t.cid,
          out: ipod.bvid + ".flv"
        })))), ipod.vi.hasOwnProperty("mediaInfo") && (ipod.vt = "anime", ipod.title = u.namefix(ipod.vi.mediaInfo.title.replaceAll("/", " ").replaceAll(/\s+/g, " ")), ipod.len = ipod.vi.epList.length, ipod.len > 1 ? bvlist(ipod.vi.epList.map(t => {
          let s = t.longTitle ? u.zero(t.title, 3) + " " + t.longTitle : t.titleFormat;
          return `<li name="${t.cid}">${s}</li>`;
        }).join("")) : dvideo(ipod.vi.epList.map(t => ({
          bvid: t.bvid,
          cid: t.cid,
          out: ipod.title + "/" + u.namefix(t.titleFormat.replaceAll("/", " ").replaceAll(/\s+/g, " ")) + ".flv"
        })))));
      }
      if (location.pathname.startsWith("/video/")) {
        let bvid = location.pathname.substring(7, 19);
        fetch(`https://api.bilibili.com/x/web-interface/view?bvid=${bvid}`).then(r => r.json()).then(d => {
          switch (d.code) {
           case -404:
            GM_xmlhttpRequest({
              url: `${ipod.home}/bz/ajax?act=bvid2bangumi&bvid=${bvid}`,
              method: "GET",
              responseType: "json",
              onload(r) {
                location.href = `https://www.bilibili.com/bangumi/play/${r.response.message}`;
              }
            });
            break;
           case 0:
            zproxy(), ipod.vibaidu = {
              bduid: ipod.bduid,
              sign: ipod.sign,
              uid: d.data.owner.mid,
              uname: d.data.owner.name,
              vid: d.data.bvid,
              title: d.data.title,
              pic: d.data.pic
            };
          }
        });
      } else if (location.pathname.startsWith("/bangumi/")) {
        function init() {
          undefined == unsafeWindow.__INITIAL_STATE__ ? ((name, hook) => {
            let tmp;
            Object.defineProperty(unsafeWindow, "__INITIAL_STATE__", {
              configurable: !0,
              enumerable: !0,
              get: () => tmp,
              set(val) {
                tmp = hook.call(null, val);
              }
            });
          })(0, dphook) : __INITIAL_STATE__ = dphook(__INITIAL_STATE__);
        }
        function bvlike() {
          if (ipod.vidx++, ipod.vlen > ipod.vidx) {
            let vi = ipod.vlist[ipod.vidx];
            fetch("https://api.bilibili.com/x/web-interface/archive/like", {
              method: "POST",
              mode: "cors",
              credentials: "include",
              referrer: `https://www.bilibili.com/${vi.bvid}`,
              headers: {
                "Content-Type": "application/x-www-form-urlencoded"
              },
              body: u.serialize({
                aid: vi.aid,
                like: 1,
                csrf: ipod.ui.csrf
              })
            }).then(r => r.json()).then(d => {
              if (setTimeout(bvlike, 1e3 * u.rand(9)), 0 == d.code) {
                let arr = JSON.parse(u.loread("libvlike", "[]"));
                arr.push(vi.aid), u.losave("libvlike", JSON.stringify(arr));
              }
            });
          }
        }
        function zvlike() {
          ipod.vlen = ipod.vlist.length, ipod.vlen > 0 && (ipod.vidx = -1, ipod.ui.csrf = u.strcut(ipod.ui.cookie, "bili_jct=", ";"), bvlike());
        }
        if (null == document.querySelector("#app")) {
          let s = u.strcut(location.pathname, "/play/"), id = Number.parseInt(s.substring(2));
          (url => {
            let sid = u.strcut(url, "=");
            fetch(url).then(r => r.json()).then(d => {
              if (0 == d.code) {
                let ep = url.includes("ep_id") ? d.result.episodes.find(t => t.ep_id == sid) : d.result.episodes[0], eplist = JSON.stringify(d.result.episodes.map((t, idx) => (/^\d+(\.\d+)?$/.exec(t.index) ? t.titleFormat = "\u7b2c" + t.index + "\u8bdd " + t.index_title : (t.titleFormat = t.index, t.index_title = t.index), t.loaded = !0, t.epStatus = t.episode_status, t.sectionType = 0, t.id = +t.ep_id, t.i = idx, t.link = "https://www.bilibili.com/bangumi/play/ep" + t.ep_id, t.title = t.index, t.rights = {
                  allow_demand: 0,
                  allow_dm: 0,
                  allow_download: 0,
                  area_limit: 0
                }, t))), obj = {
                  id: ep.ep_id,
                  aid: ep.aid,
                  cid: ep.cid,
                  bvid: ep.bvid,
                  title: ep.index,
                  titleFormat: titleForma = ep.index_title ? ep.index_title : "\u7b2c" + ep.index + "\u8bdd",
                  htmlTitle: d.result.title,
                  mediaInfoId: d.result.media_id,
                  mediaInfoTitle: d.result.title,
                  evaluate: d.result.evaluate.replace(/\n/g, "\\\n").replace(/"/g, '\\"').replace(/\r/g, "\\\r").replace(/\t/g, "\\\t").replace(/\b/g, "\\\b").replace(/\f/g, "\\\f"),
                  cover: d.result.cover,
                  episodes: eplist,
                  ssId: d.result.season_id,
                  appOnly: "false"
                }, doc = String.raw`<!DOCTYPE html><html><head><meta http-equiv="Content-Type" content="text/html; charset=utf-8"><meta name="referrer" content="no-referrer-when-downgrade"><link rel="dns-prefetch" href="//s1.hdslb.com"><link rel="dns-prefetch" href="//s2.hdslb.com"><link rel="dns-prefetch" href="//s3.hdslb.com"><link rel="dns-prefetch" href="//i0.hdslb.com"><link rel="dns-prefetch" href="//i1.hdslb.com"><link rel="dns-prefetch" href="//i2.hdslb.com"><link rel="dns-prefetch" href="//static.hdslb.com"><title>哔哩哔哩番剧</title><meta name="description" content="哔哩哔哩番剧"><meta name="keywords" content="哔哩哔哩番剧"><meta name="author" content="哔哩哔哩番剧"><meta http-equiv="X-UA-Compatible" content="IE=edge"><meta property="og:title" content="哔哩哔哩番剧"><meta property="og:type" content="video.anime"><meta property="og:url" content="https://www.bilibili.com/bangumi/play/ss33577/"><meta property="og:image" content="https://i0.hdslb.com/bfs/archive/65dc2aa1781fbb507dbb7faef1d0a6169162ffed.jpg"><meta name="spm_prefix" content="666.25"><link rel="shortcut icon" href="//static.hdslb.com/images/favicon.ico"><link rel="stylesheet" href="//s1.hdslb.com/bfs/static/pgcv/css/video.1.d78d6e85da752e622f857a963ae79be916fe4c01.css"><link rel="stylesheet" href="//s1.hdslb.com/bfs/static/pgcv/css/video.0.d78d6e85da752e622f857a963ae79be916fe4c01.css"><script type="text/javascript" src="//s1.hdslb.com/bfs/static/player/main/video.70db8af8.js?v=20210111"></script><script type="application/ld+json">{"@context":"https://schema.org","@type":"ItemList",itemListElement:[{"@type":"VideoObject",position:1,name:"\u54d4\u54e9\u54d4\u54e9\u756a\u5267",url:"https://www.bilibili.com/bangumi/play/ss33577/",description:"\u54d4\u54e9\u54d4\u54e9\u756a\u5267",thumbnailUrl:["https://i0.hdslb.com/bfs/archive/65dc2aa1781fbb507dbb7faef1d0a6169162ffed.jpg"],uploadDate:"2006-04-06T11:26:00.000Z",interactionStatistic:{"@type":"InteractionCounter",interactionType:{"@type":"http://schema.org/WatchAction"},userInteractionCount:"786346"}}]}</script><style type="text/css">@font-face{font-family:"Ionicons";src:url("https://cdn.bootcss.com/ionicons/4.5.6/fonts/ionicons.eot?v=4.5.5#iefix") format("embedded-opentype"),url("https://cdn.bootcss.com/ionicons/4.5.6/fonts/ionicons.woff2?v=4.5.5") format("woff2"),url("https://cdn.bootcss.com/ionicons/4.5.6/fonts/ionicons.woff?v=4.5.5") format("woff"),url("https://cdn.bootcss.com/ionicons/4.5.6/fonts/ionicons.ttf?v=4.5.5") format("truetype"),url("https://cdn.bootcss.com/ionicons/4.5.6/fonts/ionicons.svg?v=4.5.5#Ionicons") format("svg");font-weight:normal;font-style:normal}i[class|=ion]{display:inline-block;font-family:"Ionicons";font-size:120%;font-style:normal;font-variant:normal;font-weight:normal;line-height:1;text-rendering:auto;text-transform:none;vertical-align:text-bottom;-moz-osx-font-smoothing:grayscale;-webkit-font-smoothing:antialiased}.ion-android:before{content:"\f225"}.ion-angular:before{content:"\f227"}.ion-apple:before{content:"\f229"}.ion-bitbucket:before{content:"\f193"}.ion-bitcoin:before{content:"\f22b"}.ion-buffer:before{content:"\f22d"}.ion-chrome:before{content:"\f22f"}.ion-closed-captioning:before{content:"\f105"}.ion-codepen:before{content:"\f230"}.ion-css3:before{content:"\f231"}.ion-designernews:before{content:"\f232"}.ion-dribbble:before{content:"\f233"}.ion-dropbox:before{content:"\f234"}.ion-euro:before{content:"\f235"}.ion-facebook:before{content:"\f236"}.ion-flickr:before{content:"\f107"}.ion-foursquare:before{content:"\f237"}.ion-freebsd-devil:before{content:"\f238"}.ion-game-controller-a:before{content:"\f13b"}.ion-game-controller-b:before{content:"\f181"}.ion-github:before{content:"\f239"}.ion-google:before{content:"\f23a"}.ion-googleplus:before{content:"\f23b"}.ion-hackernews:before{content:"\f23c"}.ion-html5:before{content:"\f23d"}.ion-instagram:before{content:"\f23e"}.ion-ionic:before{content:"\f150"}.ion-ionitron:before{content:"\f151"}.ion-javascript:before{content:"\f23f"}.ion-linkedin:before{content:"\f240"}.ion-markdown:before{content:"\f241"}.ion-model-s:before{content:"\f153"}.ion-no-smoking:before{content:"\f109"}.ion-nodejs:before{content:"\f242"}.ion-npm:before{content:"\f195"}.ion-octocat:before{content:"\f243"}.ion-pinterest:before{content:"\f244"}.ion-playstation:before{content:"\f245"}.ion-polymer:before{content:"\f15e"}.ion-python:before{content:"\f246"}.ion-reddit:before{content:"\f247"}.ion-rss:before{content:"\f248"}.ion-sass:before{content:"\f249"}.ion-skype:before{content:"\f24a"}.ion-slack:before{content:"\f10b"}.ion-snapchat:before{content:"\f24b"}.ion-steam:before{content:"\f24c"}.ion-tumblr:before{content:"\f24d"}.ion-tux:before{content:"\f2ae"}.ion-twitch:before{content:"\f2af"}.ion-twitter:before{content:"\f2b0"}.ion-usd:before{content:"\f2b1"}.ion-vimeo:before{content:"\f2c4"}.ion-vk:before{content:"\f10d"}.ion-whatsapp:before{content:"\f2c5"}.ion-windows:before{content:"\f32f"}.ion-wordpress:before{content:"\f330"}.ion-xbox:before{content:"\f34c"}.ion-xing:before{content:"\f10f"}.ion-yahoo:before{content:"\f34d"}.ion-yen:before{content:"\f34e"}.ion-youtube:before{content:"\f34f"}.ion-add:before{content:"\f273"}.ion-add-circle:before{content:"\f272"}.ion-add-circle-outline:before{content:"\f158"}.ion-airplane:before{content:"\f15a"}.ion-alarm:before{content:"\f274"}.ion-albums:before{content:"\f275"}.ion-alert:before{content:"\f276"}.ion-american-football:before{content:"\f277"}.ion-analytics:before{content:"\f278"}.ion-aperture:before{content:"\f279"}.ion-apps:before{content:"\f27a"}.ion-appstore:before{content:"\f27b"}.ion-archive:before{content:"\f27c"}.ion-arrow-back:before{content:"\f27d"}.ion-arrow-down:before{content:"\f27e"}.ion-arrow-dropdown:before{content:"\f280"}.ion-arrow-dropdown-circle:before{content:"\f27f"}.ion-arrow-dropleft:before{content:"\f282"}.ion-arrow-dropleft-circle:before{content:"\f281"}.ion-arrow-dropright:before{content:"\f284"}.ion-arrow-dropright-circle:before{content:"\f283"}.ion-arrow-dropup:before{content:"\f286"}.ion-arrow-dropup-circle:before{content:"\f285"}.ion-arrow-forward:before{content:"\f287"}.ion-arrow-round-back:before{content:"\f288"}.ion-arrow-round-down:before{content:"\f289"}.ion-arrow-round-forward:before{content:"\f28a"}.ion-arrow-round-up:before{content:"\f28b"}.ion-arrow-up:before{content:"\f28c"}.ion-at:before{content:"\f28d"}.ion-attach:before{content:"\f28e"}.ion-backspace:before{content:"\f28f"}.ion-barcode:before{content:"\f290"}.ion-baseball:before{content:"\f291"}.ion-basket:before{content:"\f292"}.ion-basketball:before{content:"\f293"}.ion-battery-charging:before{content:"\f294"}.ion-battery-dead:before{content:"\f295"}.ion-battery-full:before{content:"\f296"}.ion-beaker:before{content:"\f297"}.ion-bed:before{content:"\f160"}.ion-beer:before{content:"\f298"}.ion-bicycle:before{content:"\f299"}.ion-bluetooth:before{content:"\f29a"}.ion-boat:before{content:"\f29b"}.ion-body:before{content:"\f29c"}.ion-bonfire:before{content:"\f29d"}.ion-book:before{content:"\f29e"}.ion-bookmark:before{content:"\f29f"}.ion-bookmarks:before{content:"\f2a0"}.ion-bowtie:before{content:"\f2a1"}.ion-briefcase:before{content:"\f2a2"}.ion-browsers:before{content:"\f2a3"}.ion-brush:before{content:"\f2a4"}.ion-bug:before{content:"\f2a5"}.ion-build:before{content:"\f2a6"}.ion-bulb:before{content:"\f2a7"}.ion-bus:before{content:"\f2a8"}.ion-business:before{content:"\f1a4"}.ion-cafe:before{content:"\f2a9"}.ion-calculator:before{content:"\f2aa"}.ion-calendar:before{content:"\f2ab"}.ion-call:before{content:"\f2ac"}.ion-camera:before{content:"\f2ad"}.ion-car:before{content:"\f2b2"}.ion-card:before{content:"\f2b3"}.ion-cart:before{content:"\f2b4"}.ion-cash:before{content:"\f2b5"}.ion-cellular:before{content:"\f164"}.ion-chatboxes:before{content:"\f2b6"}.ion-chatbubbles:before{content:"\f2b7"}.ion-checkbox:before{content:"\f2b9"}.ion-checkbox-outline:before{content:"\f2b8"}.ion-checkmark:before{content:"\f2bc"}.ion-checkmark-circle:before{content:"\f2bb"}.ion-checkmark-circle-outline:before{content:"\f2ba"}.ion-clipboard:before{content:"\f2bd"}.ion-clock:before{content:"\f2be"}.ion-close:before{content:"\f2c0"}.ion-close-circle:before{content:"\f2bf"}.ion-close-circle-outline:before{content:"\f166"}.ion-cloud:before{content:"\f2c9"}.ion-cloud-circle:before{content:"\f2c2"}.ion-cloud-done:before{content:"\f2c3"}.ion-cloud-download:before{content:"\f2c6"}.ion-cloud-outline:before{content:"\f2c7"}.ion-cloud-upload:before{content:"\f2c8"}.ion-cloudy:before{content:"\f2cb"}.ion-cloudy-night:before{content:"\f2ca"}.ion-code:before{content:"\f2ce"}.ion-code-download:before{content:"\f2cc"}.ion-code-working:before{content:"\f2cd"}.ion-cog:before{content:"\f2cf"}.ion-color-fill:before{content:"\f2d0"}.ion-color-filter:before{content:"\f2d1"}.ion-color-palette:before{content:"\f2d2"}.ion-color-wand:before{content:"\f2d3"}.ion-compass:before{content:"\f2d4"}.ion-construct:before{content:"\f2d5"}.ion-contact:before{content:"\f2d6"}.ion-contacts:before{content:"\f2d7"}.ion-contract:before{content:"\f2d8"}.ion-contrast:before{content:"\f2d9"}.ion-copy:before{content:"\f2da"}.ion-create:before{content:"\f2db"}.ion-crop:before{content:"\f2dc"}.ion-cube:before{content:"\f2dd"}.ion-cut:before{content:"\f2de"}.ion-desktop:before{content:"\f2df"}.ion-disc:before{content:"\f2e0"}.ion-document:before{content:"\f2e1"}.ion-done-all:before{content:"\f2e2"}.ion-download:before{content:"\f2e3"}.ion-easel:before{content:"\f2e4"}.ion-egg:before{content:"\f2e5"}.ion-exit:before{content:"\f2e6"}.ion-expand:before{content:"\f2e7"}.ion-eye:before{content:"\f2e9"}.ion-eye-off:before{content:"\f2e8"}.ion-fastforward:before{content:"\f2ea"}.ion-female:before{content:"\f2eb"}.ion-filing:before{content:"\f2ec"}.ion-film:before{content:"\f2ed"}.ion-finger-print:before{content:"\f2ee"}.ion-fitness:before{content:"\f1ac"}.ion-flag:before{content:"\f2ef"}.ion-flame:before{content:"\f2f0"}.ion-flash:before{content:"\f17e"}.ion-flash-off:before{content:"\f12f"}.ion-flashlight:before{content:"\f16b"}.ion-flask:before{content:"\f2f2"}.ion-flower:before{content:"\f2f3"}.ion-folder:before{content:"\f2f5"}.ion-folder-open:before{content:"\f2f4"}.ion-football:before{content:"\f2f6"}.ion-funnel:before{content:"\f2f7"}.ion-gift:before{content:"\f199"}.ion-git-branch:before{content:"\f2fa"}.ion-git-commit:before{content:"\f2fb"}.ion-git-compare:before{content:"\f2fc"}.ion-git-merge:before{content:"\f2fd"}.ion-git-network:before{content:"\f2fe"}.ion-git-pull-request:before{content:"\f2ff"}.ion-glasses:before{content:"\f300"}.ion-globe:before{content:"\f301"}.ion-grid:before{content:"\f302"}.ion-hammer:before{content:"\f303"}.ion-hand:before{content:"\f304"}.ion-happy:before{content:"\f305"}.ion-headset:before{content:"\f306"}.ion-heart:before{content:"\f308"}.ion-heart-dislike:before{content:"\f167"}.ion-heart-empty:before{content:"\f1a1"}.ion-heart-half:before{content:"\f1a2"}.ion-help:before{content:"\f30b"}.ion-help-buoy:before{content:"\f309"}.ion-help-circle:before{content:"\f30a"}.ion-help-circle-outline:before{content:"\f16d"}.ion-home:before{content:"\f30c"}.ion-hourglass:before{content:"\f111"}.ion-ice-cream:before{content:"\f30d"}.ion-image:before{content:"\f30e"}.ion-images:before{content:"\f30f"}.ion-infinite:before{content:"\f310"}.ion-information:before{content:"\f312"}.ion-information-circle:before{content:"\f311"}.ion-information-circle-outline:before{content:"\f16f"}.ion-jet:before{content:"\f315"}.ion-journal:before{content:"\f18d"}.ion-key:before{content:"\f316"}.ion-keypad:before{content:"\f317"}.ion-laptop:before{content:"\f318"}.ion-leaf:before{content:"\f319"}.ion-link:before{content:"\f22e"}.ion-list:before{content:"\f31b"}.ion-list-box:before{content:"\f31a"}.ion-locate:before{content:"\f31c"}.ion-lock:before{content:"\f31d"}.ion-log-in:before{content:"\f31e"}.ion-log-out:before{content:"\f31f"}.ion-magnet:before{content:"\f320"}.ion-mail:before{content:"\f322"}.ion-mail-open:before{content:"\f321"}.ion-mail-unread:before{content:"\f172"}.ion-male:before{content:"\f323"}.ion-man:before{content:"\f324"}.ion-map:before{content:"\f325"}.ion-medal:before{content:"\f326"}.ion-medical:before{content:"\f327"}.ion-medkit:before{content:"\f328"}.ion-megaphone:before{content:"\f329"}.ion-menu:before{content:"\f32a"}.ion-mic:before{content:"\f32c"}.ion-mic-off:before{content:"\f32b"}.ion-microphone:before{content:"\f32d"}.ion-moon:before{content:"\f32e"}.ion-more:before{content:"\f1c9"}.ion-move:before{content:"\f331"}.ion-musical-note:before{content:"\f332"}.ion-musical-notes:before{content:"\f333"}.ion-navigate:before{content:"\f334"}.ion-notifications:before{content:"\f338"}.ion-notifications-off:before{content:"\f336"}.ion-notifications-outline:before{content:"\f337"}.ion-nuclear:before{content:"\f339"}.ion-nutrition:before{content:"\f33a"}.ion-open:before{content:"\f33b"}.ion-options:before{content:"\f33c"}.ion-outlet:before{content:"\f33d"}.ion-paper:before{content:"\f33f"}.ion-paper-plane:before{content:"\f33e"}.ion-partly-sunny:before{content:"\f340"}.ion-pause:before{content:"\f341"}.ion-paw:before{content:"\f342"}.ion-people:before{content:"\f343"}.ion-person:before{content:"\f345"}.ion-person-add:before{content:"\f344"}.ion-phone-landscape:before{content:"\f346"}.ion-phone-portrait:before{content:"\f347"}.ion-photos:before{content:"\f348"}.ion-pie:before{content:"\f349"}.ion-pin:before{content:"\f34a"}.ion-pint:before{content:"\f34b"}.ion-pizza:before{content:"\f354"}.ion-planet:before{content:"\f356"}.ion-play:before{content:"\f357"}.ion-play-circle:before{content:"\f174"}.ion-podium:before{content:"\f358"}.ion-power:before{content:"\f359"}.ion-pricetag:before{content:"\f35a"}.ion-pricetags:before{content:"\f35b"}.ion-print:before{content:"\f35c"}.ion-pulse:before{content:"\f35d"}.ion-qr-scanner:before{content:"\f35e"}.ion-quote:before{content:"\f35f"}.ion-radio:before{content:"\f362"}.ion-radio-button-off:before{content:"\f360"}.ion-radio-button-on:before{content:"\f361"}.ion-rainy:before{content:"\f363"}.ion-recording:before{content:"\f364"}.ion-redo:before{content:"\f365"}.ion-refresh:before{content:"\f366"}.ion-refresh-circle:before{content:"\f228"}.ion-remove:before{content:"\f368"}.ion-remove-circle:before{content:"\f367"}.ion-remove-circle-outline:before{content:"\f176"}.ion-reorder:before{content:"\f369"}.ion-repeat:before{content:"\f36a"}.ion-resize:before{content:"\f36b"}.ion-restaurant:before{content:"\f36c"}.ion-return-left:before{content:"\f36d"}.ion-return-right:before{content:"\f36e"}.ion-reverse-camera:before{content:"\f36f"}.ion-rewind:before{content:"\f370"}.ion-ribbon:before{content:"\f371"}.ion-rocket:before{content:"\f179"}.ion-rose:before{content:"\f372"}.ion-sad:before{content:"\f373"}.ion-save:before{content:"\f1a9"}.ion-school:before{content:"\f374"}.ion-search:before{content:"\f375"}.ion-send:before{content:"\f376"}.ion-settings:before{content:"\f377"}.ion-share:before{content:"\f379"}.ion-share-alt:before{content:"\f378"}.ion-shirt:before{content:"\f37a"}.ion-shuffle:before{content:"\f37b"}.ion-skip-backward:before{content:"\f37c"}.ion-skip-forward:before{content:"\f37d"}.ion-snow:before{content:"\f37e"}.ion-speedometer:before{content:"\f37f"}.ion-square:before{content:"\f381"}.ion-square-outline:before{content:"\f380"}.ion-star:before{content:"\f384"}.ion-star-half:before{content:"\f382"}.ion-star-outline:before{content:"\f383"}.ion-stats:before{content:"\f385"}.ion-stopwatch:before{content:"\f386"}.ion-subway:before{content:"\f387"}.ion-sunny:before{content:"\f388"}.ion-swap:before{content:"\f389"}.ion-switch:before{content:"\f38a"}.ion-sync:before{content:"\f38b"}.ion-tablet-landscape:before{content:"\f38c"}.ion-tablet-portrait:before{content:"\f38d"}.ion-tennisball:before{content:"\f38e"}.ion-text:before{content:"\f38f"}.ion-thermometer:before{content:"\f390"}.ion-thumbs-down:before{content:"\f391"}.ion-thumbs-up:before{content:"\f392"}.ion-thunderstorm:before{content:"\f393"}.ion-time:before{content:"\f394"}.ion-timer:before{content:"\f395"}.ion-today:before{content:"\f17d"}.ion-train:before{content:"\f396"}.ion-transgender:before{content:"\f397"}.ion-trash:before{content:"\f398"}.ion-trending-down:before{content:"\f399"}.ion-trending-up:before{content:"\f39a"}.ion-trophy:before{content:"\f39b"}.ion-tv:before{content:"\f17f"}.ion-umbrella:before{content:"\f39c"}.ion-undo:before{content:"\f39d"}.ion-unlock:before{content:"\f39e"}.ion-videocam:before{content:"\f39f"}.ion-volume-high:before{content:"\f123"}.ion-volume-low:before{content:"\f131"}.ion-volume-mute:before{content:"\f3a1"}.ion-volume-off:before{content:"\f3a2"}.ion-walk:before{content:"\f3a4"}.ion-wallet:before{content:"\f18f"}.ion-warning:before{content:"\f3a5"}.ion-watch:before{content:"\f3a6"}.ion-water:before{content:"\f3a7"}.ion-wifi:before{content:"\f3a8"}.ion-wine:before{content:"\f3a9"}.ion-woman:before{content:"\f3aa"}div.tamper{align-items:center;background-color:rgba(0,0,0,0.85);box-sizing:border-box;cursor:default;display:flex;font-size:14px !important;height:100%;justify-content:center;left:0;position:fixed;top:0;text-align:left;width:100%;z-index:900000}div.tamper>div{background-color:white;box-sizing:border-box;padding:1em;width:360px}div.tamper>div.doc{padding-left:1.1em;width:720px}div.tamper a,div.tamper h1,div.tamper h2,div.tamper h3,div.tamper h4,div.tamper h5,div.tamper h6{color:#333 !important}div.tamper h1{font-size:1.8rem;font-weight:400;margin:10px 0 20px 0;text-align:center}div.tamper form{display:block}div.tamper form>div{padding:.5em 0}div.tamper form>div>div{margin:.5em 0}div.tamper form>div>div:last-child{margin-bottom:0}div.tamper form label{color:#000;font-weight:normal;margin:0;vertical-align:middle}div.tamper form label:first-child{display:block;margin-bottom:.5em}div.tamper form label:first-child:before{content:"\00bb";margin:0 .25em}div.tamper form label:not(:first-child){display:inline}div.tamper form input{box-shadow:none;color:#000}div.tamper form input[type=text]{background-color:#fff;border:1px solid #ddd;box-sizing:border-box;display:block;font-size:1em;padding:.5em;width:100%}div.tamper form input[type=text]:focus{border:1px solid #59c1f0}div.tamper form input[type=password]{background-color:#fff;border:1px solid #ddd;box-sizing:border-box;display:block;font-size:1em;padding:.5em;width:100%}div.tamper form input[type=password]:focus{border:1px solid #59c1f0}div.tamper form input[type=radio],div.tamper form input[type=checkbox]{display:inline-block !important;height:1em;margin-right:.25em;vertical-align:text-bottom;width:1em}div.tamper form input[type=checkbox]{-webkit-appearance:checkbox !important}div.tamper form input[type=radio]{-webkit-appearance:radio !important}div.tamper ul{margin:.5em;padding:0;list-style-type:disc;list-style-position:inside;max-height:520px;overflow-y:auto;scrollbar-width:thin}div.tamper ul>li{box-sizing:content-box;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;padding:.25em 0;cursor:default}div.tamper ul>li.on{color:#f45a8d}div.summary{color:#666;text-align:justify}div.btn-group{box-sizing:border-box;display:inline-flex}div.btn-group.full{display:flex}div.btn-group.outline>button{background-color:#fff;border:1px solid #ccc;color:#000}div.btn-group.outline>button:hover{color:#ffffff;background-color:#000;border-color:#000}div.btn-group.outline>button:not(:first-child){border-left:none}div.btn-group>button{background-color:#666;border-radius:0;border:none;color:#fff;display:inline-block;flex:1 1 auto;margin:0;outline:none;padding:.5em 1.25em;position:relative;font-size:inherit}div.btn-group>button:hover{background-color:#000}div.btn-group>button:first-child{border-bottom-left-radius:.25rem;border-top-left-radius:.25rem}div.btn-group>button:last-child{border-bottom-right-radius:.25rem;border-top-right-radius:.25rem}.mt1{margin-top:10px}@keyframes spinner{0%{transform:rotate(0)}100%{transform:rotate(360deg)}}.spinner{animation-name:spinner;animation-duration:2400ms;animation-timing-function:linear;animation-iteration-count:infinite}body{cursor:default}.player-mask{display:none}.media-rating{display:none}.btn-rating{display:none}.review-module{display:none}.media-right{height:auto !important}.btn-follow{display:none}.bilibili-player-ending-panel{display:none !important}.bilibili-player-video-top-follow{display:none !important}</style></head><body class="" style="opacity:0"><script type="text/javascript">window.bid=13,window.spmReportData={},window.reportConfig={sample:1,scrollTracker:true,msgObjects:"spmReportData",errorTracker:true,hasAbtest:true,abtestPlatform:4};</script><script type="text/javascript" src="//s1.hdslb.com/bfs/seed/log/report/log-reporter.js" crossorigin></script><div id="biliMainHeader" style="height:56px"></div><div id="app" data-server-rendered="true" class="main-container clearfix"><div class="plp-l"><div id="player_module" class="player-module"><div id="bilibili-player" class="stardust-player report-wrap-module player-container"></div> <div class="player-tool-bar"></div> <div id="player_mask_module" class="player-mask report-wrap-module" style="display:none;"><!----> <!----> <!----> <!----> <!----> <!----> <!----> <div class="bar-wrapper"><div class="left-bar"></div><div class="right-bar"></div></div></div></div> <div class="media-wrapper"><h1 title="哔哩哔哩番剧">哔哩哔哩番剧</h1> <div id="toolbar_module" class="tool-bar clearfix report-wrap-module report-scroll-module"><div class="like-info"><i class="iconfont icon-like"></i><span>点赞</span> <div id="sanlin"></div> <!----> <!----> <!----></div> <div class="coin-info"><i class="iconfont icon-coins"></i><span>--</span></div> <div class="share-info"><i class="iconfont icon-share"></i><span>分享</span> <!----></div> <div class="mobile-info"><i class="iconfont icon-mobile-full"></i><span>用手机观看</span> <!----></div> <!----></div> <div id="media_module" class="media-info clearfix report-wrap-module"><a href="//www.bilibili.com/bangumi/media/md___mediaInfoId___/" target="_blank" class="media-cover"><!----></a> <div class="media-right"><a href="//www.bilibili.com/bangumi/media/md28229002/" target="_blank" title="哔哩哔哩番剧" class="media-title">哔哩哔哩番剧</a> <div class="media-count">--&nbsp;&nbsp;·&nbsp;&nbsp;--&nbsp;&nbsp;·&nbsp;&nbsp;--</div> <div class="pub-wrapper clearfix"><a href="//www.bilibili.com/anime/" target="_blank" class="home-link">番剧</a> <span class="pub-info">连载中</span> <!----> <!----></div> <a href="//www.bilibili.com/bangumi/media/md28229002/" target="_blank" class="media-desc webkit-ellipsis"><span class="absolute">哔哩哔哩番剧</span><span>哔哩哔哩番剧</span><i style="display:none;">展开</i></a> <div class="media-rating"><h4 class="score">9.7</h4> <p>1368人评分</p></div> <div class="media-tool-bar clearfix"><div report-id="click_review_publish" class="btn-rating"><ul class="star-wrapper clearfix"><li><i class="iconfont icon-star-empty"></i> <!----></li><li><i class="iconfont icon-star-empty"></i> <!----></li><li><i class="iconfont icon-star-empty"></i> <!----></li><li><i class="iconfont icon-star-empty"></i> <!----></li><li><i class="iconfont icon-star-empty"></i> <!----></li></ul><span>点评</span></div> <div report-id="click_follow" class="btn-follow"><i class="iconfont icon-follow"></i><span>追番</span> <div class="bangumi-options clearfix"><ul class="opt-list"><li>标记为 想看</li> <li>标记为 在看</li> <li>标记为 已看</li> <li>取消追番</li></ul></div></div></div></div></div></div> <div id="review_module" class="review-module report-wrap-module report-scroll-module"><div class="module-title clearfix"><h4>点评</h4> <a href="//www.bilibili.com/bangumi/media/md28229002/" target="_blank" class="more-link">查看全部</a></div> <div class="review-list"><div class="review-item"><div class="review-empty pre-mask"></div> <!----></div><div class="review-item"><div class="review-empty pre-mask"></div> <!----></div><div class="review-item"><div class="review-empty pre-mask"></div> <!----></div> <!----></div></div> <!----> <div id="comment_module" class="comment-wrapper common report-wrap-module report-scroll-module" style="display:;"><div class="b-head"><span class="results"></span><span>评论</span></div> <div class="comm"></div></div></div> <div class="plp-r"><div id="paybar_module" class="pay-bar report-wrap-module pre-mask" style="display:none;"><!----> <!----> <!----> <!----> <!----> <!----></div> <div id="danmukuBox" class="danmaku-box" style="display:;"><div class="danmaku-wrap"></div></div> <div id="eplist_module" class="ep-list-wrapper report-wrap-module"><div class="list-title clearfix"><h4 title="选集">选集</h4> <span class="mode-change" style="position:relative"><i report-id="click_ep_switch" class="iconfont icon-ep-list-simple"></i> <!----></span> <!----> <span class="ep-list-progress">1/220</span></div> <div class="list-wrapper simple" style="display:none;"><ul class="clearfix" style="height:50px;"></ul></div></div>  <div class="omit-hint" style="display:none;">部分集数受地区限制不予展示</div> <!----> <div id="recom_module" class="recom-wrapper report-wrap-module report-scroll-module"><div class="recom-title">相关推荐</div> <div class="recom-list"><div class="recom-item clearfix"><div class="cover-wrapper pre-mask"></div> <!----> <div class="info-wrapper"><div class="video-title pre-mask"></div> <div class="video-subtitle pre-mask"></div> <div class="video-count pre-mask"></div></div> <!----></div><div class="recom-item clearfix"><div class="cover-wrapper pre-mask"></div> <!----> <div class="info-wrapper"><div class="video-title pre-mask"></div> <div class="video-subtitle pre-mask"></div> <div class="video-count pre-mask"></div></div> <!----></div><div class="recom-item clearfix"><div class="cover-wrapper pre-mask"></div> <!----> <div class="info-wrapper"><div class="video-title pre-mask"></div> <div class="video-subtitle pre-mask"></div> <div class="video-count pre-mask"></div></div> <!----></div><div class="recom-item clearfix"><div class="cover-wrapper pre-mask"></div> <!----> <div class="info-wrapper"><div class="video-title pre-mask"></div> <div class="video-subtitle pre-mask"></div> <div class="video-count pre-mask"></div></div> <!----></div><div class="recom-item clearfix"><div class="cover-wrapper pre-mask"></div> <!----> <div class="info-wrapper"><div class="video-title pre-mask"></div> <div class="video-subtitle pre-mask"></div> <div class="video-count pre-mask"></div></div> <!----></div></div> <!----></div></div> <div class="nav-tools" style="display:none;"><div title="返回顶部" class="tool-item backup iconfont icon-up"></div> <!----> <a title="帮助反馈" href="//www.bilibili.com/blackboard/help.html#常见问题自救方法?id=c9954d53034d43d796465e24eb792593" target="_blank"><div class="tool-item help iconfont icon-customer-serv"></div></a></div> <!----> <!----> <!----> <!----> <!----> <!----> <!----> <!----> <!----> <!----></div><script>const vipExpire=Date.now()+9e7;window.__PGC_USERSTATE__={area_limit:1,ban_area_show:1,follow:0,follow_status:2,login:1,pay:0,pay_pack_paid:0,sponsor:0,vip_info:{due_date:vipExpire,status:1,type:2}},window.__BILI_CONFIG__={show_bv:true};</script><script>window.__INITIAL_STATE__={"loginInfo":{},"isLogin":false,"couponSelected":null,"payGlobal":null,"loaded":true,"ver":{},"ssr":{},"h1Title":"哔哩哔哩番剧","mediaInfo":{"stat":{"coins":3444,"danmakus":8325,"favorites":75951,"likes":0,"reply":2614,"share":515,"views":786346},"id":___mediaInfoId___,"ssId":___ssId___,"title":"___mediaInfoTitle___","jpTitle":"","series":"哔哩哔哩番剧","alias":"","evaluate":"___evaluate___","ssType":1,"ssTypeFormat":{"name":"番剧","homeLink":"\u002F\u002Fwww.bilibili.com\u002Fanime\u002F"},"status":2,"multiMode":true,"forceWide":false,"specialCover":"","squareCover":"\u002F\u002Fi0.hdslb.com\u002Fbfs\u002Fbangumi\u002Fimage\u002Ff22bfaf955d4938d426029582fdd2303e6844a09.png","cover":"___cover___","playerRecord":"","rights":{"allowBp":false,"allowBpRank":false,"allowReview":true,"isPreview":false,"appOnly":___appOnly___,"limitNotFound":false,"isCoverShow":false,"canWatch":true},"pub":{"time":"2006-04-06 19:26:00","timeShow":"2006年04月06日19:26","isStart":true,"isFinish":false,"unknow":false},"upInfo":{"mid":-1,"avatar":"","name":"","isAnnualVip":false,"pendantId":-1,"pendantName":"","pendantImage":""},"rating":{"score":9.7,"count":1368},"newestEp":{"id":331925,"desc":"连载中","isNew":false},"payMent":{"tip":"","promotion":"","vipProm":"","vipFirstProm":"","discount":1,"vipDiscount":1,"sixType":{"allowTicket":false,"allowTimeLimit":false,"allowDiscount":false,"allowVipDiscount":false}},"payPack":{"title":"","appNoPayText":"","appPayText":"","url":""},"activity":{"id":0,"title":"","pendantOpsImg":"","pendantOpsLink":""},"count":{"coins":0,"danmus":0,"follows":0,"views":0,"likes":0},"pgcType":"anime","epSpMode":true,"newEpSpMode":false,"mainSecTitle":"选集","premiereInfo":{},"sectionBottomDesc":""},"epList":___episodes___,"epInfo":{"loaded":true,"id":___id___,"badge":"","badgeType":0,"badgeColor":"#999999","epStatus":2,"aid":___aid___,"bvid":"___bvid___","cid":___cid___,"from":"bangumi","cover":"\u002F\u002Fi0.hdslb.com\u002Fbfs\u002Farchive\u002F65dc2aa1781fbb507dbb7faef1d0a6169162ffed.jpg","title":"___title___","titleFormat":"___titleFormat___","vid":"","longTitle":"","hasNext":true,"i":0,"sectionType":0,"releaseDate":"","skip":{},"hasSkip":false,"rights":{"allow_demand":0,"allow_dm":0,"allow_download":0,"area_limit":1},"stat":{}},"sections":[],"orderSections":[],"ssList":[{"id":33577,"title":"TV","type":1,"pgcType":"anime","cover":"\u002F\u002Fi0.hdslb.com\u002Fbfs\u002Fbangumi\u002Fimage\u002Fed473b3c6ccc653074e66a3f586bb960c25a9707.png","epCover":"\u002F\u002Fi0.hdslb.com\u002Fbfs\u002Farchive\u002F5dae515b205b46feb2f69c0f2f79f95c1ca234d8.png","desc":"更新至第2话","badge":"","badgeType":0,"badgeColor":"#FB7299","views":786346,"follows":75946}],"userState":{"loaded":false,"vipInfo":{},"history":{}},"ssPayMent":{},"epPayMent":null,"player":{"loaded":false,"miniOn":false,"limitType":0},"sponsor":{"allReady":false,"allState":0,"allRank":[],"allMine":null,"allCount":0,"weekReady":false,"weekState":0,"weekRank":[],"weekMine":null,"weekCount":0},"ssRecom":{"status":"loading","data":[]},"showBv":false,"interact":{"shown":false,"btnText":"","callback":null},"nextEp":null,"playerEpList":{"code":0,"message":"","result":{"main_section":{"episodes":[]}}},"isOriginal":false,"premiereCountDown":"","premiereStatus":{},"premiereEp":{},"likeMap":{},"uperMap":{},"hasPlayableEp":false,"insertScripts":["\u002F\u002Fs1.hdslb.com\u002Fbfs\u002Fstatic\u002Fpgcv\u002F1.video.d78d6e85da752e622f857a963ae79be916fe4c01.js","\u002F\u002Fs1.hdslb.com\u002Fbfs\u002Fstatic\u002Fpgcv\u002Fvideo.d78d6e85da752e622f857a963ae79be916fe4c01.js"]};</script><script>if(window.__INITIAL_STATE__){var jsUrls=window.__INITIAL_STATE__.insertScripts||[];function insertLink(){for(var e=["//static.hdslb.com/phoenix/dist/css/comment.min.css?v="+Date.now(),"//pay.bilibili.com/paysdk/bilipay.css"],i=0;i<e.length;i++){var t=document.createElement("link");t.rel="stylesheet",t.type="text/css",t.href=e[i],document.body.appendChild(t)}}function insertScript(){if(!(window.scriptIsInject||jsUrls[0]&&-1<window.document.body.innerHTML.indexOf(jsUrls[0]))){window.scriptIsInject=!0,window.jQuery||jsUrls.unshift("//static.hdslb.com/js/jquery.min.js"),window.Promise||jsUrls.unshift("//static.hdslb.com/js/promise.auto.min.js"),jsUrls.push("//s1.hdslb.com/bfs/static/ogv/fe/iris.min.js?v=20210112.1");for(var e=0;e<jsUrls.length;e++){loadScript(jsUrls[e])}}}function loadScript(e,i){var t=document.createElement("script");t.type="text/javascript",-1==(t.src=e).indexOf("jquery")&&-1==e.indexOf("promise")&&(t.crossOrigin="true"),document.body.appendChild(t),t.onload=function(){i&&i()}}var ep=window.__INITIAL_STATE__&&window.__INITIAL_STATE__.epInfo,md=window.__INITIAL_STATE__&&window.__INITIAL_STATE__.mediaInfo;function getCookie(e){var i=new RegExp("(^| )"+e+"=([^;]*)(;|$)"),t=document.cookie.match(i);return t?unescape(t[2]):null}function setSize(){var e=md.specialCover?1070:1280,i=350,t=window.innerHeight||document.documentElement.clientHeight,o=window.innerWidth||window.document.documentElement.clientWidth,n=Math.round(md.specialCover?16*(t-264)/9-i:16*(0.743*t-108.7)/9),d=o-152-i,s=d<n?d:n;s<638&&(s=638),e<s&&(s=e);var a=s+i,r=o<a+152,l=document.querySelector(".main-container");if(l.style.width=(r?a+76:a)+"px",l.style.paddingLeft=(r?76:0)+"px",l.style.marginLeft=r?"0":"",l.style.marginRight=r?"0":"",md.specialCover){var p=Math.round(9*a/16+46);(y=document.querySelector("#player_module")).style.height=p+"px",y.style.width=a+"px",y.style.paddingLeft="",y.style.left=r?"76px":"",y.style.transform=r?"none":"",y.style.webkitTransform=r?"none":"";var _=document.querySelector(".special-cover"),w=document.querySelector(".plp-l"),c=document.querySelector(".plp-r"),m=document.querySelector("#danmukuBox");_.style.height=p+218+"px",w.style.paddingTop=p+24+"px",c.style.marginTop=p+40+"px",window.isWide?(m.style.top="0px",m.style.position="relative"):(m.style.top=-(p+40)+"px",m.style.position="absolute")}else{var u=parseInt(9*(s+(window.isWide?i:0))/16)+46+(window.hasBlackSide&&!window.isWide?96:0);if((m=document.querySelector("#danmukuBox")).style.top="",window.isWide){(y=document.querySelector("#player_module")).style.height=u-0+"px",y.style.width="",y.style.paddingLeft=r?"76px":"",y.style.left="",y.style.transform="",y.style.webkitTransform="";w=document.querySelector(".plp-l"),c=document.querySelector(".plp-r");w.style.paddingTop=u-0+"px",c.style.marginTop=u+16+"px"}else{var y;(y=document.querySelector("#player_module")).style.height=u-0+"px",y.style.width="",y.style.paddingLeft="",y.style.left="",y.style.transform="",y.style.webkitTransform="";w=document.querySelector(".plp-l"),c=document.querySelector(".plp-r");w.removeAttribute("style"),c.removeAttribute("style")}}}if(window.isWide=md.forceWide||!!md.specialCover||!md.multiMode,window.hasBlackSide=Boolean(parseInt(getCookie("blackside_state"))),window.PlayerAgent={player_widewin:function(){window.isWide=!0,setSize()},player_fullwin:function(){window.isWide=!1,setSize()},toggleBlackSide:function(e){window.hasBlackSide=e,setSize()}},setSize(),window.document.body.style.opacity="",window.addEventListener("resize",setSize),!(ep&&ep.loaded&&-1<ep.id)||md.rights.appOnly||md.premiereInfo&&md.premiereInfo.epid===ep.id){insertScript()}else{var r=function(s){window.pgcPlayerLoaded=!0;var e=window.__PGC_USERSTATE__.vip_info||{},a=window.__PGC_USERSTATE__.login&&(1===window.__PGC_USERSTATE__.pay||1===window.__PGC_USERSTATE__.sponsor||1===window.__PGC_USERSTATE__.pay_pack_paid||0!==e.type&&1===e.status);window.playerCallback=function(){window.jwTimer=setInterval(function(){var e=window.document.querySelector("#player_placeholder");"function"==typeof e.jwAddEventListener&&(e.jwAddEventListener("jwplayerMediaComplete","function(){ window.showPreviewMask();}"),clearInterval(window.jwTimer))},1000);var e=function(){window.player&&"function"==typeof window.player.addEventListener&&(window.player.addEventListener("video_media_play",function(){window.hadVideoPlay=!0}),window.player.addEventListener("video_media_seek",function(){window.hadVideoPlay=!0}),clearInterval(window.vMediaPTimer))};window.vMediaPTimer=setInterval(e,1000),e()},window.getPlayerExtraParams=function(){var e=window.__PGC_USERSTATE__.paster||{},i=ep.skip||{},t=window.__PGC_USERSTATE__.progress||{last_ep_id:-1},o=!1;o=!window.hadVideoPlay&&(t.last_ep_id<0&&!t.last_ep_index&&!t.last_time);var n=window.__PGC_USERSTATE__&&window.__PGC_USERSTATE__.epsToastType,d=window.__PGC_USERSTATE__&&window.__PGC_USERSTATE__.toastTypeMap;return{title:ep.longTitle?ep.titleFormat+" "+ep.longTitle:ep.titleFormat,mediaTitle:md.title,epTitle:ep.longTitle,epIndex:ep.titleFormat,epCover:ep.cover,epStat:ep.epStatus||md.status,squarePic:md.squareCover||"//static.hdslb.com/images/square-cover-default.png",record:0!==ep.sectionType?"":md.playerRecord?encodeURIComponent(md.playerRecord):"",shareText:window.__INITIAL_STATE__.h1Title+" #哔哩哔哩#",sharePic:md.cover,shareUrl:"//www.bilibili.com/bangumi/play/ss"+md.ssId+"/",isStart:md.pub.isStart||!md.rights.canWatch&&0!==ep.sectionType,isPreview:md.rights.isPreview&&s,allowTicket:md.payMent.sixType.allowTicket,deadLineToast:md.payMent.sixType.allowTimeLimit&&!s&&window.__PGC_USERSTATE__.dead_line?window.__PGC_USERSTATE__.dead_line:undefined,canPlay1080:a,allowSponsor:md.rights.allowBp,multiMode:md.multiMode,epNeedPay:s,isFollow:1===window.__PGC_USERSTATE__.follow,canWatch:md.rights.canWatch,sponsorWeekList:[],sponsorTotalList:[],sponsorCount:0,danmakuListOffset:md.specialCover?0:64,paster:{aid:ep.aid||0,cid:e.aid||0,type:e.type||0,duration:e.duration||0,allow_jump:e.allow_jump||0,url:e.url?e.url:""},pubTime:md.pub.timeShow,recommend:[],epList:{},nextEp:null,headTail:{first:!!window.__PGC_USERSTATE__.login&&o,op:[i.op&&i.op.start||0,i.op&&i.op.end||0],ed:[i.ed&&i.ed.start||0,i.ed&&i.ed.end||0],hasSkip:ep.hasSkip||!1},whitelistToast:n&&d&&"white_can_watch"===n[ep.id]&&d[n[ep.id]]&&d[n[ep.id]].text_info,preSaleToast:n&&d&&"presell"===n[ep.id]&&d[n[ep.id]]&&d[n[ep.id]].text_info}};var i,t,o;if("bangumi"===ep.from){var n=(i=new RegExp("(^|&)"+"t"+"=([^&|^#]*)(&|#|$)"),t=window.location.href.split("?"),null!==(o=(1<t.length?t[1]:"").match(i))?unescape(o[2]):""),d=window.__PGC_USERSTATE__.progress||{},r=d.last_time||0,l=-1<d.last_ep_id?d.last_ep_id:undefined,p=encodeURIComponent("module="+(2!==md.ssType?"bangumi":"movie")+"&season_type="+md.ssType),_=(1===(e=window.__PGC_USERSTATE__.vipInfo||{}).type||2===e.type)&&1===e.status,w=window.__PGC_USERSTATE__.paster||{},c=!_&&1!==window.__PGC_USERSTATE__.pay&&1!==window.__PGC_USERSTATE__.sponsor&&w.cid&&0<w.cid?1:undefined,m=window.__BILI_CONFIG__&&window.__BILI_CONFIG__.show_bv&&ep.bvid?"&bvid="+ep.bvid+"&show_bv=1":"",u="cid="+ep.cid+"&aid="+ep.aid+m+"&season_type="+md.ssType+(r?"&lastplaytime="+1000*r:"")+(l?"&last_ep_id="+l:"")+(c?"&pre_ad=1":"")+"&has_next="+(ep.hasNext?1:"")+(window.isWide?"&as_wide=1":"")+"&player_type="+(2!==md.ssType?1:2)+"&urlparam="+p+"&seasonId="+md.ssId+"&episodeId="+ep.id+"&record="+(0!==ep.sectionType?"":md.playerRecord?encodeURIComponent(md.playerRecord):"")+"&t="+n+(ep.attribute?"&attribute="+ep.attribute:"");window.EmbedPlayer("player","//static.hdslb.com/play.swf",u,"","",window.playerCallback)}else{(window.document.querySelector("#bilibili-player")||window.document.querySelector("#bofqi")).innerHTML='<embed height="100%" width="100%" src="//static.hdslb.com/tc.swf" type="application/x-shockwave-flash" pluginspage="//www.adobe.com/shockwave/download/download.cgi?P1_Prod_Version=ShockwaveFlash" allowscriptaccess="always" rel="noreferrer" quality="high" flashvars="bili-cid='+ep.cid+"&amp;bili-aid="+ep.aid+"&amp;vid="+ep.vid+'" allowfullscreen="true">'}},promiseArr=[];if(window.__PGC_USERSTATE__){startPlayer()}else{var cnt=0;function t(){new Promise(function(e){window.$.ajax({url:"//api.bilibili.com/pgc/view/web/season/user/status",type:"get",dataType:"json",xhrFields:{withCredentials:!0},data:{season_id:md.ssId,ts:(new Date).getTime()},success:function(e){0===e.code?window.__PGC_USERSTATE__=e.result||{}:window.__PGC_USERSTATE__={}}}).always(e)}).then(function(){startPlayer()})}window.jQuery||(cnt+=1,loadScript("//static.hdslb.com/js/jquery.min.js",function(){0==--cnt&&t()})),window.Promise||(cnt+=1,loadScript("//static.hdslb.com/js/promise.auto.min.js",function(){0==--cnt&&t()}))}function startPlayer(){var e=!1,i=!0,t=!1;window.__INITIAL_STATE__.sections.forEach(function(e){0<e.epList.length&&(t=!0)});var o=window.__PGC_USERSTATE__.vipInfo||{},n=o&&(1===o.type||2===o.type)&&1===o.status,d=!(6!==ep.epStatus&&7!==ep.epStatus&&13!==ep.epStatus||window.__PGC_USERSTATE__.login&&n),s=12===ep.epStatus&&(!window.__PGC_USERSTATE__.login||1!==window.__PGC_USERSTATE__.pay_pack_paid),a=ep.rights&&ep.rights.allow_demand&&window.__PGC_USERSTATE__.demand&&window.__PGC_USERSTATE__.demand.no_pay_epids&&-1!==window.__PGC_USERSTATE__.demand.no_pay_epids.indexOf(ep.id);if(1!==window.__PGC_USERSTATE__.pay&&(d||8===ep.epStatus||9===ep.epStatus||s)&&(e=!0),a||14===ep.epStatus?e=!0:md.pub.isStart||0!==window.__INITIAL_STATE__.epList.length||t?md.rights.isPreview&&!ep.attribute&&(0<window.__INITIAL_STATE__.epList.length||t)?i=!0:e&&(i=!1):i=!1,i){if("bangumi"===ep.from){var l=setTimeout(function(){clearTimeout(l),window.PlayerMediaLoaded=undefined,insertScript()},4000);window.PlayerMediaLoaded=function(){clearTimeout(l),window.performance&&window.performance.timing&&(window.performance.timing.firstscreenfinish=window.performance.timing.playerStage3||(new Date).getTime()),insertScript(),window.PlayerMediaLoaded=undefined}}else{insertScript()}r(e)}else{insertScript()}}}};</script></body></html>`;
                document.open(), document.write(doc.replaceAll(/___(\w+)___/g, (matched, major) => obj.hasOwnProperty(major) ? obj[major] : major)), document.close();
              }
            });
          })("https://bangumi.bilibili.com/view/web_api/season?" + (s.startsWith("ep") ? "ep_id=" : "season_id=") + id);
        }
        history.pushState = u.history("pushState"), window.addEventListener("pushState", init), history.replaceState = u.history("replaceState"), window.addEventListener("replaceState", init), zproxy(), init();
      }
    }
  } else if ("acg.rip" == location.hostname) {
    function init() {
      ipod.task = setInterval(() => {
        document.querySelector("#czyset") ? (clearInterval(ipod.task), ipod.task = 0, document.querySelectorAll("i.fa-download").forEach(t => {
          t.addEventListener("click", () => {
            let dom = u.zdom(), o = {
              "allow-overwrite": "true",
              "bt-exclude-tracker": "*",
              "max-upload-limit": "64k",
              split: "1",
              dir: ipod.aria2.dir,
              url: []
            };
            o.url.push(u.urlfix(dom.parentElement.getAttribute("href"))), u.aria2([o]);
          });
        })) : (document.querySelector("ul.nav.navbar-nav").insertAdjacentHTML("afterbegin", '<li><a id="czyset" style="cursor: default">A2DH</a></li>'), document.querySelector("#czyset").addEventListener("click", () => {
          u.zdom(), zset();
        }, !1));
      }, 3e3);
    }
    GM_addStyle(String.raw`#bangumi-box,#session-bar,div.footer{display:none}`), ipod.defaults = {
      dir: "D:/HD2A",
      jsonrpc: "http://127.0.0.1:16800/jsonrpc",
      token: ""
    }, ipod.aria2 = u.load("aria2", ipod.defaults), window.addEventListener("urlchange", init), init();
  } else if ("link.zhihu.com" == location.hostname) {
    let o = u.usp(location.search);
    o.hasOwnProperty("target") && (location.href = o.target);
  } else if ("pan.baidu.com" == location.hostname) {
    function initRapid() {
      let dom = document.querySelector("#rapid");
      null == dom ? (document.body.insertAdjacentHTML("beforeend", '<div class="tamper" id="rapid"><div style="width: 500px"><textarea name="rapid" rows="8" cols="100" placeholder="\u5728\u6b64\u5904\u7c98\u8d34\u79d2\u4f20\u7801" wrap="hard" style="resize: none;width: 460px; margin-bottom: 10px; padding:5px; border: 1px solid #666; outline: none"></textarea><div class="btn-group"><button name="close" type="button"><i class="ion-close"></i> \u5173\u95ed</button><button name="checkmark" type="button"><i class="ion-checkmark"></i> \u786e\u5b9a</button></div></div></div>'), document.querySelector("#rapid").style.cssText = "display: flex", document.querySelector("#rapid button[name=close]").addEventListener("click", () => {
        document.querySelector("#rapid").style.cssText = "display: none";
      }), document.querySelector("#rapid button[name=checkmark]").addEventListener("click", uploadRapid)) : dom.style.cssText = "display: flex";
    }
    function uploadRapid() {
      let arr = document.querySelector("#rapid textarea[name=rapid]").value.replaceAll("\r", "").split("\n");
      arr.length && (ipod.path = ipod.dcontext.instanceForSystem.list.getCurrentPath(), ipod.len = arr.length, ipod.idx = 0, arr.forEach(t => {
        let li = t.split("#", 4);
        4 == li.length && li[0].length == li[1].length && fetch(`/api/rapidupload?bdstoken=${ipod.bdstoken}`, {
          headers: {
            "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
          },
          method: "POST",
          mode: "cors",
          credentials: "include",
          body: `rtype=0&path=${ipod.path}/${li[3]}&content-md5=${li[0]}&slice-md5=${li[1]}&content-length=${li[2]}`
        }).then(r => r.json()).then(() => {
          ipod.idx++, ipod.idx == ipod.len && (ipod.dmessage.trigger("system-refresh"), document.querySelector("#rapid textarea").value = "");
        });
      }));
    }
    function dscan(str) {
      let xhr = new XMLHttpRequest();
      xhr.open("GET", "https://pan.baidu.com/rest/2.0/xpan/multimedia?method=listall&web=0&recursion=1&path=" + encodeURI(str), !1), xhr.send();
      let d = JSON.parse(xhr.responseText);
      return 0 == d.errno || (d.list = []), d.list;
    }
    function zymfli(str) {
      ipod.zym.path = str.replaceAll("//", "/");
      let a, b = "", s = '<span data-path="/">root</span>';
      if (ipod.zym.path.length > 1) {
        let arr = ipod.zym.path.split("/").slice(1).map(t => (b += "/" + t, a = t.replaceAll(/\s+/g, "").substring(0, 6), `<span data-path="${b}/">${a}</span>`));
        arr.length > 3 && (arr = arr.slice(arr.length - 3)), s += arr.join("");
      }
      document.querySelector("#zym > div[name=path]").innerHTML = s;
      let arr = JSON.parse(u.loread("fli", "[]")).filter(t => t.path == ipod.zym.path);
      arr.length ? (arr.sort((a, b) => a.name > b.name ? 1 : b.name > a.name ? -1 : 0).sort((a, b) => 0 == a.size ? 0 : 0 == b.size ? 1 : 0), document.querySelector("#fli").innerHTML = u.tpl(ipod.tpl.fli, arr)) : document.querySelector("#fli").innerHTML = "";
    }
    if (ipod.tpl = {
      fli: '<tr data-id="[id]" data-fid="[fid]"><td></td><td>[name]</td><td>[fsize]</td></tr>'
    }, ipod.defaults = {
      host: 1,
      token: "",
      jsonrpc: "http://127.0.0.1:16800/jsonrpc",
      dir: "D:/HD2A"
    }, ipod.aria2 = u.load("aria2", ipod.defaults), "/disk/home" == location.pathname) GM_cookie.list({}, r => {
      let arr = Array.isArray(r) && r.length ? u.cclean(r).reduce((d, t1) => (["BDUSS=", "STOKEN="].some(t2 => t1.includes(t2)) && d.push(t1), d), []) : [];
      arr.length ? (arr.sort(), ipod.cookie = arr.join(";"), ipod.dcontext = unsafeWindow.require("system-core:context/context.js"), ipod.dmessage = unsafeWindow.require("system-core:system/baseService/message/message.js"), ipod.bdstoken = unsafeWindow.locals.get("bdstoken"), ipod.bduid = unsafeWindow.locals.get("uk"), ipod.bduid == GM_getValue("bduid", 0) || GM_setValue("bduid", ipod.bduid), GM_xmlhttpRequest({
        url: `${ipod.home}/baiduyun/ajax?act=vlist`,
        method: "GET",
        responseType: "json",
        onload(r) {
          document.body.insertAdjacentHTML("beforeend", '<div class="tamper" id="vpanel"><div class="w2"><div>\u7ed9\u4e0b\u9762\u7684\u89c6\u9891\u70b9\u8d5e\u53ef\u83b7\u5f97\u4f7f\u7528\u6b21\u6570 &nbsp; \u4f60\u73b0\u5728\u7684\u53ef\u7528\u6b21\u6570\uff1a<span name="uut"></span> &nbsp; \u4ea4\u6d41\u7fa4\uff1a87095249</div><ul id="vlist"></ul></div></div>'), document.querySelector("#vpanel").addEventListener("click", e => {
            "vpanel" == e.target.id && (e.target.style.cssText = "display: none");
          }), 0 == r.response.code && document.querySelector("#vlist").insertAdjacentHTML("afterbegin", u.tpl('<li><a href="[url]" target="_blank" referrerpolicy="no-referrer"><div><img class="pic" src="[pic]@160w_100h_1c.webp" crossorigin="anonymous" referrerpolicy="no-referrer"></div><div class="title">[title]</div></a></li>', r.response.list));
        }
      }), ipod.task = setInterval(() => {
        let dom = document.querySelector("div[node-type=listTopTools]");
        dom && (clearInterval(ipod.task), dom.innerHTML = '<div class="btn-group outline" style="font-size: 12.5px"><button name="zspace"><i class="ion-paw"></i> \u6b21\u5143\u95e8</button><button name="video"><i class="ion-heart"></i> \u70b9\u8d5e</button><button name="flink"><i class="ion-flash"></i> \u79d2\u4f20</button><button name="zset"><i class="ion-settings"></i> \u8bbe\u7f6e</button><button name="dlink"><i class="ion-download"></i> \u4e0b\u8f7d</button></div>', document.querySelector("div.btn-group.outline").addEventListener("click", () => {
          let dom = u.zdom(1);
          switch ("I" == dom.tagName && (dom = dom.parentElement), dom.getAttribute("name")) {
           case "zspace":
            dom.hasAttribute("style") ? (dom.removeAttribute("style"), document.querySelector("#layoutMain").removeAttribute("style"), document.querySelector("#zym").style.cssText = "display: none") : (dom.style.cssText = "color:#fff;background-color:#09aaff;border-color:#09aaff", (() => {
              let dom1 = document.querySelector("#layoutMain");
              null == dom1 || (dom1.style.cssText = "width:" + (dom1.offsetWidth - 430) + "px");
              let dom2 = document.querySelector("#zym");
              null == dom2 ? (() => {
                ipod.zym = {
                  num: 0,
                  size: 0,
                  path: "/"
                }, document.querySelector("#layoutApp").insertAdjacentHTML("beforeend", '<div id="zym"><div class="btn-group outline full"><button name="fdl"><i class="ion-download"></i> \u4e0b\u8f7d</button><button name="fnew"><i class="ion-instagram"></i> \u65b0\u5efa</button><button name="frm"><i class="ion-close-circle-outline"></i> \u5220\u9664</button><button name="fin"><i class="ion-log-in"></i> \u5b58\u5165</button><button name="fout"><i class="ion-log-out"></i> \u53d6\u51fa</button></div><div style="text-align: right">\u5df2\u7528\u5bb9\u91cf\uff1a <span name="usize">0</span> &nbsp; </div><div name="path"></div><div name="full"><table><thead><tr><td width="36"></td><td></td><td width="72"></td></tr></thead><tbody id="fli"></tbody></table></div></div>');
                let dom = document.querySelector("#zym > div[name=full]");
                dom.style.cssText = "height:" + (Math.min(document.body.scrollHeight, window.innerHeight) - dom.offsetTop) + "px", document.querySelector("#fli").addEventListener("click", () => {
                  let dom = u.zdom(1);
                  switch (ipod.checkbox = dom.parentElement, dom.cellIndex) {
                   case 1:
                    0 == ipod.checkbox.getAttribute("data-fid") ? zymfli(ipod.zym.path + dom.textContent + "/") : u.swClassName("on");
                    break;
                   default:
                    u.swClassName("on");
                  }
                }), document.querySelector("#zym > div.btn-group").addEventListener("click", () => {
                  let arr = [], fli = JSON.parse(u.loread("fli", "[]"));
                  switch ("I" == (dom = u.zdom(1)).tagName && (dom = dom.parentElement), ipod.icon = dom.children[0], dom.getAttribute("name")) {
                   case "fdl":
                    if (document.querySelectorAll("#zym tr.on").forEach(t => {
                      arr.push({
                        fid: t.getAttribute("data-fid"),
                        name: "/zym/" + t.children[1].textContent
                      });
                    }), 1 == (arr = arr.filter(t => "0" != t.fid)).length) {
                      let fi = arr[0];
                      ipod.lazy ? alert("\u6b63\u5728\u6267\u884c\u4efb\u52a1\u4e2d") : (ipod.lazy = 1, ipod.icon.className = "ion-refresh spinner", fetch(`/api/filemanager?opera=delete&async=1&bdstoken=${ipod.bdstoken}`, {
                        headers: {
                          "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
                        },
                        method: "POST",
                        mode: "cors",
                        credentials: "include",
                        body: u.serialize({
                          filelist: JSON.stringify([fi.name])
                        })
                      }).then(r => r.json()).then(() => {
                        GM_xmlhttpRequest({
                          method: "POST",
                          responseType: "json",
                          url: `${ipod.home}/baiduyun/ajax?act=foutSingle`,
                          headers: {
                            "Content-type": "application/x-www-form-urlencoded"
                          },
                          data: u.serialize({
                            uid: ipod.bduid,
                            cookie: ipod.cookie,
                            fid: fi.fid
                          }),
                          onload(r) {
                            let d = r.response;
                            0 == d.code ? (Object.assign(fi, d.fi), fetch(`/api/rapidupload?bdstoken=${ipod.bdstoken}`, {
                              headers: {
                                "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
                              },
                              method: "POST",
                              mode: "cors",
                              credentials: "include",
                              body: `rtype=0&path=${fi.name}&content-md5=${fi.a}&slice-md5=${fi.b}&content-length=${fi.size}`
                            }).then(r => r.json()).then(() => {
                              fetch(`/api/list?dir=%2Fzym&bdstoken=${ipod.bdstoken}`).then(r => r.json()).then(d => {
                                let idx = d.list.findIndex(t => fi.name == t.path);
                                -1 == idx ? (ipod.lazy = 0, ipod.icon.className = "ion-download", alert("\u8bf7\u91cd\u8bd5\u4e00\u6b21")) : fetch(`/rest/2.0/xpan/multimedia?method=filemetas&dlink=1&fsids=[${d.list[idx].fs_id}]`).then(r => r.json()).then(d => {
                                  0 == d.errno ? GM_xmlhttpRequest({
                                    method: "POST",
                                    responseType: "json",
                                    url: `${ipod.home}/baiduyun/ajax?act=single4baidu`,
                                    headers: {
                                      "Content-type": "application/x-www-form-urlencoded"
                                    },
                                    data: u.serialize({
                                      fe: JSON.stringify(d.list[0]),
                                      cookie: ipod.cookie,
                                      host: ipod.aria2.host,
                                      uid: ipod.bduid,
                                      version: ipod.version
                                    }),
                                    onload(r) {
                                      ipod.lazy = 0, ipod.icon.className = "ion-download";
                                      let d = r.response;
                                      0 == d.code && (d.dlink.dir = ipod.aria2.dir, d.dlink.out = d.dlink.out.replace("zym/", ""), u.aria2([d.dlink]));
                                    }
                                  }) : (ipod.lazy = 0, ipod.icon.className = "ion-download", alert("\u8bf7\u91cd\u8bd5\u4e00\u6b21"));
                                });
                              });
                            })) : (ipod.lazy = 0, ipod.icon.className = "ion-download", console.log(d));
                          }
                        });
                      }));
                    } else alert("\u6b64\u529f\u80fd\u7528\u4e8e\u5c1d\u8bd5\u4e0b\u8f7d\u53d7\u9650\u6587\u4ef6\uff0c\u4ec5\u652f\u6301\u52fe\u9009\u5355\u4e2a\u6587\u4ef6\u3002\n\u8fd9\u91cc\u8bf4\u7684\u53d7\u9650\u6587\u4ef6\u4e0d\u662f\u6307\u88ab\u6cb3\u87f9\u7684\u6587\u4ef6\uff0c\u800c\u662f\u4e00\u4e9b\u9700\u8981\u7528\u5b98\u65b9\u5ba2\u6237\u7aef\uff0c\n\u751a\u81f3\u662f\u6307\u5b9a\u7248\u672c\u4ee5\u4e0a\u7684\u5ba2\u6237\u7aef\u624d\u53ef\u4ee5\u6b63\u5e38\u4e0b\u8f7d\u7684\u6587\u4ef6\u3002\u800c\u4e14\u6587\u4ef6\u7684\u53d7\u9650\n\u72b6\u6001\u4e5f\u662f\u4e34\u65f6\u7684\uff0c\u5373\u5f53\u524d\u65f6\u95f4\u4e0d\u80fd\u4e0b\u8f7d\u4f46\u8fc7\u51e0\u5c0f\u65f6\u540e\u6216\u51e0\u5929\u5c31\u53ef\u4ee5\u4e0b\u8f7d\n\u4e86\u3002\u7c7b\u4f3c\u4e8e\u6587\u4ef6\u88ab\u4e34\u65f6\u9501\u5b9a\u4e86\uff0c\u4e14\u662f\u5206\u7ea7\u7684\uff0c\u6240\u4ee5\u5728\u8fd9\u91cc\u4e5f\u4e0d\u662f\u6240\u6709\u53d7\n\u9650\u6587\u4ef6\u90fd\u53ef\u4e0b\u8f7d\u7684\uff0c\u9700\u8981\u770b\u53d7\u9650\u7b49\u7ea7\u3002");
                    break;
                   case "fnew":
                    document.querySelector("#fli").insertAdjacentHTML("afterbegin", '<tr data-fid="0"><td></td><td><input name="filename" type="text" placeholder="\u8bf7\u8f93\u5165\u6587\u4ef6\u5939\u540d\u79f0"></td><td></td></tr>');
                    let dom = document.querySelector("#fli input");
                    dom.focus(), dom.addEventListener("keypress", e => {
                      if (13 == e.charCode) {
                        let s = u.namefix(e.target.value);
                        3 > s.length ? e.target.closest("tr").remove() : GM_xmlhttpRequest({
                          method: "POST",
                          responseType: "json",
                          url: `${ipod.home}/baiduyun/ajax?act=fnew`,
                          headers: {
                            "Content-type": "application/x-www-form-urlencoded"
                          },
                          data: u.serialize({
                            uid: ipod.bduid,
                            cookie: ipod.cookie,
                            path: ipod.zym.path,
                            name: s
                          }),
                          onload(r) {
                            let d = r.response;
                            if (0 == d.code) {
                              let dom = e.target.parentElement;
                              e.target.remove(), dom.innerText = s;
                              let arr = JSON.parse(localStorage.getItem("fli"));
                              arr.unshift({
                                id: d.message,
                                fid: 0,
                                fsize: "",
                                name: s,
                                path: ipod.zym.path,
                                size: 0
                              }), localStorage.setItem("fli", JSON.stringify(arr));
                            }
                          }
                        });
                      }
                    });
                    break;
                   case "frm":
                    document.querySelectorAll("#zym tr.on").forEach(t1 => {
                      if (arr.push(t1.getAttribute("data-id")), "0" == t1.getAttribute("data-fid")) {
                        let folder = t1.children[1].textContent, path = "/" == ipod.zym.path ? `/${folder}` : `${ipod.zym.path}/${folder}`;
                        fli.forEach(t2 => {
                          t2.path.startsWith(path) && arr.push(t2.id);
                        });
                      }
                    }), arr.length && GM_xmlhttpRequest({
                      method: "POST",
                      responseType: "json",
                      url: `${ipod.home}/baiduyun/ajax?act=frm`,
                      headers: {
                        "Content-type": "application/x-www-form-urlencoded"
                      },
                      data: u.serialize({
                        uid: ipod.bduid,
                        cookie: ipod.cookie,
                        list: JSON.stringify(arr)
                      }),
                      onload(r) {
                        let d = r.response;
                        0 == d.code ? (fli = fli.filter(t => !arr.includes(t.id)), u.losave("fli", JSON.stringify(fli)), ipod.zym.size = 0, fli.forEach(t => {
                          ipod.zym.size += Math.ceil(t.size / 1e6);
                        }), document.querySelector("span[name=usize]").innerText = u.fsize(ipod.zym.size, 2), zymfli(ipod.zym.path)) : alert(d.message);
                      }
                    });
                    break;
                   case "fin":
                    ipod.lazy ? alert("\u6b63\u5728\u6267\u884c\u4efb\u52a1\u4e2d") : 0 == (arr = ipod.dcontext.instanceForSystem.list.getSelected().reduce((d, t) => (t.isdir ? d = d.concat(dscan(t.path)) : d.push(t), d), []).filter(t => !t.isdir).map(t => t.fs_id)).length ? alert("\u672a\u5728\u5de6\u4fa7\u52fe\u9009\u6587\u4ef6") : 64 > arr.length ? fetch("https://pan.baidu.com/rest/2.0/xpan/multimedia?method=filemetas&dlink=1&fsids=" + JSON.stringify(arr)).then(r => r.json()).then(d => {
                      0 == d.errno && (ipod.lazy = 1, ipod.icon.className = "ion-refresh spinner", ipod.path = ipod.dcontext.instanceForSystem.list.getCurrentPath(), ipod.list = [], ipod.idx = 0, ipod.len = d.list.length, d.list.forEach(t => {
                        GM_xmlhttpRequest({
                          url: t.dlink,
                          method: "GET",
                          headers: {
                            Range: "bytes=0-" + (262144 > t.size ? t.size - 1 : 262143),
                            "User-Agent": "LogStatistic"
                          },
                          responseType: "arraybuffer",
                          onload(r) {
                            if (r.statusText.includes("Intercepted")) ipod.lazy = 0, ipod.icon.className = "ion-log-in"; else {
                              let b, a = r.responseHeaders.match(/content-md5: ([\da-f]{32})/i)[1], spark = new SparkMD5.ArrayBuffer();
                              if (262144 > t.size ? b = a : (spark.append(r.response), b = spark.end()), ipod.list.push({
                                a,
                                b,
                                fid: t.fs_id,
                                size: t.size,
                                name: t.filename,
                                path: (ipod.zym.path + t.path.replace(ipod.path, "").replace(t.filename, "")).replaceAll("//", "/")
                              }), ipod.idx++, ipod.idx == ipod.len) {
                                let arr = ipod.list.map(t => t.path).filter((t, idx, self) => self.indexOf(t) == idx).filter(t => t != ipod.zym.path).map(t => t.slice(0, -1)).map(t => {
                                  let idx = 1 + t.lastIndexOf("/");
                                  return {
                                    fid: "0",
                                    name: t.substring(idx),
                                    path: t.substring(0, idx)
                                  };
                                });
                                ipod.list = ipod.list.concat(arr), GM_xmlhttpRequest({
                                  method: "POST",
                                  responseType: "json",
                                  url: `${ipod.home}/baiduyun/ajax?act=fin`,
                                  headers: {
                                    "Content-type": "application/x-www-form-urlencoded"
                                  },
                                  data: u.serialize({
                                    uid: ipod.bduid,
                                    cookie: ipod.cookie,
                                    path: ipod.zym.path,
                                    list: JSON.stringify(ipod.list)
                                  }),
                                  onload(r) {
                                    ipod.lazy = 0, ipod.icon.className = "ion-log-in";
                                    let d = r.response;
                                    if (0 == d.code) {
                                      let fli = JSON.parse(u.loread("fli")), arr = d.list.filter(t1 => {
                                        let reply = !0;
                                        return fli.forEach(t2 => {
                                          t1.name == t2.name && t1.path == t2.path && (reply = !1);
                                        }), reply;
                                      });
                                      fli = fli.concat(arr.map(t => (t.size = Number.parseInt(t.size), ipod.zym.size += Math.ceil(t.size / 1e6), t.fsize = u.fsize(t.size), t))), u.losave("fli", JSON.stringify(fli)), zymfli(ipod.zym.path), document.querySelector("span[name=usize]").innerText = u.fsize(ipod.zym.size, 2);
                                    } else alert(d.message);
                                  }
                                });
                              }
                            }
                          }
                        });
                      }));
                    }) : alert("\u52fe\u9009\u7684\u6587\u4ef6\u6570\u91cf\u8fc7\u591a");
                    break;
                   case "fout":
                    ipod.lazy ? alert("\u6b63\u5728\u6267\u884c\u4efb\u52a1\u4e2d") : (ipod.path = ipod.dcontext.instanceForSystem.list.getCurrentPath(), document.querySelectorAll("#zym tr.on").forEach(t1 => {
                      let fid = t1.getAttribute("data-fid"), name = t1.children[1].textContent;
                      if (0 == fid) {
                        let path = `${ipod.zym.path}${name}/`;
                        fli.forEach(t2 => {
                          t2.path.startsWith(path) && arr.push({
                            id: t2.id,
                            fid: t2.fid,
                            name: ipod.path + "/" + t2.path.replace(ipod.zym.path, "/") + t2.name
                          });
                        });
                      } else arr.push({
                        id: t1.getAttribute("data-id"),
                        fid,
                        name: ipod.path + "/" + name
                      });
                    }), (arr = arr.filter(t => 0 != t.fid)).length && (ipod.lazy = 1, ipod.icon.className = "ion-refresh spinner", GM_xmlhttpRequest({
                      method: "POST",
                      responseType: "json",
                      url: `${ipod.home}/baiduyun/ajax?act=fout`,
                      headers: {
                        "Content-type": "application/x-www-form-urlencoded"
                      },
                      data: u.serialize({
                        uid: ipod.bduid,
                        cookie: ipod.cookie,
                        list: JSON.stringify(arr.map(t => t.id))
                      }),
                      onload(r) {
                        let d = r.response;
                        0 == d.code ? (ipod.idx = 0, ipod.len = d.list.length, d.list.map(t1 => {
                          let idx = arr.findIndex(t2 => t2.fid == t1.fid);
                          return -1 == idx ? console.log("lose the file") : t1.name = arr[idx].name.replaceAll("//", "/"), t1;
                        }).forEach(t => {
                          fetch(`/api/rapidupload?bdstoken=${ipod.bdstoken}`, {
                            headers: {
                              "Content-Type": "application/x-www-form-urlencoded; charset=UTF-8"
                            },
                            method: "POST",
                            mode: "cors",
                            credentials: "include",
                            body: `rtype=0&path=${t.name}&content-md5=${t.a}&slice-md5=${t.b}&content-length=${t.size}`
                          }).then(r => r.json()).then(() => {
                            ipod.idx++, ipod.idx == ipod.len && (ipod.lazy = 0, ipod.icon.className = "ion-log-out", ipod.dmessage.trigger("system-refresh"));
                          });
                        })) : (ipod.lazy = 0, ipod.icon.className = "ion-log-out", alert(d.message));
                      }
                    })));
                  }
                }), document.querySelector("#zym > div[name=path]").addEventListener("click", () => {
                  let dom = u.zdom(1);
                  "SPAN" == dom.tagName && zymfli(dom.getAttribute("data-path"));
                }), GM_xmlhttpRequest({
                  method: "POST",
                  responseType: "json",
                  url: `${ipod.home}/baiduyun/ajax?act=flist`,
                  headers: {
                    "Content-type": "application/x-www-form-urlencoded"
                  },
                  data: u.serialize({
                    uid: ipod.bduid,
                    cookie: ipod.cookie
                  }),
                  onload(r) {
                    let d = r.response;
                    if (0 == d.code) {
                      ipod.zym.num = d.list.length;
                      let arr = d.list.map(t => (t.size = Number.parseInt(t.size), ipod.zym.size += Math.ceil(t.size / 1e6), t.fsize = u.fsize(t.size), t));
                      u.losave("fli", JSON.stringify(arr)), document.querySelector("span[name=usize]").innerText = u.fsize(ipod.zym.size, 2), zymfli("/");
                    }
                  }
                });
              })() : dom2.style.cssText = "display: block";
            })());
            break;
           case "video":
            0 == ipod.lazy && (ipod.lazy = 1, GM_xmlhttpRequest({
              method: "POST",
              responseType: "json",
              url: `${ipod.home}/baiduyun/ajax?act=nubaidu`,
              headers: {
                "Content-type": "application/x-www-form-urlencoded"
              },
              data: u.serialize({
                uid: ipod.bduid,
                cookie: ipod.cookie
              }),
              onload(r) {
                ipod.lazy = 0, document.querySelector("#vpanel span[name=uut]").innerText = r.response.message, document.querySelector("#vpanel").style.cssText = "display: flex";
              }
            }));
            break;
           case "zset":
            zset();
            break;
           case "flink":
            ipod.icon = dom.children[0], (() => {
              if (ipod.lazy) alert("\u6b63\u5728\u6267\u884c\u4efb\u52a1\u4e2d"); else {
                console.clear();
                let arr = ipod.dcontext.instanceForSystem.list.getSelected().reduce((d, t) => (t.isdir ? d = d.concat(dscan(t.path)) : d.push(t), d), []).filter(t => !t.isdir).map(t => t.fs_id);
                0 == arr.length ? alert("\u672a\u52fe\u9009\u6587\u4ef6") : 64 > arr.length ? fetch(`https://pan.baidu.com/rest/2.0/xpan/multimedia?method=filemetas&dlink=1&fsids=${JSON.stringify(arr)}`).then(r => r.json()).then(d => {
                  0 == d.errno ? (ipod.lazy = 1, ipod.icon.className = "ion-refresh spinner", ipod.len = d.list.length, ipod.idx = 0, ipod.list = [], d.list.forEach(t => {
                    GM_xmlhttpRequest({
                      url: t.dlink,
                      method: "GET",
                      headers: {
                        Range: "bytes=0-" + (262144 > t.size ? t.size - 1 : 262143),
                        "User-Agent": "LogStatistic"
                      },
                      responseType: "arraybuffer",
                      onload(r) {
                        if (206 == r.status && "Partial Content" == r.statusText) {
                          r.responseHeaders = r.responseHeaders.replace(/\s+/g, " ");
                          let mat = r.responseHeaders.match(/content-md5: ([\da-f]{32})/i);
                          if (Array.isArray(mat) ? t.a = mat[1] : (mat = r.responseHeaders.match(/etag: ([\da-f]{32})/i), t.a = Array.isArray(mat) ? mat[1] : ""), 262144 > t.size) t.b = t.a; else {
                            let spark = new SparkMD5.ArrayBuffer();
                            spark.append(r.response), t.b = spark.end();
                          }
                          ipod.list.push([t.a, t.b, t.size, u.namefix(t.filename)].join("#")), ipod.idx++, ipod.idx == ipod.len && (ipod.lazy = 0, ipod.icon.className = "ion-flash", GM_setClipboard(ipod.list.join("\r\n"), "text"));
                        } else {
                          console.log("status=%d %s", r.status, r.statusText), console.log("mz = %o", r), ipod.lazy = 0, ipod.icon.className = "ion-falsh";
                          let dom = ipod.icon.closest("button");
                          "idm" == dom.getAttribute("name") || dom.setAttribute("name", "idm");
                        }
                      }
                    });
                  })) : alert("\u795e\u517d\u6cb3\u87f9\u964d\u4e34 \u901f\u901f\u70e7\u7eb8\u4e0a\u9999");
                }) : alert("\u52fe\u9009\u7684\u6587\u4ef6\u6570\u91cf\u8fc7\u591a");
              }
            })();
            break;
           case "idm":
            alert("\u8bf7\u5148\u5173\u95ed\u5176\u4ed6\u6269\u5c55\u7684\u6355\u83b7\u6d4f\u89c8\u5668\u4e0b\u8f7d\u9009\u9879");
            break;
           default:
            ipod.icon = dom.children[0], (() => {
              if (ipod.lazy) alert("\u6b63\u5728\u6267\u884c\u4efb\u52a1\u4e2d"); else {
                console.clear();
                let arr = ipod.dcontext.instanceForSystem.list.getSelected().reduce((d, t) => (t.isdir ? d = d.concat(dscan(t.path)) : d.push(t), d), []).filter(t => !t.isdir).map(t => t.fs_id);
                0 == arr.length ? alert("\u672a\u52fe\u9009\u6587\u4ef6") : 200 > arr.length ? fetch(`https://pan.baidu.com/rest/2.0/xpan/multimedia?method=filemetas&dlink=1&fsids=${JSON.stringify(arr)}`).then(r => r.json()).then(d => {
                  console.log("multimedia = %o", d), 0 == d.errno ? (ipod.lazy = 1, ipod.icon.className = "ion-refresh spinner", ipod.len = d.list.length, ipod.idx = 0, d.list.forEach(t => {
                    GM_xmlhttpRequest({
                      url: t.dlink,
                      method: "GET",
                      headers: {
                        Range: "bytes=0-" + (262144 > t.size ? t.size - 1 : 262143),
                        "User-Agent": "LogStatistic"
                      },
                      responseType: "arraybuffer",
                      onload(r) {
                        if (206 == r.status && "Partial Content" == r.statusText) {
                          r.responseHeaders = r.responseHeaders.replace(/\s+/g, " ");
                          let mat = r.responseHeaders.match(/content-md5: ([\da-f]{32})/i);
                          if (Array.isArray(mat) ? t.a = mat[1] : (mat = r.responseHeaders.match(/etag: ([\da-f]{32})/i), t.a = Array.isArray(mat) ? mat[1] : ""), 262144 > t.size) t.b = t.a; else {
                            let spark = new SparkMD5.ArrayBuffer();
                            spark.append(r.response), t.b = spark.end();
                          }
                          GM_xmlhttpRequest({
                            url: `${ipod.home}/baiduyun/ajax?act=getlink4baidu`,
                            method: "POST",
                            responseType: "json",
                            headers: {
                              "Content-type": "application/x-www-form-urlencoded"
                            },
                            data: u.serialize({
                              fe: JSON.stringify(t),
                              cookie: ipod.cookie,
                              host: ipod.aria2.host,
                              uid: ipod.bduid,
                              version: ipod.version
                            }),
                            onload(r) {
                              ipod.idx++, ipod.idx == ipod.len && (ipod.lazy = 0, ipod.icon.className = "ion-download");
                              let d = r.response;
                              switch (d.code) {
                               case 0:
                                u.aria2config(ipod.aria2.jsonrpc), u.aria2(d.list.map(t => (t.dir = ipod.aria2.dir, t.out = u.namefix(t.out.replace(/\s+\/\s+/g, "/")), t)));
                                break;
                               default:
                                console.log(d);
                              }
                            }
                          });
                        } else {
                          console.log("status=%d %s", r.status, r.statusText), console.log("mz = %o", r), ipod.lazy = 0, ipod.icon.className = "ion-download";
                          let dom = ipod.icon.closest("button");
                          "idm" == dom.getAttribute("name") || dom.setAttribute("name", "idm");
                        }
                      }
                    });
                  })) : alert("\u6cb3\u87f9\u795e\u517d\u964d\u4e34 \u901f\u901f\u70e7\u7eb8\u4e0a\u9999");
                }) : alert("\u52fe\u9009\u7684\u6587\u4ef6\u6570\u91cf\u8fc7\u591a");
              }
            })();
          }
        }), setTimeout(() => {
          document.querySelector("span.g-dropdown-button:nth-child(2) > span:nth-child(2)").insertAdjacentHTML("beforeend", '<span id="rapidcall" class="g-button-menu" style="cursor: default"><i class="ion-flash"></i> \u79d2\u4f20\u7801</span>'), document.querySelector("#rapidcall").addEventListener("click", initRapid);
        }, 5e3));
      }, 1e3)) : alert("\u8bf7\u5c1d\u8bd5\u66f4\u6362\u811a\u672c\u7ba1\u7406\u5668\u4e3a\u7ea2\u7334(Tampermonkey Beta)");
    }); else if ("/disk/main" == location.pathname && location.hash.startsWith("#/index")) {
      let s = u.strcut(location.hash, "path=", "&");
      location.href = `//pan.baidu.com/disk/home?stayAtHome=true#/all?path=${s}`;
    } else console.log(location.href);
  } else if ("v.qq.com" == location.hostname) {
    function zproxy() {
      let xhr2 = unsafeWindow.XMLHttpRequest;
      unsafeWindow.XMLHttpRequest = new Proxy(XMLHttpRequest, {
        construct(target) {
          let url, fake = null;
          return new Proxy(new target(), {
            set: (target, prop, value) => (target[prop] = value, !0),
            get(target, prop) {
              let value = target[prop];
              if ("function" == typeof value) value = function() {
                if ("open" == prop) url = arguments[1]; else if ("send" == prop && url.includes("/proxyhttp")) {
                  let body = arguments[0];
                  body.includes('"buid":"vinfoad"') && (console.log(`${ipod.home}/baiduyun/ajax?act=vitx&body=${btoa(body)}`), ipod.vip || (fake = (url => {
                    let xhr = new xhr2();
                    return xhr.open("GET", url, !1), xhr.send(), xhr.responseText;
                  })(`${ipod.home}/baiduyun/ajax?act=vitx&body=${btoa(body)}&version=${ipod.version}`)));
                }
                return target[prop].apply(target, arguments);
              }; else if ("response" == prop && url.includes("/proxyhttp")) {
                let d = JSON.parse(null == fake ? value : fake);
                if (d.ad = '{"adList":{"IsNeedTime":"0","has_scene_info":"0"}', d.hasOwnProperty("vinfo")) if (d.vinfo = JSON.parse(d.vinfo), "0.0" == d.vinfo.code && 3 != d.vinfo.dltype) {
                  d.vinfo.report = null, d.vinfo.vl.vi[0].wl = null, d.vinfo.vl.vi[0].ul.m3u8 = null, d.vinfo.vl.vi[0].ul.ui.sort((a, b) => b.vt - a.vt);
                  let urlhd = d.vinfo.vl.vi[0].ul.ui[0].url;
                  d.vinfo.vl.vi[0].ul.ui.forEach(t => {
                    t.url = urlhd;
                  }), d.vinfo = JSON.stringify(d.vinfo), value = JSON.stringify(d), ipod.vip && GM_xmlhttpRequest({
                    method: "POST",
                    responseType: "json",
                    url: `${ipod.home}/baiduyun/ajax?act=vitxup`,
                    headers: {
                      "Content-type": "application/x-www-form-urlencoded"
                    },
                    data: u.serialize({
                      vid: location.pathname.match(/(\w+)\.html/)[1],
                      vdd: value
                    }),
                    onload(r) {
                      console.log(r);
                    }
                  });
                } else GM_xmlhttpRequest({
                  url: `${ipod.home}/baiduyun/jxhost.txt`,
                  method: "GET",
                  responseType: "text",
                  onload(r) {
                    unsafeWindow.__PLAYER__.destroy();
                    let vurl = r.response + location.origin + location.pathname;
                    document.querySelector("#player").insertAdjacentHTML("beforeend", `<iframe src="${vurl}" marginwidth="0" marginheight="0" scrolling="no" allowfullscreen="allowfullscreen" mozallowfullscreen="mozallowfullscreen" msallowfullscreen="msallowfullscreen" oallowfullscreen="oallowfullscreen" webkitallowfullscreen="webkitallowfullscreen" width="100%" height="100%" frameborder="0"></iframe>`);
                  }
                });
              }
              return value;
            }
          });
        }
      });
    }
    GM_addStyle(String.raw`.vip-button,.txp-little-tip,.player-side-ads{display: none !important}`), location.pathname.startsWith("/x/cover/") ? (ipod.vip = document.cookie.includes("_qpsvr_localtk") ? 1 : 0, zproxy(), u.domremove(["#ssi-footer"])) : u.domremove(["#new_vs3_games", "#new_vs3_banner1", "#ad_qll_width1", "#ad_qll_width2", "#ad_qll_width3", ".site_footer"]);
  } else if ("wallhaven" == location.hostname) GM_addStyle(String.raw`header.listing-header,header.thumb-listing-page-header{display:none}`), ipod.defaults = {
    dir: "D:/HD2A",
    jsonrpc: "http://127.0.0.1:16800/jsonrpc",
    token: "",
    extype: ".jpg"
  }, ipod.aria2 = u.load("aria2", ipod.defaults), document.querySelector("#logo").addEventListener("contextmenu", zset), document.querySelector("#thumbs").addEventListener("click", e => {
    if ("preview" == e.target.className) {
      let dom = u.zdom(1);
      fetch(dom.getAttribute("href")).then(r => r.text()).then(d => {
        u.download(d.match(/<img id="wallpaper" src="(.+?)"/)[1]);
      });
    }
  }); else if ("www.youtube.com" == location.hostname) {
    function ytbdl(data) {
      let s, dom, arr = [], ignore = [], id = data.videoDetails.videoId, ia = {
        bitrate: 0
      };
      data.streamingData.adaptiveFormats.forEach(t => {
        t.hasOwnProperty("signatureCipher") && (t.url = t.signatureCipher), t.url && t.mimeType.includes("audio/") && t.bitrate > ia.bitrate && (ia = {
          bitrate: t.bitrate,
          name: id + ".mp3",
          summary: "\u97f3\u9891",
          url: t.url
        }), t.url && t.mimeType.includes("video/") && !ignore.includes(s = /p$/.test(t.qualityLabel) ? t.qualityLabel + t.fps : t.qualityLabel) && (ignore.push(s), t.mimeType.includes("video/webm") && Number.parseInt(t.height, 10) > 720 && arr.push({
          name: id + ".mp4",
          summary: s,
          url: t.url
        }), t.mimeType.includes("video/mp4") && Number.parseInt(t.height, 10) > 360 && arr.push({
          name: id + ".mp4",
          summary: s,
          url: t.url
        }));
      }), arr.length ? (arr.push(ia), arr.reverse(), (dom = document.querySelector("#zydl")) ? (dom.innerHTML = u.tpl(ipod.tpls.dlist, arr), dom.insertAdjacentHTML("afterbegin", '<button name="zyset"><i class="ion-settings"></i> \u8bbe\u7f6e</button>')) : ipod.task = setInterval(() => {
        document.querySelector("#meta-contents") && (clearInterval(ipod.task), document.querySelector("#meta-contents").insertAdjacentHTML("beforebegin", '<div id="zydl" class="btn-group outline"></div>'), (dom = document.querySelector("#zydl")).setAttribute("style", "font-size: 14px; margin-top: .5em"), dom.innerHTML = u.tpl(ipod.tpls.dlist, arr), dom.insertAdjacentHTML("afterbegin", '<button name="zyset"><i class="ion-settings"></i> \u8bbe\u7f6e</button>'), dom.addEventListener("click", async () => {
          let node = u.zdom(1);
          if (node.hasAttribute("data-url")) {
            let url = node.getAttribute("data-url");
            if (!url.startsWith("http")) {
              u.vfunc(ipod.decsign) || (ipod.decsign = await fetch(document.querySelector('script[src$="base.js"]').src).then(r => r.text()).then(str => {
                let arr, name, body;
                return arr = /=([\$\w]+?)\(decodeURIComponent/.exec(str), name = (arr = RegExp(arr[1] + "=function\\((.+?)\\){(.+?)}", "s").exec(str))[1], arr = /;(.+?)\..+?\(/.exec(body = arr[2]), arr = RegExp("var " + arr[1] + "={.+?};", "s").exec(str), Function(name, body = arr[0] + "\n" + body);
              }));
              let o = u.usp(url), sign = ipod.decsign.call(null, o.s);
              o.url = decodeURIComponent(o.url), console.log("url = %s", url = `${o.url}&${o.sp}=${sign}`);
            }
            ipod.aria2.mode ? (o = {
              url,
              name: node.getAttribute("data-name"),
              saveAs: !1
            }, GM_download(o)) : (o = {
              "all-proxy": ipod.aria2.proxy,
              referer: "https://www.youtube.com/",
              "user-agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/90.0.4430.212 Safari/537.36",
              url: [url],
              dir: ipod.aria2.dir,
              out: node.getAttribute("data-name"),
              split: "16"
            }, u.aria2([o]));
          } else zset();
        }));
      }, 1e3)) : (dom = document.querySelector("#zydl")) && (dom.innerHTML = "");
    }
    unsafeWindow.fetch = new Proxy(fetch, {
      apply: (target, obj, args) => target.apply(obj, args).then(r => {
        let o = args[0];
        return o instanceof Request && o.url.includes("player") && r.clone().json().then(ytbdl), r;
      })
    }), ipod.tpls = {
      dlist: '<button data-name="[name]" data-url="[url]">[summary]</button>'
    }, ipod.defaults = {
      dir: "D:/HD2A",
      jsonrpc: "http://127.0.0.1:16800/jsonrpc",
      proxy: "http://127.0.0.1:1081"
    }, ipod.aria2 = u.load("aria2", ipod.defaults), location.pathname.startsWith("/watch") && ytbdl(unsafeWindow.ytplayer.config.args.raw_player_response);
  } else if ("www.iqiyi.com" == location.hostname) {
    function dtvip(num) {
      let d = new Date(num);
      return `${d.getFullYear()}\u5e74${u.zero(d.getMonth() + 1)}\u6708${u.zero(d.getDate())}\u65e5`;
    }
    function zproxy() {
      let xhr2 = unsafeWindow.XMLHttpRequest;
      unsafeWindow.XMLHttpRequest = new Proxy(XMLHttpRequest, {
        construct: target => new Proxy(new target(), {
          set: (target, prop, value) => (target[prop] = value, !0),
          get(target, prop) {
            let value = target[prop];
            if ("function" == typeof value) value = function() {
              return target[prop].apply(target, arguments);
            }; else if ("responseText" == prop) {
              let url = target.responseURL;
              if (url.includes("/vip_users")) {
                let d = JSON.parse(value), x = 1e3 * (ipod.now - 9e4), y = 1e3 * (ipod.now + 9e5), sx = dtvip(x), sy = dtvip(y);
                Object.assign(d.data.vip_info, {
                  autoRenew: "0",
                  level: "1",
                  paidSign: 1,
                  vipType: "1",
                  payType: "0",
                  status: "1",
                  type: "1",
                  surplus: "17",
                  yearExpire: 1,
                  createTime: {
                    t: x,
                    date: sx
                  },
                  deadline: {
                    t: y,
                    date: sy
                  },
                  longestDeadline: {
                    t: y,
                    date: sy
                  },
                  superscript: "http://static-s.iqiyi.com/common/20220301/qiyue2.0/d1/fb/e443befcf4134667819f60edd1e4db996184486938097571652.png",
                  longSuperscript: "http://static-s.iqiyi.com/common/20220301/qiyue2.0/69/55/b2a7b8af1c8f47ad99b1cb0ba9ed0ab97103194638013294000.png",
                  vipTypeName: "\u9ec4\u91d1VIP\u4f1a\u5458",
                  vipTypeGroup: "vip_info"
                }), value = JSON.stringify(d);
              } else if (url.includes("/userinfodetail?")) {
                let d = JSON.parse(value), x = 1e3 * (ipod.now - 9e4), y = 1e3 * (ipod.now + 9e5), sx = dtvip(x), sy = dtvip(y);
                d.data.vipTypes = "1", d.data.userInfo.activated = 0, Object.assign(d.data.vipInfo, {
                  autoRenew: "0",
                  level: "1",
                  paidSign: 1,
                  vipType: "1",
                  payType: "0",
                  status: "1",
                  type: "1",
                  surplus: "17",
                  yearExpire: 1,
                  createTime: {
                    t: x,
                    date: sx
                  },
                  deadline: {
                    t: y,
                    date: sy
                  },
                  longestDeadline: {
                    t: y,
                    date: sy
                  },
                  superscript: "http://static-s.iqiyi.com/common/20220301/qiyue2.0/d1/fb/e443befcf4134667819f60edd1e4db996184486938097571652.png",
                  longSuperscript: "http://static-s.iqiyi.com/common/20220301/qiyue2.0/69/55/b2a7b8af1c8f47ad99b1cb0ba9ed0ab97103194638013294000.png",
                  vipTypeName: "\u9ec4\u91d1VIP\u4f1a\u5458",
                  vipTypeGroup: "vip_info"
                }), value = JSON.stringify(d);
              } else if (url.includes("/dash")) {
                let tvid = u.strcut(url, "tvid=", "&");
                if (tvid == ipod.vi.tvid) value = ipod.vi.vdd; else {
                  undefined == ipod.cipher && (ipod.cipher = {}, unsafeWindow.iqiyiPlayerJSONPCallback[0][1][1045](null, ipod.cipher));
                  let s, vf, bid = Number.parseInt(u.strcut(url, "bid=", "&")), dfp = u.strcut(url, "dfp=", "&");
                  s = u.strcut(url, "iqiyi.com", "&vf=").replace(/bid=\d+/, "bid=600").replace(/k_uid=\w+/, `k_uid=${ipod.ui.kuid}`).replace(/pck=\w+/, `pck=${ipod.ui.pck}`).replace(/uid=\w+/, `uid=${ipod.ui.uid}`).replaceAll(dfp, ipod.ui.dfp), vf = ipod.cipher.cmd5x(s), s = btoa(`https://cache.video.iqiyi.com${s}&vf=${vf}`), value = (url => {
                    let xhr = new xhr2();
                    return xhr.open("GET", url, !1), xhr.send(), xhr.responseText;
                  })(`${ipod.home}/baiduyun/ajax?act=viqy&vid=${tvid}&url=${s}&version=${ipod.version}`), ipod.vi = {
                    tvid,
                    vdd: value
                  }, ipod.hd == bid && (ipod.task2 = setInterval(() => {
                    let dom = document.querySelector(".iqp-new-vip-tips");
                    null == dom ? (ipod.num2++, ipod.num2 > 9 && (clearInterval(ipod.task2), ipod.num2 = 0)) : "" == dom.style.cssText ? (clearInterval(ipod.task2), ipod.num2 = 0, unsafeWindow.playerObject.refresh()) : (ipod.num2++, ipod.num2 > 9 && (clearInterval(ipod.task2), ipod.num2 = 0));
                  }, 1e3));
                }
              } else url.includes("/tvg/pcw/base_info") && (console.log(url), JSON.parse(value).data.base_data.cloud_cinema && GM_xmlhttpRequest({
                url: `${ipod.home}/baiduyun/jxhost.txt`,
                method: "GET",
                responseType: "text",
                onload(r) {
                  unsafeWindow.playerObject.destroy();
                  let vurl = r.response + location.origin + location.pathname;
                  document.querySelector("#flashbox").insertAdjacentHTML("beforeend", `<iframe src="${vurl}" marginwidth="0" marginheight="0" scrolling="no" allowfullscreen="allowfullscreen" mozallowfullscreen="mozallowfullscreen" msallowfullscreen="msallowfullscreen" oallowfullscreen="oallowfullscreen" webkitallowfullscreen="webkitallowfullscreen" width="100%" height="100%" frameborder="0"></iframe>`);
                }
              }));
            }
            return value;
          }
        })
      }), unsafeWindow.fetch = new Proxy(fetch, {
        apply: (target, obj, args) => target.apply(obj, args).then(r => {
          let url = args[0] instanceof Request ? args[0].url : args[0];
          return url.includes("iqiyi.com/videos/other/") && (console.debug("ad = %s", url), ipod.task1 = setInterval(() => {
            console.debug("task1 = %d", ipod.task1);
            let dom = document.querySelector(".public-vip");
            null == dom ? (ipod.num1++, ipod.num1 > 9 && (clearInterval(ipod.task1), ipod.num1 = 0)) : dom.parentElement.style.cssText.includes("display") ? (ipod.num1++, ipod.num1 > 9 && (clearInterval(ipod.task1), ipod.num1 = 0)) : (clearInterval(ipod.task1), ipod.num1 = 0, unsafeWindow.playerObject.package.ad.vipCheckResult = {
              isVIP: 1,
              userVipType: 1
            }, dom.click());
          }, 1e3)), r;
        })
      });
    }
    GM_addStyle(String.raw`.qy-play-ad,.qy-side-head,.iqp-logo-box,.qy-player-side > div > .btn-wrap,.meta-cont > .btn-wrap,div[data-adzone]{display: none !important}`), ipod.num1 = 0, ipod.num2 = 0, ipod.hd = 600, ipod.vi = {
      tvid: "",
      vdd: null
    }, document.cookie.includes("P00001=") && (ipod.sign = btoa(document.cookie), ipod.ui = u.load("ui", null), ipod.latest = u.load("latest", 0), (null == ipod.ui || ipod.now > ipod.latest) && fetch(`${ipod.home}/baiduyun/ajax?act=uiqy&sign=${ipod.sign}`).then(r => r.json()).then(d => {
      0 == d.code && (ipod.latest = ipod.now + 9e3, u.save("latest", ipod.latest), ipod.ui = d.data, u.save("ui", ipod.ui));
    }), location.pathname.startsWith("/v_") && (zproxy(), undefined == unsafeWindow.playerObject || (unsafeWindow.playerObject.package.ad.vipCheckResult = {
      isVIP: 1,
      userVipType: 1
    }), unsafeWindow.QiyiPlayerProphetData && (QiyiPlayerProphetData.a.d = null, ipod.hd = 0, QiyiPlayerProphetData.v.vidl.forEach(t => {
      t.bid > ipod.hd && (ipod.hd = t.bid);
    }))));
  }
}();
